"use client";

import React, { useState, useEffect } from "react";
import { useAuth } from "@/context/AuthContext";
import {
  Factory,
  Layers,
  Users,
  CheckCircle2,
  Clock,
  AlertTriangle,
  ArrowRight,
  TrendingUp,
  FileText,
  CreditCard,
  Plus,
  ShieldCheck,
  Search,
  Sliders,
} from "lucide-react";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
} from "recharts";

export default function DashboardPage() {
  const { user } = useAuth();
  const [data, setData] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function loadDashboardData() {
      try {
        const [ordersRes, analyticsRes, requestsRes, notificationsRes] = await Promise.all([
          fetch("/api/orders?scope=mine"),
          fetch("/api/analytics"),
          fetch("/api/collaboration/requests"),
          fetch("/api/notifications"),
        ]);

        const ordersData = await ordersRes.json();
        const analyticsData = await analyticsRes.json();
        const requestsData = await requestsRes.json();
        const notificationsData = await notificationsRes.json();

        setData({
          orders: ordersData.orders || [],
          analytics: analyticsData,
          requests: requestsData.requests || [],
          notifications: notificationsData.notifications || [],
        });
      } catch (err) {
        console.error("Dashboard load failed:", err);
      } finally {
        setLoading(false);
      }
    }

    loadDashboardData();
  }, [user]);

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[50vh] space-y-4">
        <div className="w-10 h-10 border-4 border-teal-500 border-t-transparent rounded-full animate-spin" />
        <p className="text-sm text-slate-400">Loading collaborative workspace metrics...</p>
      </div>
    );
  }

  const metrics = data?.analytics?.metrics || {};
  const orders = data?.orders || [];
  const pendingRequests = (data?.requests || []).filter((r: any) => r.status === "PENDING");
  const monthlyData = data?.analytics?.monthlyData || [];
  const allocationDistribution = data?.analytics?.allocationDistribution || [];
  const COLORS = ["#0d9488", "#3b82f6", "#6366f1", "#f59e0b"];

  return (
    <div className="space-y-8">
      {/* Header Banner */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-bold text-white">Industrial Operations Hub</h1>
            {user?.business?.verificationStatus === "VERIFIED" && (
              <span className="flex items-center gap-1 text-[11px] font-semibold text-teal-400 bg-teal-500/10 px-2.5 py-0.5 rounded-full border border-teal-500/20">
                <ShieldCheck className="w-3.5 h-3.5" />
                Verified Business
              </span>
            )}
          </div>
          <p className="text-xs text-slate-400 mt-1">
            {user?.business?.name} • Category: <strong className="text-slate-200">{user?.business?.category}</strong> •
            Location: {user?.business?.location}
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {user?.role === "OWNER" && (
            <a
              href="/orders/new"
              className="inline-flex items-center gap-1.5 px-4 py-2 bg-teal-600 hover:bg-teal-500 text-white rounded-lg text-xs font-semibold shadow transition"
            >
              <Plus className="w-4 h-4" />
              Publish Bulk Order
            </a>
          )}
          <a
            href="/businesses"
            className="inline-flex items-center gap-1.5 px-3 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg text-xs font-medium border border-slate-700 transition"
          >
            <Search className="w-3.5 h-3.5" />
            Discover Partners
          </a>
          <a
            href="/capacity"
            className="inline-flex items-center gap-1.5 px-3 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg text-xs font-medium border border-slate-700 transition"
          >
            <Sliders className="w-3.5 h-3.5" />
            Manage Capacity
          </a>
        </div>
      </div>

      {/* KPI Cards Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Active Orders */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow space-y-2">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-xs font-medium uppercase tracking-wider">Active Orders</span>
            <Layers className="w-4 h-4 text-teal-400" />
          </div>
          <div className="text-2xl font-bold text-white">{orders.length}</div>
          <p className="text-[11px] text-slate-400">
            {metrics.activeOrdersCount || 0} in progress, {metrics.completedOrdersCount || 0} completed
          </p>
        </div>

        {/* Capacity Utilization */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow space-y-2">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-xs font-medium uppercase tracking-wider">Capacity Utilization</span>
            <Factory className="w-4 h-4 text-blue-400" />
          </div>
          <div className="text-2xl font-bold text-white">{metrics.utilizationRate || 0}%</div>
          <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
            <div
              className="bg-blue-500 h-full rounded-full transition-all"
              style={{ width: `${Math.min(100, metrics.utilizationRate || 0)}%` }}
            />
          </div>
          <p className="text-[11px] text-slate-400">
            {(metrics.availableCapacity || 0).toLocaleString()} {metrics.capacityUnit || "units"} available
          </p>
        </div>

        {/* Pending Invitations */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow space-y-2">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-xs font-medium uppercase tracking-wider">Pending Collabs</span>
            <Users className="w-4 h-4 text-amber-400" />
          </div>
          <div className="text-2xl font-bold text-white">{pendingRequests.length}</div>
          <p className="text-[11px] text-slate-400">
            {metrics.collaborationSuccessRate || 100}% historical acceptance rate
          </p>
        </div>

        {/* Financial Flow */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow space-y-2">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-xs font-medium uppercase tracking-wider">Invoiced Total</span>
            <CreditCard className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="text-2xl font-bold text-white">
            ₹{((metrics.totalInvoiced || 0) / 100000).toFixed(2)} Lakh
          </div>
          <p className="text-[11px] text-slate-400">
            Settled: ₹{((metrics.totalCollected || 0) / 100000).toFixed(2)} Lakh
          </p>
        </div>
      </div>

      {/* Visual Analytics Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Production Trends Chart */}
        <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-sm font-bold text-white">Production & Collaboration Volume (Units)</h2>
              <p className="text-xs text-slate-400">Target volume vs validated completions</p>
            </div>
            <span className="text-xs font-semibold text-teal-400 bg-teal-500/10 px-2 py-0.5 rounded border border-teal-500/30">
              Live Verified
            </span>
          </div>

          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={monthlyData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <XAxis dataKey="month" stroke="#64748b" fontSize={11} />
                <YAxis stroke="#64748b" fontSize={11} />
                <Tooltip
                  contentStyle={{ backgroundColor: "#0f172a", borderColor: "#334155", borderRadius: "0.5rem" }}
                  labelStyle={{ color: "#fff", fontWeight: "bold" }}
                />
                <Bar dataKey="volume" fill="#1e293b" name="Scheduled Units" radius={[4, 4, 0, 0]} />
                <Bar dataKey="completed" fill="#0d9488" name="Produced Units" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Work Allocation Distribution */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow space-y-4 flex flex-col justify-between">
          <div>
            <h2 className="text-sm font-bold text-white">Work Allocation Split</h2>
            <p className="text-xs text-slate-400">Lead company vs partner manufacturers</p>
          </div>

          <div className="h-44 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={allocationDistribution}
                  cx="50%"
                  cy="50%"
                  innerRadius={45}
                  outerRadius={70}
                  paddingAngle={4}
                  dataKey="value"
                >
                  {allocationDistribution.map((entry: any, index: number) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip
                  contentStyle={{ backgroundColor: "#0f172a", borderColor: "#334155", borderRadius: "0.5rem" }}
                />
              </PieChart>
            </ResponsiveContainer>
          </div>

          <div className="space-y-2 text-xs">
            {allocationDistribution.map((item: any, i: number) => (
              <div key={item.name} className="flex items-center justify-between text-slate-300">
                <div className="flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: COLORS[i % COLORS.length] }} />
                  <span className="truncate max-w-[150px]">{item.name}</span>
                </div>
                <span className="font-semibold text-white">
                  {item.value.toLocaleString()} u ({item.percentage}%)
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Active Orders List */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-base font-bold text-white">Managed Bulk Orders</h2>
            <p className="text-xs text-slate-400">Order progress, partner allocations, and deadlines</p>
          </div>
          <a href="/orders" className="text-xs text-teal-400 hover:text-teal-300 flex items-center gap-1 font-medium">
            View All Orders <ArrowRight className="w-3.5 h-3.5" />
          </a>
        </div>

        {orders.length === 0 ? (
          <div className="text-center py-8 text-xs text-slate-500">No active bulk orders registered yet.</div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-950 text-slate-400 uppercase tracking-wider text-[10px] border-b border-slate-800">
                <tr>
                  <th className="py-3 px-4">Order Ref</th>
                  <th className="py-3 px-4">Title & Category</th>
                  <th className="py-3 px-4">Total Qty</th>
                  <th className="py-3 px-4">Collaborators</th>
                  <th className="py-3 px-4">Status</th>
                  <th className="py-3 px-4">Deadline</th>
                  <th className="py-3 px-4 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800 text-slate-300">
                {orders.map((order: any) => {
                  const totalAllocated = (order.allocations || []).reduce(
                    (s: number, a: any) => s + (a.status !== "CANCELLED" ? a.allocatedQuantity : 0),
                    0
                  );
                  const isFullyCovered = totalAllocated >= order.totalQuantity;

                  return (
                    <tr key={order.id} className="hover:bg-slate-800/40 transition">
                      <td className="py-3 px-4 font-mono font-medium text-teal-400">{order.orderNumber}</td>
                      <td className="py-3 px-4">
                        <div className="font-semibold text-white truncate max-w-xs">{order.title}</div>
                        <div className="text-[11px] text-slate-400">{order.category}</div>
                      </td>
                      <td className="py-3 px-4">
                        <div className="font-medium text-white">
                          {order.totalQuantity.toLocaleString()} {order.quantityUnit}
                        </div>
                        <div className="text-[10px] text-slate-400">
                          Allocated: {totalAllocated.toLocaleString()} ({Math.round((totalAllocated / order.totalQuantity) * 100)}%)
                        </div>
                      </td>
                      <td className="py-3 px-4">
                        <div className="flex items-center gap-1">
                          <Users className="w-3.5 h-3.5 text-teal-400" />
                          <span>{(order.allocations || []).length} Business(es)</span>
                        </div>
                      </td>
                      <td className="py-3 px-4">
                        <span
                          className={`px-2 py-0.5 rounded text-[10px] font-semibold ${
                            order.status === "COMPLETED"
                              ? "bg-emerald-500/20 text-emerald-300 border border-emerald-500/30"
                              : order.status === "IN_PRODUCTION"
                              ? "bg-teal-500/20 text-teal-300 border border-teal-500/30"
                              : order.status === "OPEN_FOR_COLLABORATION"
                              ? "bg-amber-500/20 text-amber-300 border border-amber-500/30"
                              : "bg-slate-700 text-slate-300"
                          }`}
                        >
                          {order.status.replace(/_/g, " ")}
                        </span>
                      </td>
                      <td className="py-3 px-4 font-mono text-[11px]">
                        {new Date(order.deadline).toLocaleDateString()}
                      </td>
                      <td className="py-3 px-4 text-right">
                        <a
                          href={`/orders/${order.id}`}
                          className="px-2.5 py-1 bg-slate-800 hover:bg-teal-600 text-slate-200 hover:text-white rounded text-[11px] font-medium transition"
                        >
                          Manage
                        </a>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
