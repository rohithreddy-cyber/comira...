"use client";

import React, { useState, useEffect } from "react";
import { useAuth } from "@/context/AuthContext";
import {
  Layers,
  Search,
  Filter,
  Plus,
  ArrowRight,
  Factory,
  Users,
  Calendar,
  AlertTriangle,
  CheckCircle2,
  Sliders,
} from "lucide-react";

export default function OrdersPage() {
  const { user } = useAuth();
  const [orders, setOrders] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("");
  const [scope, setScope] = useState<"mine" | "all">("mine");

  const loadOrders = async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams();
      if (search) params.set("search", search);
      if (statusFilter) params.set("status", statusFilter);
      if (scope === "mine") params.set("scope", "mine");

      const res = await fetch(`/api/orders?${params.toString()}`);
      const data = await res.json();
      setOrders(data.orders || []);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadOrders();
  }, [search, statusFilter, scope]);

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl">
        <div>
          <h1 className="text-2xl font-bold text-white flex items-center gap-2">
            <Layers className="w-6 h-6 text-teal-400" />
            Bulk Manufacturing Orders
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Browse, manage, and distribute industrial contract orders exceeding individual capacities
          </p>
        </div>

        {user?.role === "OWNER" && (
          <a
            href="/orders/new"
            className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-teal-600 hover:bg-teal-500 text-white font-semibold text-xs shadow-lg shadow-teal-900/40 transition"
          >
            <Plus className="w-4 h-4" />
            Publish New Bulk Order
          </a>
        )}
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 flex flex-wrap items-center justify-between gap-3 shadow">
        <div className="flex flex-wrap items-center gap-2 flex-1 max-w-lg">
          <div className="relative flex-1 min-w-[200px]">
            <Search className="w-4 h-4 text-slate-500 absolute left-3 top-2.5" />
            <input
              type="text"
              placeholder="Search by title, order ref, or capabilities..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full pl-9 pr-3 py-1.5 bg-slate-950 border border-slate-700 rounded-lg text-xs text-white placeholder-slate-500 focus:outline-none focus:border-teal-500"
            />
          </div>

          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="px-3 py-1.5 bg-slate-950 border border-slate-700 rounded-lg text-xs text-white focus:outline-none focus:border-teal-500"
          >
            <option value="">All Statuses</option>
            <option value="OPEN_FOR_COLLABORATION">Open for Collaboration</option>
            <option value="COLLABORATION_PENDING">Collaboration Pending</option>
            <option value="PRODUCTION_SCHEDULED">Production Scheduled</option>
            <option value="IN_PRODUCTION">In Production</option>
            <option value="COMPLETED">Completed</option>
          </select>
        </div>

        <div className="flex items-center gap-2 text-xs">
          <button
            onClick={() => setScope("mine")}
            className={`px-3 py-1.5 rounded-lg font-medium transition ${
              scope === "mine"
                ? "bg-teal-600 text-white"
                : "bg-slate-800 text-slate-300 hover:bg-slate-700"
            }`}
          >
            My Business Orders
          </button>
          <button
            onClick={() => setScope("all")}
            className={`px-3 py-1.5 rounded-lg font-medium transition ${
              scope === "all"
                ? "bg-teal-600 text-white"
                : "bg-slate-800 text-slate-300 hover:bg-slate-700"
            }`}
          >
            All Open Marketplace Orders
          </button>
        </div>
      </div>

      {/* Orders Grid */}
      {loading ? (
        <div className="flex justify-center py-12">
          <div className="w-8 h-8 border-4 border-teal-500 border-t-transparent rounded-full animate-spin" />
        </div>
      ) : orders.length === 0 ? (
        <div className="text-center py-16 bg-slate-900 border border-slate-800 rounded-2xl space-y-3">
          <Layers className="w-10 h-10 text-slate-600 mx-auto" />
          <h3 className="text-base font-semibold text-white">No Orders Found</h3>
          <p className="text-xs text-slate-400 max-w-sm mx-auto">
            Try adjusting your search filters or publish a new bulk order to initiate collaborative production.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {orders.map((order) => {
            const totalAllocated = (order.allocations || []).reduce(
              (s: number, a: any) => s + (a.status !== "CANCELLED" ? a.allocatedQuantity : 0),
              0
            );
            const totalProduced = (order.allocations || []).reduce(
              (s: number, a: any) => s + (a.status !== "CANCELLED" ? a.completedQuantity : 0),
              0
            );
            const allocPercent = Math.min(100, Math.round((totalAllocated / order.totalQuantity) * 100));
            const prodPercent = Math.min(100, Math.round((totalProduced / order.totalQuantity) * 100));

            return (
              <div
                key={order.id}
                className="bg-slate-900 border border-slate-800 hover:border-slate-700 rounded-2xl p-5 shadow transition flex flex-col justify-between space-y-4"
              >
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="font-mono text-xs text-teal-400 font-semibold bg-teal-500/10 px-2.5 py-0.5 rounded border border-teal-500/20">
                      {order.orderNumber}
                    </span>
                    <span
                      className={`px-2.5 py-0.5 rounded text-[10px] font-semibold ${
                        order.status === "COMPLETED"
                          ? "bg-emerald-500/20 text-emerald-300 border border-emerald-500/30"
                          : order.status === "IN_PRODUCTION"
                          ? "bg-teal-500/20 text-teal-300 border border-teal-500/30"
                          : order.status === "OPEN_FOR_COLLABORATION"
                          ? "bg-amber-500/20 text-amber-300 border border-amber-500/30"
                          : "bg-slate-700 text-slate-300"
                      }`}
                    >
                      {order.status.replace(/_/g, " ")}
                    </span>
                  </div>

                  <div>
                    <h3 className="font-bold text-white text-base leading-snug">{order.title}</h3>
                    <p className="text-xs text-slate-400 line-clamp-2 mt-1">{order.description}</p>
                  </div>

                  {/* Badges / Specs */}
                  <div className="flex flex-wrap gap-1.5 text-[11px]">
                    <span className="px-2 py-0.5 rounded bg-slate-800 text-slate-300 border border-slate-700">
                      🏭 {order.category}
                    </span>
                    <span className="px-2 py-0.5 rounded bg-slate-800 text-slate-300 border border-slate-700">
                      📍 {order.deliveryLocation}
                    </span>
                    <span className="px-2 py-0.5 rounded bg-slate-800 text-slate-300 border border-slate-700">
                      💰 ₹{order.targetUnitCost} / {order.quantityUnit}
                    </span>
                  </div>

                  {/* Allocation & Production Progress Bars */}
                  <div className="space-y-1.5 pt-2">
                    <div className="flex justify-between text-xs text-slate-400">
                      <span>Work Allocation</span>
                      <span className="text-white font-medium">
                        {totalAllocated.toLocaleString()} / {order.totalQuantity.toLocaleString()} {order.quantityUnit} ({allocPercent}%)
                      </span>
                    </div>
                    <div className="w-full bg-slate-950 h-2 rounded-full overflow-hidden border border-slate-800">
                      <div
                        className="bg-blue-500 h-full rounded-full transition-all"
                        style={{ width: `${allocPercent}%` }}
                      />
                    </div>

                    <div className="flex justify-between text-xs text-slate-400 pt-1">
                      <span>Verified Production</span>
                      <span className="text-teal-400 font-medium">
                        {totalProduced.toLocaleString()} units ({prodPercent}%)
                      </span>
                    </div>
                    <div className="w-full bg-slate-950 h-2 rounded-full overflow-hidden border border-slate-800">
                      <div
                        className="bg-teal-500 h-full rounded-full transition-all"
                        style={{ width: `${prodPercent}%` }}
                      />
                    </div>
                  </div>
                </div>

                <div className="pt-3 border-t border-slate-800 flex items-center justify-between text-xs">
                  <div className="text-slate-400 flex items-center gap-1">
                    <Calendar className="w-3.5 h-3.5" />
                    Deadline: <strong className="text-slate-200">{new Date(order.deadline).toLocaleDateString()}</strong>
                  </div>
                  <a
                    href={`/orders/${order.id}`}
                    className="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg bg-teal-600 hover:bg-teal-500 text-white font-medium transition"
                  >
                    View Details
                    <ArrowRight className="w-3.5 h-3.5" />
                  </a>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
