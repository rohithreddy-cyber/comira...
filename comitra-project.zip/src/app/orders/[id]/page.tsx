"use client";

import React, { useState, useEffect } from "react";
import { useParams, useRouter } from "next/navigation";
import { useAuth } from "@/context/AuthContext";
import {
  Layers,
  Factory,
  Users,
  CheckCircle2,
  Calendar,
  AlertTriangle,
  ArrowRight,
  ShieldCheck,
  Send,
  Sliders,
  FileText,
  CreditCard,
  Plus,
  Info,
  Clock,
  Sparkles,
  ExternalLink,
} from "lucide-react";

export default function OrderDetailsPage() {
  const { id } = useParams();
  const { user } = useAuth();
  const router = useRouter();

  const [orderData, setOrderData] = useState<any>(null);
  const [recommendations, setRecommendations] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<"matching" | "allocations" | "agreements" | "specs">("matching");

  // Scoring weights state
  const [weights, setWeights] = useState({
    capabilityWeight: 0.35,
    capacityWeight: 0.25,
    qualityWeight: 0.15,
    deadlineWeight: 0.15,
    trustWeight: 0.10,
  });

  // Invitation Modal state
  const [inviteModalOpen, setInviteModalOpen] = useState(false);
  const [selectedPartner, setSelectedPartner] = useState<any>(null);
  const [inviteForm, setInviteForm] = useState({
    proposedQuantity: 2500,
    unitPrice: 450,
    proposedDeadline: "",
    requirements: "",
    message: "",
  });
  const [inviteLoading, setInviteLoading] = useState(false);
  const [inviteMsg, setInviteMsg] = useState<{ text: string; error?: boolean } | null>(null);

  const loadOrderAndRecommendations = async () => {
    setLoading(true);
    try {
      const [orderRes, recsRes] = await Promise.all([
        fetch(`/api/orders/${id}`),
        fetch(
          `/api/orders/${id}/recommendations?capabilityWeight=${weights.capabilityWeight}&capacityWeight=${weights.capacityWeight}&qualityWeight=${weights.qualityWeight}&deadlineWeight=${weights.deadlineWeight}&trustWeight=${weights.trustWeight}`
        ),
      ]);

      const oData = await orderRes.json();
      const rData = await recsRes.json();

      setOrderData(oData);
      setRecommendations(rData.recommendations || []);

      if (oData.order) {
        setInviteForm((prev) => ({
          ...prev,
          unitPrice: oData.order.targetUnitCost,
          proposedDeadline: new Date(oData.order.deadline).toISOString().split("T")[0],
          requirements: oData.order.qualityRequirements,
        }));
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (id) {
      loadOrderAndRecommendations();
    }
  }, [id, weights]);

  const handleSendInvite = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedPartner) return;
    setInviteLoading(true);
    setInviteMsg(null);

    try {
      const res = await fetch("/api/collaboration/requests", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          orderId: id,
          receiverBusinessId: selectedPartner.id,
          proposedQuantity: inviteForm.proposedQuantity,
          unitPrice: inviteForm.unitPrice,
          proposedDeadline: inviteForm.proposedDeadline,
          requirements: inviteForm.requirements,
          message: inviteForm.message,
        }),
      });

      const data = await res.json();
      setInviteLoading(false);

      if (!res.ok) {
        setInviteMsg({ text: data.error || "Failed to send invitation", error: true });
        return;
      }

      setInviteMsg({ text: `Collaboration invitation sent to ${selectedPartner.name}!` });
      setTimeout(() => {
        setInviteModalOpen(false);
        loadOrderAndRecommendations();
      }, 1500);
    } catch (err: any) {
      setInviteLoading(false);
      setInviteMsg({ text: err.message || "Network error", error: true });
    }
  };

  if (loading && !orderData) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[50vh] space-y-4">
        <div className="w-10 h-10 border-4 border-teal-500 border-t-transparent rounded-full animate-spin" />
        <p className="text-sm text-slate-400">Loading order allocations & matching recommendations...</p>
      </div>
    );
  }

  const order = orderData?.order;
  const summary = orderData?.summary || {};
  const isOwner = user?.businessId === order?.ownerBusinessId;

  return (
    <div className="space-y-8">
      {/* Header Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 sm:p-8 shadow-xl space-y-6">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <span className="font-mono text-xs font-bold text-teal-400 bg-teal-500/10 px-3 py-1 rounded-full border border-teal-500/30">
                {order.orderNumber}
              </span>
              <span
                className={`px-2.5 py-0.5 rounded text-[10px] font-semibold ${
                  order.status === "COMPLETED"
                    ? "bg-emerald-500/20 text-emerald-300 border border-emerald-500/30"
                    : order.status === "IN_PRODUCTION"
                    ? "bg-teal-500/20 text-teal-300 border border-teal-500/30"
                    : order.status === "OPEN_FOR_COLLABORATION"
                    ? "bg-amber-500/20 text-amber-300 border border-amber-500/30"
                    : "bg-slate-700 text-slate-300"
                }`}
              >
                {order.status.replace(/_/g, " ")}
              </span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-white">{order.title}</h1>
            <p className="text-xs text-slate-400 max-w-3xl leading-relaxed">{order.description}</p>
          </div>

          <div className="text-right space-y-1">
            <div className="text-xs text-slate-400">Total Order Budget</div>
            <div className="text-2xl font-mono font-bold text-white">₹{order.totalBudget.toLocaleString()}</div>
            <div className="text-[11px] text-teal-400 font-medium">
              ₹{order.targetUnitCost} per {order.quantityUnit}
            </div>
          </div>
        </div>

        {/* Global Progress Overview */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-4 border-t border-slate-800 text-xs">
          <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-1">
            <span className="text-slate-400">Total Required Quantity</span>
            <div className="text-lg font-bold text-white">
              {order.totalQuantity.toLocaleString()} {order.quantityUnit}
            </div>
            <div className="text-[11px] text-slate-500">
              In-house: {(order.selfAllocatedQty || 0).toLocaleString()} • Needed:{" "}
              {summary.remainingUnallocated.toLocaleString()}
            </div>
          </div>

          <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-1">
            <div className="flex justify-between">
              <span className="text-slate-400">Work Allocation</span>
              <span className="text-blue-400 font-bold">
                {Math.round((summary.totalAllocated / order.totalQuantity) * 100)}%
              </span>
            </div>
            <div className="text-lg font-bold text-white">
              {summary.totalAllocated.toLocaleString()} / {order.totalQuantity.toLocaleString()} {order.quantityUnit}
            </div>
            <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
              <div
                className="bg-blue-500 h-full rounded-full transition-all"
                style={{ width: `${Math.min(100, Math.round((summary.totalAllocated / order.totalQuantity) * 100))}%` }}
              />
            </div>
          </div>

          <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-1">
            <div className="flex justify-between">
              <span className="text-slate-400">Verified Production</span>
              <span className="text-teal-400 font-bold">{summary.progressPercentage}%</span>
            </div>
            <div className="text-lg font-bold text-white">
              {summary.totalProduced.toLocaleString()} / {order.totalQuantity.toLocaleString()} {order.quantityUnit}
            </div>
            <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
              <div
                className="bg-teal-500 h-full rounded-full transition-all"
                style={{ width: `${summary.progressPercentage}%` }}
              />
            </div>
          </div>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="border-b border-slate-800 flex gap-4 text-xs font-semibold">
        <button
          onClick={() => setActiveTab("matching")}
          className={`pb-3 flex items-center gap-2 border-b-2 transition ${
            activeTab === "matching"
              ? "border-teal-400 text-teal-300"
              : "border-transparent text-slate-400 hover:text-slate-200"
          }`}
        >
          <Sparkles className="w-4 h-4" />
          Partner Matching Engine ({recommendations.length})
        </button>
        <button
          onClick={() => setActiveTab("allocations")}
          className={`pb-3 flex items-center gap-2 border-b-2 transition ${
            activeTab === "allocations"
              ? "border-teal-400 text-teal-300"
              : "border-transparent text-slate-400 hover:text-slate-200"
          }`}
        >
          <Factory className="w-4 h-4" />
          Work Allocations & Milestones ({(order.allocations || []).length})
        </button>
        <button
          onClick={() => setActiveTab("agreements")}
          className={`pb-3 flex items-center gap-2 border-b-2 transition ${
            activeTab === "agreements"
              ? "border-teal-400 text-teal-300"
              : "border-transparent text-slate-400 hover:text-slate-200"
          }`}
        >
          <FileText className="w-4 h-4" />
          Agreements & Invoices ({(order.agreements || []).length + (order.invoices || []).length})
        </button>
        <button
          onClick={() => setActiveTab("specs")}
          className={`pb-3 flex items-center gap-2 border-b-2 transition ${
            activeTab === "specs"
              ? "border-teal-400 text-teal-300"
              : "border-transparent text-slate-400 hover:text-slate-200"
          }`}
        >
          <Sliders className="w-4 h-4" />
          Technical Specifications
        </button>
      </div>

      {/* TAB 1: PARTNER MATCHING ENGINE */}
      {activeTab === "matching" && (
        <div className="space-y-6">
          {/* Algorithmic Weights Tuning Box */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <div>
                <h2 className="text-sm font-bold text-white flex items-center gap-1.5">
                  <Sliders className="w-4 h-4 text-teal-400" />
                  Transparent Rule-Based Scoring Formula
                </h2>
                <p className="text-[11px] text-slate-400">
                  Calculates partner compatibility autonomously without external AI APIs using 5 normalized criteria.
                </p>
              </div>
              <span className="text-[11px] font-mono text-teal-300 bg-slate-950 px-3 py-1 rounded border border-slate-800">
                Score = 0.35·Cap + 0.25·Vol + 0.15·Qual + 0.15·Lead + 0.10·Trust
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-5 gap-4 pt-2 text-xs">
              <div>
                <div className="flex justify-between text-slate-400 mb-1">
                  <span>Capability</span>
                  <span className="text-white font-mono">{Math.round(weights.capabilityWeight * 100)}%</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="1"
                  step="0.05"
                  value={weights.capabilityWeight}
                  onChange={(e) => setWeights({ ...weights, capabilityWeight: parseFloat(e.target.value) })}
                  className="w-full accent-teal-500"
                />
              </div>

              <div>
                <div className="flex justify-between text-slate-400 mb-1">
                  <span>Capacity</span>
                  <span className="text-white font-mono">{Math.round(weights.capacityWeight * 100)}%</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="1"
                  step="0.05"
                  value={weights.capacityWeight}
                  onChange={(e) => setWeights({ ...weights, capacityWeight: parseFloat(e.target.value) })}
                  className="w-full accent-teal-500"
                />
              </div>

              <div>
                <div className="flex justify-between text-slate-400 mb-1">
                  <span>Quality/Cert</span>
                  <span className="text-white font-mono">{Math.round(weights.qualityWeight * 100)}%</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="1"
                  step="0.05"
                  value={weights.qualityWeight}
                  onChange={(e) => setWeights({ ...weights, qualityWeight: parseFloat(e.target.value) })}
                  className="w-full accent-teal-500"
                />
              </div>

              <div>
                <div className="flex justify-between text-slate-400 mb-1">
                  <span>Deadline</span>
                  <span className="text-white font-mono">{Math.round(weights.deadlineWeight * 100)}%</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="1"
                  step="0.05"
                  value={weights.deadlineWeight}
                  onChange={(e) => setWeights({ ...weights, deadlineWeight: parseFloat(e.target.value) })}
                  className="w-full accent-teal-500"
                />
              </div>

              <div>
                <div className="flex justify-between text-slate-400 mb-1">
                  <span>Trust History</span>
                  <span className="text-white font-mono">{Math.round(weights.trustWeight * 100)}%</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="1"
                  step="0.05"
                  value={weights.trustWeight}
                  onChange={(e) => setWeights({ ...weights, trustWeight: parseFloat(e.target.value) })}
                  className="w-full accent-teal-500"
                />
              </div>
            </div>
          </div>

          {/* Recommendations Cards List */}
          <div className="space-y-4">
            {recommendations.map((rec) => {
              const b = rec.business;
              const bd = rec.breakdown;
              const isAllocated = (order.allocations || []).some((a: any) => a.businessId === b.id);

              return (
                <div
                  key={b.id}
                  className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-4 hover:border-slate-700 transition"
                >
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                    <div>
                      <div className="flex items-center gap-2">
                        <h3 className="text-lg font-bold text-white">{b.name}</h3>
                        {b.verificationStatus === "VERIFIED" && (
                          <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-teal-500/10 text-teal-400 border border-teal-500/20">
                            Verified MSME
                          </span>
                        )}
                        {isAllocated && (
                          <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-blue-500/20 text-blue-300 border border-blue-500/30">
                            Active Collaborator
                          </span>
                        )}
                      </div>
                      <p className="text-xs text-slate-400 mt-0.5">
                        {b.category} • {b.location} • Available Capacity:{" "}
                        <strong className="text-teal-400 font-mono">
                          {b.availableCapacity.toLocaleString()} {b.capacityUnit}
                        </strong>
                      </p>
                    </div>

                    <div className="flex items-center gap-3">
                      <div className="text-right">
                        <div className="text-xs text-slate-400">Recommendation Score</div>
                        <div className="text-2xl font-bold font-mono text-teal-400">{bd.totalScore}%</div>
                      </div>
                      <span
                        className={`px-3 py-1 rounded-lg text-xs font-bold ${
                          bd.matchCategory === "EXCELLENT"
                            ? "bg-emerald-500/20 text-emerald-300 border border-emerald-500/30"
                            : bd.matchCategory === "HIGH"
                            ? "bg-teal-500/20 text-teal-300 border border-teal-500/30"
                            : bd.matchCategory === "MODERATE"
                            ? "bg-amber-500/20 text-amber-300 border border-amber-500/30"
                            : "bg-slate-800 text-slate-400 border border-slate-700"
                        }`}
                      >
                        {bd.matchCategory} MATCH
                      </span>
                    </div>
                  </div>

                  {/* Factor Breakdown Bars */}
                  <div className="grid grid-cols-2 sm:grid-cols-5 gap-3 pt-3 border-t border-slate-800/80 text-xs">
                    <div>
                      <span className="text-slate-400">Capability ({bd.capabilityScore}%)</span>
                      <div className="w-full bg-slate-950 h-1.5 rounded-full overflow-hidden mt-1">
                        <div className="bg-teal-500 h-full rounded-full" style={{ width: `${bd.capabilityScore}%` }} />
                      </div>
                    </div>
                    <div>
                      <span className="text-slate-400">Capacity ({bd.capacityScore}%)</span>
                      <div className="w-full bg-slate-950 h-1.5 rounded-full overflow-hidden mt-1">
                        <div className="bg-blue-500 h-full rounded-full" style={{ width: `${bd.capacityScore}%` }} />
                      </div>
                    </div>
                    <div>
                      <span className="text-slate-400">Deadline ({bd.deadlineScore}%)</span>
                      <div className="w-full bg-slate-950 h-1.5 rounded-full overflow-hidden mt-1">
                        <div className="bg-indigo-500 h-full rounded-full" style={{ width: `${bd.deadlineScore}%` }} />
                      </div>
                    </div>
                    <div>
                      <span className="text-slate-400">Quality ({bd.qualityScore}%)</span>
                      <div className="w-full bg-slate-950 h-1.5 rounded-full overflow-hidden mt-1">
                        <div className="bg-purple-500 h-full rounded-full" style={{ width: `${bd.qualityScore}%` }} />
                      </div>
                    </div>
                    <div>
                      <span className="text-slate-400">Trust ({bd.trustScore}%)</span>
                      <div className="w-full bg-slate-950 h-1.5 rounded-full overflow-hidden mt-1">
                        <div className="bg-amber-500 h-full rounded-full" style={{ width: `${bd.trustScore}%` }} />
                      </div>
                    </div>
                  </div>

                  {/* Explainable Reasons & Limitations */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2 text-xs">
                    <div className="p-3 rounded-xl bg-slate-950/80 border border-slate-800/80 space-y-1">
                      <span className="font-semibold text-emerald-400 flex items-center gap-1">
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        Recommendation Justification:
                      </span>
                      <ul className="space-y-1 text-slate-300 text-[11px] pl-4 list-disc">
                        {bd.reasons.map((r: string, idx: number) => (
                          <li key={idx}>{r}</li>
                        ))}
                      </ul>
                    </div>

                    <div className="p-3 rounded-xl bg-slate-950/80 border border-slate-800/80 space-y-1">
                      <span className="font-semibold text-amber-400 flex items-center gap-1">
                        <AlertTriangle className="w-3.5 h-3.5" />
                        Operational Considerations:
                      </span>
                      {bd.limitations && bd.limitations.length > 0 ? (
                        <ul className="space-y-1 text-slate-300 text-[11px] pl-4 list-disc">
                          {bd.limitations.map((l: string, idx: number) => (
                            <li key={idx}>{l}</li>
                          ))}
                        </ul>
                      ) : (
                        <p className="text-[11px] text-slate-500">No major operational bottlenecks detected.</p>
                      )}
                    </div>
                  </div>

                  {/* Action Button */}
                  {isOwner && !isAllocated && (
                    <div className="pt-2 flex justify-end">
                      <button
                        onClick={() => {
                          setSelectedPartner(b);
                          setInviteForm((prev) => ({
                            ...prev,
                            proposedQuantity: Math.min(2500, b.availableCapacity),
                          }));
                          setInviteModalOpen(true);
                        }}
                        className="inline-flex items-center gap-1.5 px-4 py-2 bg-teal-600 hover:bg-teal-500 text-white font-semibold text-xs rounded-lg shadow transition"
                      >
                        <Send className="w-3.5 h-3.5" />
                        Send Collaboration Invitation
                      </button>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* TAB 2: WORK ALLOCATIONS & PRODUCTION STREAMS */}
      {activeTab === "allocations" && (
        <div className="space-y-6">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-4">
            <h2 className="text-base font-bold text-white">Distributed Manufacturing Production Lines</h2>
            <p className="text-xs text-slate-400">
              Allocated work breakdown, verified completions, and lead deadlines across companies.
            </p>

            <div className="space-y-4">
              {(order.allocations || []).map((alloc: any) => {
                const percent = Math.min(
                  100,
                  Math.round((alloc.completedQuantity / alloc.allocatedQuantity) * 100)
                );
                return (
                  <div
                    key={alloc.id}
                    className="p-5 rounded-xl bg-slate-950 border border-slate-800 space-y-3"
                  >
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                      <div>
                        <div className="flex items-center gap-2">
                          <h3 className="font-bold text-white text-sm">{alloc.business?.name}</h3>
                          <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-teal-500/10 text-teal-400">
                            {alloc.status}
                          </span>
                        </div>
                        <p className="text-xs text-slate-400 mt-0.5">
                          Agreed Rate: ₹{alloc.agreedUnitPrice} • Value: ₹{alloc.totalAmount.toLocaleString()} •
                          Target: {new Date(alloc.agreedDeadline).toLocaleDateString()}
                        </p>
                      </div>

                      <div className="text-right">
                        <div className="text-xs text-slate-400">Produced Units</div>
                        <div className="text-lg font-mono font-bold text-white">
                          {alloc.completedQuantity.toLocaleString()} / {alloc.allocatedQuantity.toLocaleString()}{" "}
                          {order.quantityUnit} ({percent}%)
                        </div>
                      </div>
                    </div>

                    <div className="w-full bg-slate-900 h-2 rounded-full overflow-hidden border border-slate-800">
                      <div className="bg-teal-500 h-full rounded-full transition-all" style={{ width: `${percent}%` }} />
                    </div>

                    {alloc.notes && <p className="text-xs text-slate-400 italic">“{alloc.notes}”</p>}
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* TAB 3: AGREEMENTS & INVOICES */}
      {activeTab === "agreements" && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-4">
            <h2 className="text-sm font-bold text-white flex items-center gap-1.5">
              <FileText className="w-4 h-4 text-teal-400" />
              Digital Co-Manufacturing Agreements
            </h2>
            <div className="space-y-3">
              {(order.agreements || []).map((agr: any) => (
                <div key={agr.id} className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2 text-xs">
                  <div className="flex justify-between items-center">
                    <span className="font-mono text-teal-400 font-bold">{agr.agreementNumber}</span>
                    <span className="px-2 py-0.5 rounded text-[10px] bg-teal-500/20 text-teal-300">
                      {agr.status}
                    </span>
                  </div>
                  <p className="font-semibold text-white">{agr.title}</p>
                  <p className="text-slate-400">
                    Partner: {agr.partnerBusiness?.name} • Allocation: {agr.allocatedQuantity.toLocaleString()} units
                  </p>
                  <a
                    href="/agreements"
                    className="inline-flex items-center gap-1 text-teal-400 hover:text-teal-300 font-medium"
                  >
                    View & Print Agreement <ExternalLink className="w-3 h-3" />
                  </a>
                </div>
              ))}
            </div>
          </div>

          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-4">
            <h2 className="text-sm font-bold text-white flex items-center gap-1.5">
              <CreditCard className="w-4 h-4 text-teal-400" />
              Milestone Invoices & Payments
            </h2>
            <div className="space-y-3">
              {(order.invoices || []).map((inv: any) => (
                <div key={inv.id} className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2 text-xs">
                  <div className="flex justify-between items-center">
                    <span className="font-mono text-teal-400 font-bold">{inv.invoiceNumber}</span>
                    <span
                      className={`px-2 py-0.5 rounded text-[10px] ${
                        inv.status === "PAID" ? "bg-emerald-500/20 text-emerald-300" : "bg-blue-500/20 text-blue-300"
                      }`}
                    >
                      {inv.status}
                    </span>
                  </div>
                  <p className="text-white font-medium">{inv.itemDescription}</p>
                  <div className="flex justify-between text-slate-400">
                    <span>Total (with GST): ₹{inv.amountTotal.toLocaleString()}</span>
                    <span>Due: {new Date(inv.dueDate).toLocaleDateString()}</span>
                  </div>
                  <a
                    href="/invoices"
                    className="inline-flex items-center gap-1 text-teal-400 hover:text-teal-300 font-medium"
                  >
                    View Invoice Records <ExternalLink className="w-3 h-3" />
                  </a>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* TAB 4: TECHNICAL SPECIFICATIONS */}
      {activeTab === "specs" && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-4 text-xs">
          <h2 className="text-base font-bold text-white">Full Manufacturing Specifications</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
              <h3 className="font-bold text-slate-200">Required Machining Capabilities</h3>
              <p className="text-teal-400 font-mono">{order.requiredCapabilities}</p>
            </div>
            <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
              <h3 className="font-bold text-slate-200">Delivery Destination</h3>
              <p className="text-slate-300">{order.deliveryLocation}</p>
            </div>
            <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
              <h3 className="font-bold text-slate-200">Technical Tolerances & Drawings</h3>
              <p className="text-slate-300">{order.technicalSpecs}</p>
            </div>
            <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
              <h3 className="font-bold text-slate-200">Quality Inspection Standards</h3>
              <p className="text-slate-300">{order.qualityRequirements}</p>
            </div>
          </div>
        </div>
      )}

      {/* Collaboration Invitation Modal */}
      {inviteModalOpen && selectedPartner && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 max-w-lg w-full space-y-4 shadow-2xl">
            <div className="flex justify-between items-center border-b border-slate-800 pb-3">
              <div>
                <h3 className="text-base font-bold text-white">Send Collaboration Invitation</h3>
                <p className="text-xs text-slate-400">Partner: {selectedPartner.name}</p>
              </div>
              <button
                onClick={() => setInviteModalOpen(false)}
                className="text-slate-400 hover:text-white text-xs font-semibold"
              >
                ✕
              </button>
            </div>

            {inviteMsg && (
              <div
                className={`p-3 rounded-lg text-xs ${
                  inviteMsg.error ? "bg-red-950/80 text-red-200" : "bg-emerald-950/80 text-emerald-200"
                }`}
              >
                {inviteMsg.text}
              </div>
            )}

            <form onSubmit={handleSendInvite} className="space-y-4 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 mb-1">Proposed Work Quantity</label>
                  <input
                    type="number"
                    required
                    min="1"
                    max={selectedPartner.availableCapacity}
                    value={inviteForm.proposedQuantity}
                    onChange={(e) =>
                      setInviteForm({ ...inviteForm, proposedQuantity: parseFloat(e.target.value) || 0 })
                    }
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-white"
                  />
                  <span className="text-[10px] text-teal-400">
                    Max available: {selectedPartner.availableCapacity.toLocaleString()}
                  </span>
                </div>

                <div>
                  <label className="block text-slate-300 mb-1">Agreed Unit Rate (₹)</label>
                  <input
                    type="number"
                    required
                    min="1"
                    value={inviteForm.unitPrice}
                    onChange={(e) => setInviteForm({ ...inviteForm, unitPrice: parseFloat(e.target.value) || 0 })}
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-white"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-300 mb-1">Target Milestone Deadline</label>
                <input
                  type="date"
                  required
                  value={inviteForm.proposedDeadline}
                  onChange={(e) => setInviteForm({ ...inviteForm, proposedDeadline: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-white"
                />
              </div>

              <div>
                <label className="block text-slate-300 mb-1">Specific Production Requirements</label>
                <input
                  type="text"
                  value={inviteForm.requirements}
                  onChange={(e) => setInviteForm({ ...inviteForm, requirements: e.target.value })}
                  placeholder="e.g. 5-Axis Milling + Hard Anodizing Class 2"
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-white"
                />
              </div>

              <div>
                <label className="block text-slate-300 mb-1">Direct Message to Partner</label>
                <textarea
                  rows={2}
                  value={inviteForm.message}
                  onChange={(e) => setInviteForm({ ...inviteForm, message: e.target.value })}
                  placeholder="Add custom notes regarding batch timelines, tooling fixture details..."
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-white"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setInviteModalOpen(false)}
                  className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={inviteLoading}
                  className="px-4 py-2 bg-teal-600 hover:bg-teal-500 text-white rounded-lg font-semibold disabled:opacity-50"
                >
                  {inviteLoading ? "Sending..." : "Dispatch Invitation"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
