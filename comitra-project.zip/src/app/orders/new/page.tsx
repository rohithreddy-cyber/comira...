"use client";

import React, { useState } from "react";
import { useRouter } from "next/navigation";
import { useAuth } from "@/context/AuthContext";
import {
  Layers,
  Factory,
  ArrowRight,
  AlertCircle,
  HelpCircle,
  Info,
  Calendar,
  Sparkles,
} from "lucide-react";

export default function NewOrderPage() {
  const router = useRouter();
  const { user } = useAuth();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const availableCapacity = user?.business?.availableCapacity ?? 10000;
  const capacityUnit = user?.business?.capacityUnit ?? "units/month";

  const [formData, setFormData] = useState({
    title: "",
    description: "",
    category: "CNC Machining & Metal Fabrication",
    totalQuantity: 10000,
    quantityUnit: "units",
    targetUnitCost: 450,
    deadline: new Date(Date.now() + 45 * 24 * 60 * 60 * 1000).toISOString().split("T")[0],
    deliveryLocation: "Industrial Logistics Hub, Bengaluru",
    technicalSpecs: "Material: Alloy Steel / Aluminum 7075; Tolerance: ±0.005mm; Surface roughness: Ra 0.4 um.",
    qualityRequirements: "ISO 9001:2015 or AS9100D required. 100% CMM report and Ultrasonic testing.",
    requiredCapabilities: "CNC Machining, Heat Treatment, Surface Finishing",
    selfAllocatedQty: Math.min(6000, availableCapacity),
  });

  const remainingForCollab = Math.max(0, formData.totalQuantity - formData.selfAllocatedQty);
  const totalBudget = formData.totalQuantity * formData.targetUnitCost;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (formData.selfAllocatedQty > availableCapacity) {
      setError(
        `In-house allocation (${formData.selfAllocatedQty.toLocaleString()}) exceeds your remaining capacity (${availableCapacity.toLocaleString()} ${capacityUnit}). Please reduce in-house quantity or expand capacity.`
      );
      return;
    }

    if (formData.selfAllocatedQty > formData.totalQuantity) {
      setError("In-house allocation cannot exceed total order quantity.");
      return;
    }

    setLoading(true);
    try {
      const res = await fetch("/api/orders", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(formData),
      });

      const data = await res.json();
      setLoading(false);

      if (!res.ok) {
        setError(data.error || "Failed to create order");
        return;
      }

      router.push(`/orders/${data.order.id}`);
    } catch (err: any) {
      setLoading(false);
      setError(err.message || "Network error");
    }
  };

  return (
    <div className="max-w-3xl mx-auto py-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white flex items-center gap-2">
            <Layers className="w-6 h-6 text-teal-400" />
            Publish Bulk Manufacturing Order
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Specify technical details, allocate in-house capacity, and initiate collaborative partner matching
          </p>
        </div>
      </div>

      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 sm:p-8 shadow-xl space-y-6">
        {error && (
          <div className="p-3 rounded-lg bg-red-950/80 border border-red-800 text-red-200 text-xs flex items-center gap-2">
            <AlertCircle className="w-4 h-4 flex-shrink-0" />
            <span>{error}</span>
          </div>
        )}

        {/* Capacity Alert Box */}
        <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 flex items-start gap-3">
          <Info className="w-5 h-5 text-teal-400 flex-shrink-0 mt-0.5" />
          <div className="text-xs space-y-1">
            <p className="text-slate-200 font-semibold">
              Current Available In-House Capacity:{" "}
              <span className="text-teal-400 font-bold">
                {availableCapacity.toLocaleString()} {capacityUnit}
              </span>
            </p>
            <p className="text-slate-400">
              If your order size exceeds your available machines, allocate what you can build internally. CoMitra will
              automatically discover suitable manufacturing partners for the remainder ({remainingForCollab.toLocaleString()}{" "}
              units).
            </p>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="space-y-4">
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">Order Title / Component Name</label>
              <input
                type="text"
                required
                placeholder="e.g. 10,000 Units: Aircraft High-Pressure Hydraulic Actuator Housings"
                value={formData.title}
                onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-sm text-white focus:outline-none focus:border-teal-500"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">Detailed Description & Project Context</label>
              <textarea
                required
                rows={3}
                placeholder="Describe component function, end client application, and project urgency..."
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-sm text-white focus:outline-none focus:border-teal-500"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">Manufacturing Category</label>
                <select
                  value={formData.category}
                  onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-sm text-white focus:outline-none focus:border-teal-500"
                >
                  <option value="CNC Machining & Metal Fabrication">CNC Machining & Metal Fabrication</option>
                  <option value="Forging, Casting & Heat Treatment">Forging, Casting & Heat Treatment</option>
                  <option value="Precision Tooling & Stamping">Precision Tooling & Stamping</option>
                  <option value="Plastics & Injection Molding">Plastics & Injection Molding</option>
                  <option value="Additive Manufacturing & 3D Printing">Additive Manufacturing & 3D Printing</option>
                  <option value="Electronics & PCB Assembly">Electronics & PCB Assembly</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">Target Delivery Location</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. HAL Aerospace Logistics Hub, Bengaluru"
                  value={formData.deliveryLocation}
                  onChange={(e) => setFormData({ ...formData, deliveryLocation: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-sm text-white focus:outline-none focus:border-teal-500"
                />
              </div>
            </div>

            {/* Quantities & Capacity Split */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 p-4 rounded-xl bg-slate-950/60 border border-slate-800">
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">Total Order Quantity</label>
                <input
                  type="number"
                  required
                  min="1"
                  value={formData.totalQuantity}
                  onChange={(e) => setFormData({ ...formData, totalQuantity: parseFloat(e.target.value) || 0 })}
                  className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-lg text-sm text-white font-mono focus:outline-none focus:border-teal-500"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  In-House Self-Allocation ({capacityUnit})
                </label>
                <input
                  type="number"
                  required
                  min="0"
                  max={formData.totalQuantity}
                  value={formData.selfAllocatedQty}
                  onChange={(e) => setFormData({ ...formData, selfAllocatedQty: parseFloat(e.target.value) || 0 })}
                  className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-lg text-sm text-white font-mono focus:outline-none focus:border-teal-500"
                />
                <span className="text-[10px] text-teal-400">Your available: {availableCapacity.toLocaleString()}</span>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">Open for Collaboration</label>
                <div className="px-3 py-2 bg-slate-900/80 border border-teal-500/30 rounded-lg text-sm font-mono text-teal-300 font-bold">
                  {remainingForCollab.toLocaleString()} {formData.quantityUnit}
                </div>
                <span className="text-[10px] text-slate-400">Eligible for partner matching</span>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">Target Unit Price (₹)</label>
                <input
                  type="number"
                  required
                  min="0.1"
                  step="0.01"
                  value={formData.targetUnitCost}
                  onChange={(e) => setFormData({ ...formData, targetUnitCost: parseFloat(e.target.value) || 0 })}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-sm text-white focus:outline-none focus:border-teal-500"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">Calculated Total Budget</label>
                <div className="px-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-sm font-mono text-slate-200">
                  ₹{totalBudget.toLocaleString()}
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">Final Delivery Deadline</label>
                <input
                  type="date"
                  required
                  value={formData.deadline}
                  onChange={(e) => setFormData({ ...formData, deadline: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-sm text-white focus:outline-none focus:border-teal-500"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">
                Required Capabilities (Comma Separated for Matching Engine)
              </label>
              <input
                type="text"
                required
                placeholder="e.g. CNC Machining, Heat Treatment, Surface Finishing"
                value={formData.requiredCapabilities}
                onChange={(e) => setFormData({ ...formData, requiredCapabilities: e.target.value })}
                className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-sm text-white focus:outline-none focus:border-teal-500"
              />
              <p className="text-[10px] text-slate-400 mt-1">
                The algorithmic matching engine compares these keywords with candidate capabilities.
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">Technical Specifications</label>
                <textarea
                  required
                  rows={2}
                  value={formData.technicalSpecs}
                  onChange={(e) => setFormData({ ...formData, technicalSpecs: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-xs text-white focus:outline-none focus:border-teal-500"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">Quality Requirements & Standards</label>
                <textarea
                  required
                  rows={2}
                  value={formData.qualityRequirements}
                  onChange={(e) => setFormData({ ...formData, qualityRequirements: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-xs text-white focus:outline-none focus:border-teal-500"
                />
              </div>
            </div>
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full py-3 rounded-lg bg-teal-600 hover:bg-teal-500 text-white font-semibold text-sm transition shadow-lg shadow-teal-900/30 flex items-center justify-center gap-2 disabled:opacity-50"
          >
            {loading ? "Publishing Order..." : "Publish Bulk Order & Run Matching Engine"}
            <ArrowRight className="w-4 h-4" />
          </button>
        </form>
      </div>
    </div>
  );
}
