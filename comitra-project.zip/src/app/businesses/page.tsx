"use client";

import React, { useState, useEffect } from "react";
import {
  Search,
  Factory,
  ShieldCheck,
  Cpu,
  MapPin,
  Star,
  CheckCircle2,
  ExternalLink,
  Sliders,
} from "lucide-react";

export default function BusinessDirectoryPage() {
  const [businesses, setBusinesses] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [category, setCategory] = useState("");
  const [location, setLocation] = useState("");

  const loadBusinesses = async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams();
      if (search) params.set("search", search);
      if (category) params.set("category", category);
      if (location) params.set("location", location);

      const res = await fetch(`/api/businesses?${params.toString()}`);
      const data = await res.json();
      setBusinesses(data.businesses || []);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadBusinesses();
  }, [search, category, location]);

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl">
        <div>
          <h1 className="text-2xl font-bold text-white flex items-center gap-2">
            <Search className="w-6 h-6 text-teal-400" />
            Industrial Partner Directory
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Discover verified manufacturing units, browse certified machine capabilities, and assess available capacity
          </p>
        </div>
      </div>

      {/* Filter Bar */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 flex flex-wrap items-center gap-3 shadow">
        <div className="relative flex-1 min-w-[200px]">
          <Search className="w-4 h-4 text-slate-500 absolute left-3 top-2.5" />
          <input
            type="text"
            placeholder="Search business name, capability, or machine..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-9 pr-3 py-1.5 bg-slate-950 border border-slate-700 rounded-lg text-xs text-white placeholder-slate-500 focus:outline-none focus:border-teal-500"
          />
        </div>

        <select
          value={category}
          onChange={(e) => setCategory(e.target.value)}
          className="px-3 py-1.5 bg-slate-950 border border-slate-700 rounded-lg text-xs text-white focus:outline-none focus:border-teal-500"
        >
          <option value="">All Categories</option>
          <option value="CNC Machining & Metal Fabrication">CNC Machining & Metal Fabrication</option>
          <option value="Additive Manufacturing & Plastics">Additive Manufacturing & Plastics</option>
          <option value="Industrial Administration">Industrial Administration</option>
        </select>

        <input
          type="text"
          placeholder="Location (e.g. Pune, Gujarat, Bengaluru)..."
          value={location}
          onChange={(e) => setLocation(e.target.value)}
          className="px-3 py-1.5 bg-slate-950 border border-slate-700 rounded-lg text-xs text-white placeholder-slate-500 focus:outline-none focus:border-teal-500"
        />
      </div>

      {/* Grid */}
      {loading ? (
        <div className="flex justify-center py-12">
          <div className="w-8 h-8 border-4 border-teal-500 border-t-transparent rounded-full animate-spin" />
        </div>
      ) : businesses.length === 0 ? (
        <div className="text-center py-16 bg-slate-900 border border-slate-800 rounded-2xl text-xs text-slate-500">
          No businesses found matching your criteria.
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {businesses.map((biz) => (
            <div
              key={biz.id}
              className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-4 hover:border-slate-700 transition flex flex-col justify-between"
            >
              <div className="space-y-3">
                <div className="flex justify-between items-start">
                  <div>
                    <div className="flex items-center gap-2">
                      <h3 className="text-base font-bold text-white">{biz.name}</h3>
                      {biz.verificationStatus === "VERIFIED" && (
                        <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-teal-500/10 text-teal-400 border border-teal-500/20 flex items-center gap-1">
                          <ShieldCheck className="w-3 h-3" /> Verified
                        </span>
                      )}
                    </div>
                    <p className="text-xs text-slate-400 flex items-center gap-1 mt-0.5">
                      <MapPin className="w-3 h-3 text-slate-500" />
                      {biz.location}
                    </p>
                  </div>

                  <div className="text-right">
                    <div className="flex items-center gap-1 text-amber-400 font-bold font-mono text-sm">
                      <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
                      {biz.trustScore}%
                    </div>
                    <span className="text-[10px] text-slate-500">
                      {biz.receivedReviews?.length || 0} verified review(s)
                    </span>
                  </div>
                </div>

                <p className="text-xs text-slate-400 line-clamp-2">{biz.description}</p>

                {/* Capabilities pills */}
                <div className="space-y-1">
                  <span className="text-[10px] uppercase font-semibold text-slate-500 tracking-wider">
                    Core Capabilities:
                  </span>
                  <div className="flex flex-wrap gap-1.5 text-[11px]">
                    {(biz.capabilities || []).map((cap: any) => (
                      <span
                        key={cap.id}
                        className="px-2 py-0.5 rounded bg-slate-950 border border-slate-800 text-slate-300"
                      >
                        {cap.capabilityName}
                        {cap.maxPrecision ? ` (${cap.maxPrecision})` : ""}
                      </span>
                    ))}
                  </div>
                </div>
              </div>

              <div className="pt-3 border-t border-slate-800/80 flex items-center justify-between text-xs">
                <div className="text-slate-400">
                  Available Capacity:{" "}
                  <strong className="text-teal-400 font-mono">
                    {biz.availableCapacity.toLocaleString()} {biz.capacityUnit}
                  </strong>
                </div>

                <a
                  href="/orders/new"
                  className="px-3 py-1.5 rounded-lg bg-teal-600/90 hover:bg-teal-500 text-white font-semibold transition"
                >
                  Invite to Order
                </a>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
