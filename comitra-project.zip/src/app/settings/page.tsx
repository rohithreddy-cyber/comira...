"use client";

import React from "react";
import { useAuth } from "@/context/AuthContext";
import { Sliders, Building, ShieldCheck, Mail, Key, Sparkles } from "lucide-react";

export default function SettingsPage() {
  const { user } = useAuth();

  return (
    <div className="max-w-3xl mx-auto space-y-6">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-2">
        <h1 className="text-2xl font-bold text-white flex items-center gap-2">
          <Sliders className="w-6 h-6 text-teal-400" />
          System Settings & Platform Preferences
        </h1>
        <p className="text-xs text-slate-400">
          Account security, organization details, and environment connection parameters
        </p>
      </div>

      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow space-y-4 text-xs">
        <h2 className="text-sm font-bold text-white">Active Session Credentials</h2>
        <div className="grid grid-cols-2 gap-4">
          <div>
            <span className="text-slate-400">User Identity:</span>
            <p className="font-semibold text-white mt-0.5">{user?.name}</p>
          </div>
          <div>
            <span className="text-slate-400">Account Email:</span>
            <p className="font-mono text-teal-400 mt-0.5">{user?.email}</p>
          </div>
          <div>
            <span className="text-slate-400">Role Privilege:</span>
            <p className="font-bold text-slate-200 mt-0.5">{user?.role}</p>
          </div>
          <div>
            <span className="text-slate-400">Assigned Entity:</span>
            <p className="font-semibold text-slate-200 mt-0.5">{user?.business?.name || "Regulatory Directorate"}</p>
          </div>
        </div>
      </div>

      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow space-y-4 text-xs">
        <h2 className="text-sm font-bold text-white flex items-center gap-1.5">
          <Sparkles className="w-4 h-4 text-teal-400" />
          Environment & External Integrations
        </h2>
        <div className="space-y-3 text-slate-300">
          <div className="flex justify-between items-center p-3 rounded-xl bg-slate-950 border border-slate-800">
            <div>
              <span className="font-semibold text-white">Database Engine</span>
              <p className="text-slate-400 text-[11px]">Prisma Relational ORM (PostgreSQL & SQLite compatible)</p>
            </div>
            <span className="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 text-[10px] font-bold">
              CONNECTED
            </span>
          </div>

          <div className="flex justify-between items-center p-3 rounded-xl bg-slate-950 border border-slate-800">
            <div>
              <span className="font-semibold text-white">Algorithmic Partner Matching Engine</span>
              <p className="text-slate-400 text-[11px]">Local deterministic rule-based evaluation (zero external API dependency)</p>
            </div>
            <span className="px-2 py-0.5 rounded bg-teal-500/20 text-teal-300 text-[10px] font-bold">
              ACTIVE
            </span>
          </div>

          <div className="flex justify-between items-center p-3 rounded-xl bg-slate-950 border border-slate-800">
            <div>
              <span className="font-semibold text-white">Optional Google Gemini AI Copilot</span>
              <p className="text-slate-400 text-[11px]">Provides executive narrative summaries if GEMINI_API_KEY is supplied</p>
            </div>
            <span className="px-2 py-0.5 rounded bg-slate-800 text-slate-400 text-[10px] font-mono">
              STANDBY / OPTIONAL
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}
