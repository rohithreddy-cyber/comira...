"use client";

import React, { useState, useEffect } from "react";
import { useAuth } from "@/context/AuthContext";
import {
  FileText,
  Printer,
  CheckCircle2,
  Clock,
  ArrowRight,
  ShieldCheck,
  Building,
  AlertTriangle,
} from "lucide-react";

export default function AgreementsPage() {
  const { user } = useAuth();
  const [agreements, setAgreements] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedAgreement, setSelectedAgreement] = useState<any>(null);
  const [signLoading, setSignLoading] = useState(false);
  const [msg, setMsg] = useState<{ text: string; error?: boolean } | null>(null);

  const loadAgreements = async () => {
    setLoading(true);
    try {
      const res = await fetch("/api/agreements");
      const data = await res.json();
      setAgreements(data.agreements || []);
      if ((data.agreements || []).length > 0 && !selectedAgreement) {
        setSelectedAgreement(data.agreements[0]);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadAgreements();
  }, [user]);

  const handleSign = async (agreementId: string) => {
    setSignLoading(true);
    setMsg(null);

    try {
      const res = await fetch("/api/agreements", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ agreementId, action: "SIGN" }),
      });

      const data = await res.json();
      setSignLoading(false);

      if (!res.ok) {
        setMsg({ text: data.error || "Failed to sign agreement", error: true });
        return;
      }

      setMsg({ text: "Agreement signed digitally! Audit timestamp registered." });
      loadAgreements();
      if (data.agreement) {
        setSelectedAgreement((prev: any) => ({ ...prev, ...data.agreement }));
      }
    } catch (err: any) {
      setSignLoading(false);
      setMsg({ text: err.message || "Network error", error: true });
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Banner (Hidden in Print) */}
      <div className="no-print flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl">
        <div>
          <h1 className="text-2xl font-bold text-white flex items-center gap-2">
            <FileText className="w-6 h-6 text-teal-400" />
            Digital Co-Manufacturing Agreements
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Printable legal-grade sub-contract specifications, electronic mutual acceptance logs, and revision records
          </p>
        </div>

        {selectedAgreement && (
          <button
            onClick={() => window.print()}
            className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold text-xs border border-slate-700 transition"
          >
            <Printer className="w-4 h-4 text-teal-400" />
            Print Agreement Document
          </button>
        )}
      </div>

      {msg && (
        <div
          className={`no-print p-4 rounded-xl text-xs flex items-center gap-2 shadow ${
            msg.error
              ? "bg-red-950/80 border border-red-800 text-red-200"
              : "bg-emerald-950/80 border border-emerald-800 text-emerald-200"
          }`}
        >
          {msg.error ? <AlertTriangle className="w-4 h-4" /> : <CheckCircle2 className="w-4 h-4" />}
          <span>{msg.text}</span>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Agreements Selector List (Hidden in Print) */}
        <div className="no-print space-y-3">
          <h2 className="text-sm font-bold text-white">Active Contract Documents</h2>
          {agreements.length === 0 ? (
            <p className="text-xs text-slate-500 py-6">No agreements recorded yet.</p>
          ) : (
            agreements.map((agr) => {
              const isSelected = selectedAgreement?.id === agr.id;
              return (
                <div
                  key={agr.id}
                  onClick={() => setSelectedAgreement(agr)}
                  className={`p-4 rounded-xl border text-xs cursor-pointer transition ${
                    isSelected
                      ? "bg-teal-950/40 border-teal-500/60 shadow"
                      : "bg-slate-900 border-slate-800 hover:border-slate-700"
                  }`}
                >
                  <div className="flex justify-between items-center mb-1">
                    <span className="font-mono text-teal-400 font-bold">{agr.agreementNumber}</span>
                    <span
                      className={`px-2 py-0.5 rounded text-[10px] font-semibold ${
                        agr.status === "ACCEPTED"
                          ? "bg-emerald-500/20 text-emerald-300"
                          : "bg-amber-500/20 text-amber-300"
                      }`}
                    >
                      {agr.status}
                    </span>
                  </div>
                  <h3 className="font-semibold text-white truncate">{agr.title}</h3>
                  <p className="text-[11px] text-slate-400 mt-1">
                    {agr.ownerBusiness?.name} ↔ {agr.partnerBusiness?.name}
                  </p>
                  <p className="text-[11px] text-slate-400">
                    Allocated: <strong>{agr.allocatedQuantity.toLocaleString()} units</strong> (₹
                    {agr.totalValue.toLocaleString()})
                  </p>
                </div>
              );
            })
          )}
        </div>

        {/* Printable Formal Agreement Document View */}
        <div className="lg:col-span-2">
          {selectedAgreement ? (
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-8 sm:p-10 shadow-2xl space-y-6 text-slate-200 print:bg-white print:text-black print:border-none print:shadow-none">
              {/* Document Header */}
              <div className="border-b border-slate-800 pb-6 print:border-black flex justify-between items-start">
                <div>
                  <div className="inline-block px-2.5 py-1 rounded bg-teal-500/20 text-teal-300 print:text-black print:border print:border-black font-mono text-[11px] font-bold">
                    OFFICIAL SUBCONTRACT RECORD: {selectedAgreement.agreementNumber}
                  </div>
                  <h2 className="text-xl sm:text-2xl font-bold text-white print:text-black mt-2">
                    {selectedAgreement.title}
                  </h2>
                  <p className="text-xs text-slate-400 print:text-gray-600 mt-1">
                    Order Reference: {selectedAgreement.order?.orderNumber} — {selectedAgreement.order?.title}
                  </p>
                </div>
                <div className="text-right">
                  <span
                    className={`px-3 py-1 rounded-full text-xs font-bold ${
                      selectedAgreement.status === "ACCEPTED"
                        ? "bg-emerald-500/20 text-emerald-300 print:text-black"
                        : "bg-amber-500/20 text-amber-300 print:text-black"
                    }`}
                  >
                    STATUS: {selectedAgreement.status}
                  </span>
                  <div className="text-[10px] text-slate-500 print:text-gray-500 mt-1">
                    CoMitra Digital Verification Protocol
                  </div>
                </div>
              </div>

              {/* Contracting Parties */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 p-4 rounded-xl bg-slate-950 border border-slate-800 print:bg-white print:border-gray-300 text-xs">
                <div>
                  <span className="text-[10px] uppercase font-bold text-teal-400 print:text-gray-700">
                    Primary / Lead Contractor
                  </span>
                  <h4 className="font-bold text-white print:text-black text-sm mt-0.5">
                    {selectedAgreement.ownerBusiness?.name}
                  </h4>
                  <p className="text-slate-400 print:text-gray-600 mt-1">
                    Location: {selectedAgreement.ownerBusiness?.location}
                  </p>
                  <p className="text-slate-400 print:text-gray-600">
                    Email: {selectedAgreement.ownerBusiness?.email}
                  </p>
                </div>

                <div>
                  <span className="text-[10px] uppercase font-bold text-blue-400 print:text-gray-700">
                    Collaborating Manufacturing Partner
                  </span>
                  <h4 className="font-bold text-white print:text-black text-sm mt-0.5">
                    {selectedAgreement.partnerBusiness?.name}
                  </h4>
                  <p className="text-slate-400 print:text-gray-600 mt-1">
                    Location: {selectedAgreement.partnerBusiness?.location}
                  </p>
                  <p className="text-slate-400 print:text-gray-600">
                    Email: {selectedAgreement.partnerBusiness?.email}
                  </p>
                </div>
              </div>

              {/* Scope & Financials */}
              <div className="grid grid-cols-3 gap-4 text-center text-xs p-4 rounded-xl bg-slate-950/60 border border-slate-800 print:bg-white print:border-gray-300">
                <div>
                  <span className="text-slate-400 print:text-gray-600">Subcontracted Quantity</span>
                  <div className="text-lg font-bold font-mono text-white print:text-black mt-1">
                    {selectedAgreement.allocatedQuantity.toLocaleString()} units
                  </div>
                </div>
                <div>
                  <span className="text-slate-400 print:text-gray-600">Agreed Unit Rate</span>
                  <div className="text-lg font-bold font-mono text-white print:text-black mt-1">
                    ₹{selectedAgreement.agreedUnitPrice.toFixed(2)}
                  </div>
                </div>
                <div>
                  <span className="text-slate-400 print:text-gray-600">Total Contract Value</span>
                  <div className="text-lg font-bold font-mono text-teal-400 print:text-black mt-1">
                    ₹{selectedAgreement.totalValue.toLocaleString()}
                  </div>
                </div>
              </div>

              {/* Full Terms Text */}
              <div className="space-y-2 text-xs">
                <h4 className="font-bold text-white print:text-black">Standard Industrial Subcontract Terms</h4>
                <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 print:bg-white print:border-gray-300 font-mono text-[11px] text-slate-300 print:text-black whitespace-pre-line leading-relaxed">
                  {selectedAgreement.termsText}
                </div>
              </div>

              {/* Digital Execution & Signature Timestamps */}
              <div className="pt-4 border-t border-slate-800 print:border-black grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                <div className="p-3 rounded-lg bg-slate-950 border border-slate-800 print:border-gray-300 space-y-1">
                  <span className="text-[10px] uppercase text-slate-400 print:text-gray-600">
                    Lead Contractor Sign-off
                  </span>
                  <div className="font-semibold text-white print:text-black">
                    {selectedAgreement.ownerSignedAt ? (
                      <span className="text-emerald-400 print:text-black flex items-center gap-1">
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        Signed on {new Date(selectedAgreement.ownerSignedAt).toLocaleString()}
                      </span>
                    ) : (
                      <span className="text-amber-400 print:text-gray-600">Pending Execution</span>
                    )}
                  </div>
                </div>

                <div className="p-3 rounded-lg bg-slate-950 border border-slate-800 print:border-gray-300 space-y-1">
                  <span className="text-[10px] uppercase text-slate-400 print:text-gray-600">
                    Partner Manufacturer Sign-off
                  </span>
                  <div className="font-semibold text-white print:text-black">
                    {selectedAgreement.partnerSignedAt ? (
                      <span className="text-emerald-400 print:text-black flex items-center gap-1">
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        Signed on {new Date(selectedAgreement.partnerSignedAt).toLocaleString()}
                      </span>
                    ) : (
                      <span className="text-amber-400 print:text-gray-600">Pending Execution</span>
                    )}
                  </div>
                </div>
              </div>

              {/* Action for Unsigned Agreement (Hidden in Print) */}
              {selectedAgreement.status !== "ACCEPTED" && (
                <div className="no-print pt-2 flex justify-end">
                  <button
                    onClick={() => handleSign(selectedAgreement.id)}
                    disabled={signLoading}
                    className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-teal-600 hover:bg-teal-500 text-white font-semibold text-xs shadow transition disabled:opacity-50"
                  >
                    <CheckCircle2 className="w-4 h-4" />
                    {signLoading ? "Registering Signature..." : "Digitally Sign Agreement"}
                  </button>
                </div>
              )}
            </div>
          ) : (
            <div className="text-center py-16 bg-slate-900 border border-slate-800 rounded-2xl text-xs text-slate-500">
              Select an agreement from the sidebar to view full document specifications.
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
