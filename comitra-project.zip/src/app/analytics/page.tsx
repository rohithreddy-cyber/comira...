"use client";

import React, { useState, useEffect } from "react";
import { useAuth } from "@/context/AuthContext";
import {
  BarChart3,
  Download,
  Sparkles,
  TrendingUp,
  CreditCard,
  Factory,
  Layers,
  Users,
  CheckCircle2,
  AlertCircle,
} from "lucide-react";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  LineChart,
  Line,
} from "recharts";

export default function AnalyticsPage() {
  const { user } = useAuth();
  const [data, setData] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [aiText, setAiText] = useState<string | null>(null);
  const [aiLoading, setAiLoading] = useState(false);

  useEffect(() => {
    fetch("/api/analytics")
      .then((res) => res.json())
      .then((d) => setData(d))
      .catch((e) => console.error(e))
      .finally(() => setLoading(false));
  }, [user]);

  const handleAiInsight = async () => {
    setAiLoading(true);
    try {
      const res = await fetch("/api/ai/insights", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          prompt: `Analyze the following manufacturing cluster metrics:\n- Active Orders: ${data?.metrics?.activeOrdersCount}\n- Monthly Utilization: ${data?.metrics?.utilizationRate}%\n- Invoiced Amount: ₹${data?.metrics?.totalInvoiced}\n- Collaboration Acceptance: ${data?.metrics?.collaborationSuccessRate}%\nProvide a concise 3-bullet strategic summary for production executives.`,
        }),
      });
      const resData = await res.json();
      setAiText(resData.text || "AI insight generated.");
    } catch (e: any) {
      setAiText("Unable to communicate with AI endpoint.");
    } finally {
      setAiLoading(false);
    }
  };

  const exportCSV = () => {
    if (!data) return;
    const monthly = data.monthlyData || [];
    let csv = "Month,Volume,Completed\n";
    monthly.forEach((m: any) => {
      csv += `${m.month},${m.volume},${m.completed}\n`;
    });

    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.setAttribute("href", url);
    link.setAttribute("download", `comitra_analytics_report_${Date.now()}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[50vh] space-y-4">
        <div className="w-10 h-10 border-4 border-teal-500 border-t-transparent rounded-full animate-spin" />
        <p className="text-sm text-slate-400">Loading business analytics & trend forecasts...</p>
      </div>
    );
  }

  const metrics = data?.metrics || {};
  const monthlyData = data?.monthlyData || [];
  const allocationDistribution = data?.allocationDistribution || [];
  const COLORS = ["#0d9488", "#3b82f6", "#6366f1", "#f59e0b"];

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl">
        <div>
          <h1 className="text-2xl font-bold text-white flex items-center gap-2">
            <BarChart3 className="w-6 h-6 text-teal-400" />
            Operations Analytics & Decision Intelligence
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Empirical throughput metrics, multi-vendor performance trends, and capacity utilization analytics
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={exportCSV}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold text-xs border border-slate-700 transition"
          >
            <Download className="w-4 h-4 text-teal-400" />
            Export CSV
          </button>

          <button
            onClick={handleAiInsight}
            disabled={aiLoading}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-teal-600 hover:bg-teal-500 text-white font-semibold text-xs shadow transition disabled:opacity-50"
          >
            <Sparkles className="w-4 h-4" />
            {aiLoading ? "Synthesizing..." : "Optional AI Copilot"}
          </button>
        </div>
      </div>

      {/* Optional AI Synthesis Box */}
      {aiText && (
        <div className="p-5 rounded-2xl bg-gradient-to-r from-teal-950/60 to-slate-900 border border-teal-500/30 space-y-2 shadow-xl">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-teal-300 flex items-center gap-1.5">
              <Sparkles className="w-4 h-4" /> CoMitra AI Industrial Copilot
            </span>
            <span className="text-[10px] text-slate-500">Google Gemini Integration</span>
          </div>
          <p className="text-xs text-slate-200 whitespace-pre-line leading-relaxed">{aiText}</p>
        </div>
      )}

      {/* KPI Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="p-5 rounded-xl bg-slate-900 border border-slate-800 shadow space-y-1">
          <span className="text-xs text-slate-400 uppercase tracking-wider">Utilization Rate</span>
          <div className="text-2xl font-bold font-mono text-teal-400">{metrics.utilizationRate}%</div>
          <p className="text-[11px] text-slate-500">Optimal zone for manufacturing</p>
        </div>

        <div className="p-5 rounded-xl bg-slate-900 border border-slate-800 shadow space-y-1">
          <span className="text-xs text-slate-400 uppercase tracking-wider">Collab Success</span>
          <div className="text-2xl font-bold font-mono text-blue-400">{metrics.collaborationSuccessRate}%</div>
          <p className="text-[11px] text-slate-500">Invitations accepted</p>
        </div>

        <div className="p-5 rounded-xl bg-slate-900 border border-slate-800 shadow space-y-1">
          <span className="text-xs text-slate-400 uppercase tracking-wider">Gross Invoiced</span>
          <div className="text-2xl font-bold font-mono text-white">
            ₹{((metrics.totalInvoiced || 0) / 100000).toFixed(2)}L
          </div>
          <p className="text-[11px] text-slate-500">Milestone billings</p>
        </div>

        <div className="p-5 rounded-xl bg-slate-900 border border-slate-800 shadow space-y-1">
          <span className="text-xs text-slate-400 uppercase tracking-wider">Trust Rating</span>
          <div className="text-2xl font-bold font-mono text-amber-400">{metrics.trustScore}%</div>
          <p className="text-[11px] text-slate-500">Verified platform standing</p>
        </div>
      </div>

      {/* Charts Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Monthly Volume */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow space-y-4">
          <div>
            <h2 className="text-sm font-bold text-white">Scheduled vs Actual Output</h2>
            <p className="text-xs text-slate-400">Monthly component throughput</p>
          </div>
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={monthlyData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <XAxis dataKey="month" stroke="#64748b" fontSize={11} />
                <YAxis stroke="#64748b" fontSize={11} />
                <Tooltip
                  contentStyle={{ backgroundColor: "#0f172a", borderColor: "#334155", borderRadius: "0.5rem" }}
                  labelStyle={{ color: "#fff", fontWeight: "bold" }}
                />
                <Bar dataKey="volume" fill="#1e293b" name="Target Units" radius={[4, 4, 0, 0]} />
                <Bar dataKey="completed" fill="#0d9488" name="Finished Units" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Work Allocation Split */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow space-y-4">
          <div>
            <h2 className="text-sm font-bold text-white">Consortium Work Share Split</h2>
            <p className="text-xs text-slate-400">Component production distribution</p>
          </div>
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={allocationDistribution}
                  cx="50%"
                  cy="50%"
                  innerRadius={55}
                  outerRadius={85}
                  paddingAngle={4}
                  dataKey="value"
                >
                  {allocationDistribution.map((entry: any, index: number) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip
                  contentStyle={{ backgroundColor: "#0f172a", borderColor: "#334155", borderRadius: "0.5rem" }}
                />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </div>
  );
}
