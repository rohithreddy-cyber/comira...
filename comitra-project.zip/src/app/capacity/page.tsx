"use client";

import React, { useState, useEffect } from "react";
import { useAuth } from "@/context/AuthContext";
import {
  Sliders,
  Factory,
  CheckCircle2,
  AlertTriangle,
  Cpu,
  Layers,
  ArrowRight,
  ShieldAlert,
} from "lucide-react";

export default function CapacityPage() {
  const { user, refreshUser } = useAuth();
  const [capacityData, setCapacityData] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [editTotal, setEditTotal] = useState(10000);
  const [editUnit, setEditUnit] = useState("units/month");
  const [updating, setUpdating] = useState(false);
  const [msg, setMsg] = useState<{ text: string; error?: boolean } | null>(null);

  const loadCapacity = async () => {
    setLoading(true);
    try {
      const res = await fetch("/api/capacity");
      const data = await res.json();
      setCapacityData(data);
      if (data.totalCapacity) {
        setEditTotal(data.totalCapacity);
        setEditUnit(data.capacityUnit);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadCapacity();
  }, [user]);

  const handleUpdate = async (e: React.FormEvent) => {
    e.preventDefault();
    setUpdating(true);
    setMsg(null);

    try {
      const res = await fetch("/api/capacity", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          totalCapacity: editTotal,
          availableCapacity: Math.max(0, editTotal - (capacityData?.committedCapacity || 0)),
          capacityUnit: editUnit,
        }),
      });

      const data = await res.json();
      setUpdating(false);

      if (!res.ok) {
        setMsg({ text: data.error || "Update failed", error: true });
        return;
      }

      setMsg({ text: "Production capacity and availability updated successfully!" });
      loadCapacity();
      refreshUser();
    } catch (err: any) {
      setUpdating(false);
      setMsg({ text: err.message || "Network error", error: true });
    }
  };

  if (loading && !capacityData) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[50vh] space-y-4">
        <div className="w-10 h-10 border-4 border-teal-500 border-t-transparent rounded-full animate-spin" />
        <p className="text-sm text-slate-400">Loading plant machine availability and capacity...</p>
      </div>
    );
  }

  const committed = capacityData?.committedCapacity || 0;
  const available = capacityData?.availableCapacity || 0;
  const total = capacityData?.totalCapacity || 1;
  const utilization = Math.min(100, Math.round((committed / total) * 100));

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl">
        <div>
          <h1 className="text-2xl font-bold text-white flex items-center gap-2">
            <Sliders className="w-6 h-6 text-teal-400" />
            Capacity & Machine Resource Management
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Maintain accurate factory throughput limits to prevent overbooking and enable algorithmic matching
          </p>
        </div>
      </div>

      {msg && (
        <div
          className={`p-4 rounded-xl text-xs flex items-center gap-2 shadow ${
            msg.error
              ? "bg-red-950/80 border border-red-800 text-red-200"
              : "bg-emerald-950/80 border border-emerald-800 text-emerald-200"
          }`}
        >
          {msg.error ? <AlertTriangle className="w-4 h-4" /> : <CheckCircle2 className="w-4 h-4" />}
          <span>{msg.text}</span>
        </div>
      )}

      {/* KPI Overview Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 shadow space-y-2">
          <span className="text-xs text-slate-400 uppercase tracking-wider font-semibold">Total Rated Capacity</span>
          <div className="text-3xl font-bold font-mono text-white">
            {total.toLocaleString()}{" "}
            <span className="text-sm font-sans font-normal text-slate-400">{capacityData?.capacityUnit}</span>
          </div>
          <p className="text-[11px] text-slate-500">Maximum monthly factory output across operational lines</p>
        </div>

        <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 shadow space-y-2">
          <span className="text-xs text-slate-400 uppercase tracking-wider font-semibold">Committed Production</span>
          <div className="text-3xl font-bold font-mono text-blue-400">
            {committed.toLocaleString()}{" "}
            <span className="text-sm font-sans font-normal text-slate-400">{capacityData?.capacityUnit}</span>
          </div>
          <p className="text-[11px] text-slate-500">Locked in confirmed subcontract orders ({utilization}% utilized)</p>
        </div>

        <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 shadow space-y-2">
          <span className="text-xs text-slate-400 uppercase tracking-wider font-semibold">Available for Collab</span>
          <div className="text-3xl font-bold font-mono text-teal-400">
            {available.toLocaleString()}{" "}
            <span className="text-sm font-sans font-normal text-slate-400">{capacityData?.capacityUnit}</span>
          </div>
          <p className="text-[11px] text-slate-500">Advertised to matching engine for incoming partner inquiries</p>
        </div>
      </div>

      {/* Utilization Visual Bar */}
      <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 shadow space-y-3">
        <div className="flex justify-between items-center text-xs">
          <span className="font-semibold text-white">Factory Utilization Indicator</span>
          <span className="font-mono text-teal-400 font-bold">{utilization}% Capacity Committed</span>
        </div>
        <div className="w-full bg-slate-950 h-3 rounded-full overflow-hidden border border-slate-800 flex">
          <div
            className="bg-blue-500 h-full transition-all"
            style={{ width: `${utilization}%` }}
            title={`Committed: ${committed}`}
          />
          <div
            className="bg-teal-500/40 h-full transition-all"
            style={{ width: `${100 - utilization}%` }}
            title={`Available: ${available}`}
          />
        </div>
        <div className="flex justify-between text-[11px] text-slate-400">
          <span>0 units</span>
          <span className="text-blue-400 font-medium">■ Committed ({committed.toLocaleString()})</span>
          <span className="text-teal-400 font-medium">■ Available ({available.toLocaleString()})</span>
          <span>{total.toLocaleString()} units</span>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Update Capacity Form */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow space-y-4">
          <h2 className="text-base font-bold text-white">Adjust Rated Capacity</h2>
          <p className="text-xs text-slate-400">
            Server enforces that rated capacity cannot be reduced below active committed allocations (
            {committed.toLocaleString()}).
          </p>

          <form onSubmit={handleUpdate} className="space-y-4 text-xs">
            <div>
              <label className="block text-slate-300 mb-1">New Total Rated Capacity</label>
              <input
                type="number"
                required
                min={committed}
                value={editTotal}
                onChange={(e) => setEditTotal(parseFloat(e.target.value) || 0)}
                className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-white font-mono"
              />
              <span className="text-[10px] text-slate-400">Minimum allowed based on current orders: {committed}</span>
            </div>

            <div>
              <label className="block text-slate-300 mb-1">Measurement Unit</label>
              <input
                type="text"
                required
                value={editUnit}
                onChange={(e) => setEditUnit(e.target.value)}
                className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-white"
              />
            </div>

            <button
              type="submit"
              disabled={updating}
              className="w-full py-2.5 rounded-lg bg-teal-600 hover:bg-teal-500 text-white font-semibold shadow transition disabled:opacity-50"
            >
              {updating ? "Validating & Saving..." : "Update Factory Capacity"}
            </button>
          </form>
        </div>

        {/* Machine & Hardware Resources */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow space-y-4">
          <h2 className="text-base font-bold text-white flex items-center gap-2">
            <Cpu className="w-5 h-5 text-teal-400" />
            Machine & Line Inventory
          </h2>
          <p className="text-xs text-slate-400">Operational machines backing your verified production capacity.</p>

          <div className="space-y-2">
            {(capacityData?.resources || []).map((res: any) => (
              <div
                key={res.id}
                className="p-3 rounded-xl bg-slate-950 border border-slate-800 text-xs flex items-center justify-between"
              >
                <div>
                  <h4 className="font-semibold text-white">{res.resourceName}</h4>
                  <p className="text-[11px] text-slate-400">
                    Type: {res.resourceType} • Qty: {res.quantity} unit(s)
                  </p>
                </div>
                <div className="text-right">
                  <span className="px-2 py-0.5 rounded text-[10px] bg-teal-500/20 text-teal-300 font-semibold">
                    {res.operationalStatus}
                  </span>
                  <div className="text-[10px] text-slate-400 mt-1">{res.capacityPerHour} units/hr</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
