"use client";

import React, { useState, useEffect } from "react";
import { useAuth } from "@/context/AuthContext";
import {
  ShieldAlert,
  ShieldCheck,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  Building,
  Layers,
  History,
  Lock,
  Search,
} from "lucide-react";

export default function AdminPage() {
  const { user } = useAuth();
  const [data, setData] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [actionLoading, setActionLoading] = useState<string | null>(null);
  const [msg, setMsg] = useState<{ text: string; error?: boolean } | null>(null);
  const [tab, setTab] = useState<"verifications" | "businesses" | "audit">("verifications");

  const loadAdminData = async () => {
    setLoading(true);
    try {
      const res = await fetch("/api/admin");
      if (!res.ok) {
        throw new Error("Forbidden: Admin privileges required");
      }
      const adminData = await res.json();
      setData(adminData);
    } catch (e: any) {
      console.error(e);
      setMsg({ text: e.message || "Failed to load admin data", error: true });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadAdminData();
  }, [user]);

  const handleReviewVerification = async (verificationId: string, status: "APPROVED" | "REJECTED") => {
    setActionLoading(verificationId);
    setMsg(null);

    try {
      const res = await fetch("/api/admin", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          action: "REVIEW_VERIFICATION",
          verificationId,
          status,
          notes: `Decision recorded by Administrator ${user?.name || "Dr. Vikram Sethi"}`,
        }),
      });

      const resData = await res.json();
      setActionLoading(null);

      if (!res.ok) {
        setMsg({ text: resData.error || "Review action failed", error: true });
        return;
      }

      setMsg({ text: `Business verification marked as ${status}!` });
      loadAdminData();
    } catch (err: any) {
      setActionLoading(null);
      setMsg({ text: err.message || "Network error", error: true });
    }
  };

  const handleToggleSuspend = async (businessId: string) => {
    setActionLoading(businessId);
    setMsg(null);

    try {
      const res = await fetch("/api/admin", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          action: "TOGGLE_SUSPEND",
          businessId,
        }),
      });

      const resData = await res.json();
      setActionLoading(null);

      if (!res.ok) {
        setMsg({ text: resData.error || "Toggle failed", error: true });
        return;
      }

      setMsg({ text: "Business active status updated successfully!" });
      loadAdminData();
    } catch (err: any) {
      setActionLoading(null);
      setMsg({ text: err.message || "Network error", error: true });
    }
  };

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[50vh] space-y-4">
        <div className="w-10 h-10 border-4 border-amber-500 border-t-transparent rounded-full animate-spin" />
        <p className="text-sm text-slate-400">Authenticating administrative session...</p>
      </div>
    );
  }

  if (user?.role !== "ADMIN") {
    return (
      <div className="p-8 text-center bg-slate-900 border border-red-900/40 rounded-2xl max-w-md mx-auto space-y-4">
        <ShieldAlert className="w-12 h-12 text-red-400 mx-auto" />
        <h2 className="text-lg font-bold text-white">Access Denied: 403 Forbidden</h2>
        <p className="text-xs text-slate-400">
          This portal is reserved strictly for Platform Regulatory Administrators. Please sign in with administrator
          credentials or switch persona via the top banner.
        </p>
      </div>
    );
  }

  const verifications = data?.verifications || [];
  const businesses = data?.businesses || [];
  const auditEvents = data?.auditEvents || [];
  const summary = data?.summary || {};

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-slate-900 border border-amber-900/40 rounded-2xl p-6 shadow-xl">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-bold text-white flex items-center gap-2">
              <ShieldCheck className="w-6 h-6 text-amber-400" />
              National Regulatory & Administration Directorate
            </h1>
            <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-amber-500/20 text-amber-300 border border-amber-500/30">
              AUDITOR ACCESS
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Centralized KYC compliance verification, industrial cluster oversight, and immutable audit logs
          </p>
        </div>
      </div>

      {msg && (
        <div
          className={`p-4 rounded-xl text-xs flex items-center gap-2 shadow ${
            msg.error
              ? "bg-red-950/80 border border-red-800 text-red-200"
              : "bg-emerald-950/80 border border-emerald-800 text-emerald-200"
          }`}
        >
          {msg.error ? <AlertTriangle className="w-4 h-4" /> : <CheckCircle2 className="w-4 h-4" />}
          <span>{msg.text}</span>
        </div>
      )}

      {/* KPI Overview */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 shadow space-y-1">
          <span className="text-xs text-slate-400 uppercase tracking-wider">Registered Units</span>
          <div className="text-2xl font-bold font-mono text-white">{summary.totalBusinesses || 0}</div>
          <p className="text-[10px] text-slate-500">Verified MSMEs & Tier-1s</p>
        </div>

        <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 shadow space-y-1">
          <span className="text-xs text-slate-400 uppercase tracking-wider">Total Orders</span>
          <div className="text-2xl font-bold font-mono text-teal-400">{summary.totalOrders || 0}</div>
          <p className="text-[10px] text-slate-500">Published on platform</p>
        </div>

        <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 shadow space-y-1">
          <span className="text-xs text-slate-400 uppercase tracking-wider">Work Allocations</span>
          <div className="text-2xl font-bold font-mono text-blue-400">{summary.totalAllocations || 0}</div>
          <p className="text-[10px] text-slate-500">Subcontracts governed</p>
        </div>

        <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 shadow space-y-1">
          <span className="text-xs text-slate-400 uppercase tracking-wider">Tax Invoices</span>
          <div className="text-2xl font-bold font-mono text-amber-400">{summary.totalInvoices || 0}</div>
          <p className="text-[10px] text-slate-500">Milestone settlements</p>
        </div>
      </div>

      {/* Tab Navigation */}
      <div className="flex gap-2 border-b border-slate-800 pb-2 text-xs font-semibold">
        <button
          onClick={() => setTab("verifications")}
          className={`px-4 py-2 rounded-lg transition ${
            tab === "verifications" ? "bg-amber-600 text-white" : "text-slate-400 hover:text-slate-200"
          }`}
        >
          Compliance Queue ({verifications.length})
        </button>
        <button
          onClick={() => setTab("businesses")}
          className={`px-4 py-2 rounded-lg transition ${
            tab === "businesses" ? "bg-amber-600 text-white" : "text-slate-400 hover:text-slate-200"
          }`}
        >
          Registered Businesses ({businesses.length})
        </button>
        <button
          onClick={() => setTab("audit")}
          className={`px-4 py-2 rounded-lg transition ${
            tab === "audit" ? "bg-amber-600 text-white" : "text-slate-400 hover:text-slate-200"
          }`}
        >
          System Audit Logs ({auditEvents.length})
        </button>
      </div>

      {/* TAB 1: VERIFICATIONS QUEUE */}
      {tab === "verifications" && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-4">
          <h2 className="text-sm font-bold text-white">Business Verification Submissions</h2>
          <div className="space-y-3">
            {verifications.map((v: any) => (
              <div
                key={v.id}
                className="p-4 rounded-xl bg-slate-950 border border-slate-800 text-xs flex flex-col sm:flex-row sm:items-center justify-between gap-3"
              >
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="font-bold text-white">{v.business?.name}</h3>
                    <span
                      className={`px-2 py-0.5 rounded text-[10px] font-semibold ${
                        v.status === "APPROVED"
                          ? "bg-emerald-500/20 text-emerald-300"
                          : v.status === "REJECTED"
                          ? "bg-red-500/20 text-red-300"
                          : "bg-amber-500/20 text-amber-300"
                      }`}
                    >
                      {v.status}
                    </span>
                  </div>
                  <p className="text-slate-400 mt-1">
                    Document Type: <strong className="text-slate-200">{v.documentType}</strong> • ID:{" "}
                    <span className="font-mono text-teal-400">{v.documentNumber}</span>
                  </p>
                  {v.reviewerNotes && <p className="text-[11px] text-slate-500 italic mt-0.5">{v.reviewerNotes}</p>}
                </div>

                <div className="flex items-center gap-2">
                  {v.status === "PENDING" && (
                    <>
                      <button
                        onClick={() => handleReviewVerification(v.id, "REJECTED")}
                        disabled={actionLoading === v.id}
                        className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-red-900/60 text-slate-300 hover:text-red-300 transition"
                      >
                        Reject
                      </button>
                      <button
                        onClick={() => handleReviewVerification(v.id, "APPROVED")}
                        disabled={actionLoading === v.id}
                        className="px-4 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-semibold transition"
                      >
                        Approve & Verify
                      </button>
                    </>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 2: BUSINESSES & SUSPENSION */}
      {tab === "businesses" && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-4">
          <h2 className="text-sm font-bold text-white">Platform Business Registry</h2>
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-950 text-slate-400 uppercase text-[10px] border-b border-slate-800">
                <tr>
                  <th className="py-2.5 px-3">Business Name</th>
                  <th className="py-2.5 px-3">Reg. Number</th>
                  <th className="py-2.5 px-3">Location</th>
                  <th className="py-2.5 px-3">Capacity</th>
                  <th className="py-2.5 px-3">Verification</th>
                  <th className="py-2.5 px-3 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800">
                {businesses.map((b: any) => (
                  <tr key={b.id} className="hover:bg-slate-800/40">
                    <td className="py-3 px-3">
                      <div className="font-bold text-white">{b.name}</div>
                      <div className="text-[10px] text-slate-400">{b.category}</div>
                    </td>
                    <td className="py-3 px-3 font-mono text-teal-400">{b.registrationNumber}</td>
                    <td className="py-3 px-3 text-slate-300">{b.location}</td>
                    <td className="py-3 px-3 font-mono">
                      {b.availableCapacity.toLocaleString()} / {b.totalCapacity.toLocaleString()} {b.capacityUnit}
                    </td>
                    <td className="py-3 px-3">
                      <span
                        className={`px-2 py-0.5 rounded text-[10px] font-semibold ${
                          b.isSuspended
                            ? "bg-red-500/20 text-red-300"
                            : b.verificationStatus === "VERIFIED"
                            ? "bg-emerald-500/20 text-emerald-300"
                            : "bg-amber-500/20 text-amber-300"
                        }`}
                      >
                        {b.isSuspended ? "SUSPENDED" : b.verificationStatus}
                      </span>
                    </td>
                    <td className="py-3 px-3 text-right">
                      <button
                        onClick={() => handleToggleSuspend(b.id)}
                        disabled={actionLoading === b.id}
                        className={`px-2.5 py-1 rounded text-[11px] font-medium transition ${
                          b.isSuspended
                            ? "bg-emerald-700 hover:bg-emerald-600 text-white"
                            : "bg-slate-800 hover:bg-red-900/60 text-slate-300 hover:text-red-300"
                        }`}
                      >
                        {b.isSuspended ? "Reinstate" : "Suspend"}
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 3: AUDIT EVENTS */}
      {tab === "audit" && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-4">
          <h2 className="text-sm font-bold text-white">Immutable Platform Audit Trail (Last 100 Events)</h2>
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-950 text-slate-400 uppercase text-[10px] border-b border-slate-800">
                <tr>
                  <th className="py-2 px-3">Timestamp</th>
                  <th className="py-2 px-3">Event Type</th>
                  <th className="py-2 px-3">Action</th>
                  <th className="py-2 px-3">Actor</th>
                  <th className="py-2 px-3">Target</th>
                  <th className="py-2 px-3">Payload Details</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800 font-mono text-[11px]">
                {auditEvents.map((evt: any) => (
                  <tr key={evt.id} className="hover:bg-slate-800/40">
                    <td className="py-2 px-3 text-slate-400">{new Date(evt.createdAt).toLocaleString()}</td>
                    <td className="py-2 px-3 text-teal-400 font-bold">{evt.eventType}</td>
                    <td className="py-2 px-3 text-white font-semibold">{evt.action}</td>
                    <td className="py-2 px-3 text-slate-300">{evt.actorName}</td>
                    <td className="py-2 px-3 text-slate-400">
                      {evt.targetType} ({evt.targetId.slice(0, 8)}...)
                    </td>
                    <td className="py-2 px-3 text-slate-500 truncate max-w-xs">{evt.metadataJson || "—"}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}
