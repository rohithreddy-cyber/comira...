"use client";

import React, { useState } from "react";
import { useRouter } from "next/navigation";
import { useAuth } from "@/context/AuthContext";
import { Factory, Lock, Mail, ArrowRight, ShieldCheck, AlertCircle } from "lucide-react";

export default function LoginPage() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const { login, switchDemoUser } = useAuth();
  const router = useRouter();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);

    const result = await login(email, password);
    setLoading(false);

    if (result.success) {
      router.push("/dashboard");
    } else {
      setError(result.error || "Login failed");
    }
  };

  return (
    <div className="max-w-md mx-auto py-10 space-y-8">
      <div className="text-center space-y-2">
        <div className="w-12 h-12 rounded-xl bg-teal-600 flex items-center justify-center text-white mx-auto shadow-lg shadow-teal-900/30">
          <Factory className="w-7 h-7" />
        </div>
        <h1 className="text-2xl font-bold text-white">Sign In to CoMitra</h1>
        <p className="text-xs text-slate-400">Access your collaborative manufacturing workspace</p>
      </div>

      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 sm:p-8 shadow-xl space-y-6">
        {error && (
          <div className="p-3 rounded-lg bg-red-950/80 border border-red-800 text-red-200 text-xs flex items-center gap-2">
            <AlertCircle className="w-4 h-4 flex-shrink-0" />
            <span>{error}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1">Business Email Address</label>
            <div className="relative">
              <Mail className="w-4 h-4 text-slate-500 absolute left-3 top-3" />
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="name@company.com"
                className="w-full pl-9 pr-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-sm text-white placeholder-slate-500 focus:outline-none focus:border-teal-500"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1">Password</label>
            <div className="relative">
              <Lock className="w-4 h-4 text-slate-500 absolute left-3 top-3" />
              <input
                type="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full pl-9 pr-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-sm text-white placeholder-slate-500 focus:outline-none focus:border-teal-500"
              />
            </div>
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full py-2.5 rounded-lg bg-teal-600 hover:bg-teal-500 text-white font-semibold text-sm transition shadow-lg shadow-teal-900/30 flex items-center justify-center gap-2 disabled:opacity-50"
          >
            {loading ? "Signing in..." : "Sign In"}
            <ArrowRight className="w-4 h-4" />
          </button>
        </form>

        <div className="relative">
          <div className="absolute inset-0 flex items-center">
            <div className="w-full border-t border-slate-800" />
          </div>
          <div className="relative flex justify-center text-xs uppercase">
            <span className="bg-slate-900 px-2 text-slate-500 font-semibold">Demonstration Quick Logins</span>
          </div>
        </div>

        {/* Demo Fast Login Buttons */}
        <div className="space-y-2">
          <button
            type="button"
            onClick={() => switchDemoUser("OWNER")}
            className="w-full py-2 px-3 text-xs rounded-lg bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-200 flex items-center justify-between transition"
          >
            <span className="font-medium">Apex Precision (Order Owner)</span>
            <span className="text-[10px] text-teal-400">owner@apex.com</span>
          </button>
          <button
            type="button"
            onClick={() => switchDemoUser("PARTNER_B")}
            className="w-full py-2 px-3 text-xs rounded-lg bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-200 flex items-center justify-between transition"
          >
            <span className="font-medium">Bharat ForgeWorks (Partner 1)</span>
            <span className="text-[10px] text-blue-400">partner@bharatforge.com</span>
          </button>
          <button
            type="button"
            onClick={() => switchDemoUser("PARTNER_C")}
            className="w-full py-2 px-3 text-xs rounded-lg bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-200 flex items-center justify-between transition"
          >
            <span className="font-medium">Crestline Dynamics (Partner 2)</span>
            <span className="text-[10px] text-indigo-400">partner@crestline.com</span>
          </button>
          <button
            type="button"
            onClick={() => switchDemoUser("ADMIN")}
            className="w-full py-2 px-3 text-xs rounded-lg bg-amber-950/40 hover:bg-amber-900/60 border border-amber-800/60 text-amber-200 flex items-center justify-between transition"
          >
            <span className="font-medium">Regulatory Administrator</span>
            <span className="text-[10px] text-amber-300">admin@comitra.gov.in</span>
          </button>
        </div>

        <p className="text-center text-xs text-slate-400">
          New manufacturing business?{" "}
          <a href="/register" className="text-teal-400 hover:text-teal-300 font-semibold underline">
            Register business profile
          </a>
        </p>
      </div>
    </div>
  );
}
