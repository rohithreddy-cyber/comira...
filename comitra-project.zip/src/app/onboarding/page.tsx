"use client";

import React, { useState } from "react";
import { useRouter } from "next/navigation";
import { useAuth } from "@/context/AuthContext";
import { Factory, CheckCircle2, ArrowRight, Sliders, Cpu, ShieldCheck } from "lucide-react";

export default function OnboardingPage() {
  const router = useRouter();
  const { user, refreshUser } = useAuth();
  const [step, setStep] = useState(1);
  const [capability, setCapability] = useState({
    name: "CNC 5-Axis Milling",
    precision: "±0.005 mm",
    certifications: "ISO 9001:2015",
    leadTimeDays: 14,
  });

  return (
    <div className="max-w-xl mx-auto py-8 space-y-6">
      <div className="text-center space-y-2">
        <span className="text-xs uppercase tracking-wider font-semibold text-teal-400">Step {step} of 3</span>
        <h1 className="text-2xl font-bold text-white">Business Capacity Onboarding</h1>
        <p className="text-xs text-slate-400">Configure your initial production parameters for algorithmic matching</p>
      </div>

      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 sm:p-8 shadow-xl space-y-6">
        {step === 1 && (
          <div className="space-y-4 text-xs">
            <h2 className="text-sm font-bold text-white flex items-center gap-1.5">
              <Factory className="w-4 h-4 text-teal-400" />
              1. Primary Machining Capabilities
            </h2>
            <p className="text-slate-400">Specify your flagship production processes and precision tolerances.</p>

            <div className="space-y-3">
              <div>
                <label className="block text-slate-300 mb-1">Process Name</label>
                <input
                  type="text"
                  value={capability.name}
                  onChange={(e) => setCapability({ ...capability, name: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-white"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 mb-1">Max Precision Tolerance</label>
                  <input
                    type="text"
                    value={capability.precision}
                    onChange={(e) => setCapability({ ...capability, precision: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-white"
                  />
                </div>
                <div>
                  <label className="block text-slate-300 mb-1">Standard Lead Time (Days)</label>
                  <input
                    type="number"
                    value={capability.leadTimeDays}
                    onChange={(e) => setCapability({ ...capability, leadTimeDays: parseInt(e.target.value) || 0 })}
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-white"
                  />
                </div>
              </div>
            </div>

            <button
              onClick={() => setStep(2)}
              className="w-full py-2.5 rounded-lg bg-teal-600 hover:bg-teal-500 text-white font-semibold transition mt-4"
            >
              Continue to Machine Resources →
            </button>
          </div>
        )}

        {step === 2 && (
          <div className="space-y-4 text-xs">
            <h2 className="text-sm font-bold text-white flex items-center gap-1.5">
              <Cpu className="w-4 h-4 text-teal-400" />
              2. Installed Machinery & Shopfloor
            </h2>
            <p className="text-slate-400">Your machinery backed by verification records.</p>

            <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
              <div className="flex justify-between items-center text-white font-semibold">
                <span>Vertical Machining Center (VMC)</span>
                <span className="text-teal-400 font-mono">4 Lines</span>
              </div>
              <p className="text-[11px] text-slate-400">Equipped with automated tool changers and in-process probing.</p>
            </div>

            <button
              onClick={() => setStep(3)}
              className="w-full py-2.5 rounded-lg bg-teal-600 hover:bg-teal-500 text-white font-semibold transition mt-4"
            >
              Finalize Compliance & Launch →
            </button>
          </div>
        )}

        {step === 3 && (
          <div className="space-y-4 text-xs text-center py-4">
            <div className="w-12 h-12 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center mx-auto">
              <CheckCircle2 className="w-6 h-6" />
            </div>
            <h2 className="text-base font-bold text-white">Profile Ready for Collaboration</h2>
            <p className="text-slate-400 max-w-sm mx-auto">
              Your manufacturing unit is indexed. You can now publish large bulk orders or accept subcontracts.
            </p>

            <button
              onClick={() => router.push("/dashboard")}
              className="px-6 py-2.5 rounded-lg bg-teal-600 hover:bg-teal-500 text-white font-semibold shadow transition"
            >
              Enter Operations Dashboard
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
