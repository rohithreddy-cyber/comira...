"use client";

import React, { useState, useEffect } from "react";
import { useAuth } from "@/context/AuthContext";
import {
  Star,
  CheckCircle2,
  Building,
  Plus,
  AlertTriangle,
  MessageSquare,
  ShieldCheck,
} from "lucide-react";

export default function ReviewsPage() {
  const { user } = useAuth();
  const [reviews, setReviews] = useState<any[]>([]);
  const [orders, setOrders] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [modalOpen, setModalOpen] = useState(false);
  const [submitLoading, setSubmitLoading] = useState(false);
  const [msg, setMsg] = useState<{ text: string; error?: boolean } | null>(null);

  const [reviewForm, setReviewForm] = useState({
    orderId: "",
    revieweeBusinessId: "",
    score: 5,
    communicationRating: 5,
    qualityRating: 5,
    timelinessRating: 5,
    feedback: "",
  });

  const loadData = async () => {
    setLoading(true);
    try {
      const [revRes, ordRes] = await Promise.all([
        fetch("/api/reviews"),
        fetch("/api/orders?scope=mine"),
      ]);
      const revData = await revRes.json();
      const ordData = await ordRes.json();

      setReviews(revData.reviews || []);
      setOrders(ordData.orders || []);

      if ((ordData.orders || []).length > 0) {
        const firstOrder = ordData.orders[0];
        const partner = (firstOrder.allocations || []).find((a: any) => a.businessId !== user?.businessId);
        setReviewForm((prev) => ({
          ...prev,
          orderId: firstOrder.id,
          revieweeBusinessId: partner ? partner.businessId : firstOrder.ownerBusinessId,
        }));
      }
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, [user]);

  const handleSubmitReview = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitLoading(true);
    setMsg(null);

    try {
      const res = await fetch("/api/reviews", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(reviewForm),
      });

      const data = await res.json();
      setSubmitLoading(false);

      if (!res.ok) {
        setMsg({ text: data.error || "Failed to submit review", error: true });
        return;
      }

      setMsg({ text: "Verified review submitted successfully! Trust score updated." });
      setModalOpen(false);
      loadData();
    } catch (err: any) {
      setSubmitLoading(false);
      setMsg({ text: err.message || "Network error", error: true });
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl">
        <div>
          <h1 className="text-2xl font-bold text-white flex items-center gap-2">
            <Star className="w-6 h-6 text-amber-400" />
            Verified Collaboration Trust & Ratings
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Empirical peer evaluations restricted to confirmed manufacturing partners on completed order batches
          </p>
        </div>

        <button
          onClick={() => setModalOpen(true)}
          className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-teal-600 hover:bg-teal-500 text-white font-semibold text-xs shadow transition"
        >
          <Plus className="w-4 h-4" />
          Review Partner
        </button>
      </div>

      {msg && (
        <div
          className={`p-4 rounded-xl text-xs flex items-center gap-2 shadow ${
            msg.error
              ? "bg-red-950/80 border border-red-800 text-red-200"
              : "bg-emerald-950/80 border border-emerald-800 text-emerald-200"
          }`}
        >
          {msg.error ? <AlertTriangle className="w-4 h-4" /> : <CheckCircle2 className="w-4 h-4" />}
          <span>{msg.text}</span>
        </div>
      )}

      {/* Reviews List */}
      <div className="space-y-4">
        {loading ? (
          <div className="flex justify-center py-12">
            <div className="w-8 h-8 border-4 border-teal-500 border-t-transparent rounded-full animate-spin" />
          </div>
        ) : reviews.length === 0 ? (
          <p className="text-xs text-slate-500 text-center py-12">No verified reviews recorded yet.</p>
        ) : (
          reviews.map((r) => (
            <div key={r.id} className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow space-y-3">
              <div className="flex justify-between items-start">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-white text-sm">{r.reviewerBusiness?.name}</span>
                    <span className="text-xs text-slate-500">→</span>
                    <span className="font-semibold text-teal-400 text-xs">Verified Partner</span>
                  </div>
                  <p className="text-[11px] text-slate-400 mt-0.5">
                    Order Ref: {r.order?.orderNumber} — {r.order?.title}
                  </p>
                </div>

                <div className="flex items-center gap-1 text-amber-400 font-bold font-mono">
                  <Star className="w-4 h-4 fill-amber-400" />
                  {r.score.toFixed(1)} / 5.0
                </div>
              </div>

              <p className="text-xs text-slate-300 leading-relaxed italic">“{r.feedback}”</p>

              <div className="flex flex-wrap items-center gap-4 text-[11px] text-slate-400 pt-2 border-t border-slate-800/80">
                <span>Communication: <strong className="text-slate-200">{r.communicationRating}★</strong></span>
                <span>Quality Compliance: <strong className="text-slate-200">{r.qualityRating}★</strong></span>
                <span>Timeliness: <strong className="text-slate-200">{r.timelinessRating}★</strong></span>
                <span className="ml-auto text-[10px] text-slate-500 font-mono">
                  {new Date(r.createdAt).toLocaleDateString()}
                </span>
              </div>
            </div>
          ))
        )}
      </div>

      {/* Submit Review Modal */}
      {modalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 max-w-lg w-full space-y-4 shadow-2xl">
            <div className="flex justify-between items-center border-b border-slate-800 pb-3">
              <h3 className="text-base font-bold text-white">Submit Verified Partner Review</h3>
              <button onClick={() => setModalOpen(false)} className="text-slate-400 hover:text-white">
                ✕
              </button>
            </div>

            <form onSubmit={handleSubmitReview} className="space-y-4 text-xs">
              <div>
                <label className="block text-slate-300 mb-1">Select Completed / Active Order</label>
                <select
                  value={reviewForm.orderId}
                  onChange={(e) => {
                    const sel = orders.find((o) => o.id === e.target.value);
                    if (sel) {
                      const partner = (sel.allocations || []).find((a: any) => a.businessId !== user?.businessId);
                      setReviewForm({
                        ...reviewForm,
                        orderId: sel.id,
                        revieweeBusinessId: partner ? partner.businessId : sel.ownerBusinessId,
                      });
                    }
                  }}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-white"
                >
                  {orders.map((o) => (
                    <option key={o.id} value={o.id}>
                      {o.orderNumber} — {o.title}
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 mb-1">Overall Rating (1 - 5 Stars)</label>
                  <input
                    type="number"
                    min="1"
                    max="5"
                    step="0.1"
                    required
                    value={reviewForm.score}
                    onChange={(e) => setReviewForm({ ...reviewForm, score: parseFloat(e.target.value) || 5 })}
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-white font-mono"
                  />
                </div>
                <div>
                  <label className="block text-slate-300 mb-1">Quality Inspection Rating</label>
                  <input
                    type="number"
                    min="1"
                    max="5"
                    step="0.1"
                    required
                    value={reviewForm.qualityRating}
                    onChange={(e) =>
                      setReviewForm({ ...reviewForm, qualityRating: parseFloat(e.target.value) || 5 })
                    }
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-white font-mono"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 mb-1">Communication Rating</label>
                  <input
                    type="number"
                    min="1"
                    max="5"
                    step="0.1"
                    required
                    value={reviewForm.communicationRating}
                    onChange={(e) =>
                      setReviewForm({ ...reviewForm, communicationRating: parseFloat(e.target.value) || 5 })
                    }
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-white font-mono"
                  />
                </div>
                <div>
                  <label className="block text-slate-300 mb-1">Timeliness Rating</label>
                  <input
                    type="number"
                    min="1"
                    max="5"
                    step="0.1"
                    required
                    value={reviewForm.timelinessRating}
                    onChange={(e) =>
                      setReviewForm({ ...reviewForm, timelinessRating: parseFloat(e.target.value) || 5 })
                    }
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-white font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-300 mb-1">Detailed Technical Feedback</label>
                <textarea
                  rows={3}
                  required
                  placeholder="Detail dimensional tolerances achieved, communication responsiveness, and overall collaboration experience..."
                  value={reviewForm.feedback}
                  onChange={(e) => setReviewForm({ ...reviewForm, feedback: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-white"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setModalOpen(false)}
                  className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={submitLoading}
                  className="px-4 py-2 bg-teal-600 hover:bg-teal-500 text-white rounded-lg font-semibold disabled:opacity-50"
                >
                  {submitLoading ? "Publishing..." : "Publish Verified Review"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
