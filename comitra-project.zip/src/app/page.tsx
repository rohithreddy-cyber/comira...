"use client";

import React from "react";
import { useAuth } from "@/context/AuthContext";
import {
  Factory,
  ArrowRight,
  ShieldCheck,
  Cpu,
  BarChart2,
  CheckCircle2,
  Users2,
  Layers,
  Sparkles,
  ExternalLink,
  ChevronRight,
  Lock,
} from "lucide-react";

export default function LandingPage() {
  const { user, switchDemoUser } = useAuth();

  return (
    <div className="space-y-16 py-6">
      {/* Hero Section */}
      <section className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-slate-900 via-slate-900 to-teal-950 border border-slate-800 p-8 sm:p-14 shadow-2xl">
        <div className="absolute top-0 right-0 -mt-10 -mr-10 w-96 h-96 bg-teal-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="max-w-3xl space-y-6 relative z-10">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-teal-500/10 border border-teal-500/30 text-teal-300 text-xs font-semibold">
            <Sparkles className="w-3.5 h-3.5" />
            Smart B2B Collaborative Manufacturing Platform
          </div>

          <h1 className="text-4xl sm:text-6xl font-extrabold tracking-tight text-white leading-tight">
            One Order. <br />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-teal-400 via-teal-200 to-cyan-400">
              Multiple Manufacturers.
            </span>{" "}
            <br />
            One Success.
          </h1>

          <p className="text-lg text-slate-300 leading-relaxed max-w-2xl">
            Never reject an order due to capacity limits again. CoMitra connects capable manufacturing businesses to
            distribute, coordinate, and fulfill massive customer orders collaboratively with transparent matching,
            enforced capacity rules, and digital milestones.
          </p>

          <div className="flex flex-wrap items-center gap-4 pt-4">
            {user ? (
              <a
                href="/dashboard"
                className="inline-flex items-center gap-2 px-6 py-3.5 rounded-xl bg-teal-600 hover:bg-teal-500 text-white font-semibold shadow-lg shadow-teal-900/40 transition text-sm"
              >
                Go to Workspace Dashboard
                <ArrowRight className="w-4 h-4" />
              </a>
            ) : (
              <>
                <a
                  href="/register"
                  className="inline-flex items-center gap-2 px-6 py-3.5 rounded-xl bg-teal-600 hover:bg-teal-500 text-white font-semibold shadow-lg shadow-teal-900/40 transition text-sm"
                >
                  Register Business
                  <ArrowRight className="w-4 h-4" />
                </a>
                <a
                  href="/login"
                  className="inline-flex items-center gap-2 px-6 py-3.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold border border-slate-700 transition text-sm"
                >
                  Sign In to Account
                </a>
              </>
            )}
            <a
              href="#demo-scenario"
              className="inline-flex items-center gap-1.5 px-4 py-3.5 text-sm font-medium text-teal-400 hover:text-teal-300 underline underline-offset-4"
            >
              View Live Demo Scenario
            </a>
          </div>
        </div>
      </section>

      {/* Live Demonstration Persona Cards */}
      <section id="demo-scenario" className="space-y-6">
        <div className="border-b border-slate-800 pb-4">
          <span className="text-xs uppercase tracking-wider font-semibold text-teal-400">
            Interactive College Project Evaluation
          </span>
          <h2 className="text-2xl font-bold text-white mt-1">Experience the Complete Co-Manufacturing Workflow</h2>
          <p className="text-sm text-slate-400">
            Click any persona below to instantaneously sign in and experience the platform from their perspective.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {/* Persona 1: Owner */}
          <div className="p-5 rounded-xl bg-slate-900/90 border border-slate-800 hover:border-teal-500/50 transition flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between mb-3">
                <span className="px-2 py-0.5 rounded text-[11px] font-semibold bg-teal-500/20 text-teal-300 border border-teal-500/30">
                  LEAD MANUFACTURER
                </span>
                <Factory className="w-5 h-5 text-teal-400" />
              </div>
              <h3 className="font-bold text-white text-base">Apex Precision Eng.</h3>
              <p className="text-xs text-slate-400 mt-1">
                Holds a 10,000 unit aerospace order. In-house capacity is 6,000 units. Discovers and coordinates partners.
              </p>
              <div className="mt-3 text-[11px] text-slate-400 space-y-1">
                <p>👤 Rohit Deshmukh (Owner)</p>
                <p>⚙️ 6,000 in-house + 4,000 shared</p>
              </div>
            </div>
            <button
              onClick={() => switchDemoUser("OWNER")}
              className="mt-4 w-full py-2 rounded-lg bg-teal-600/90 hover:bg-teal-500 text-white font-medium text-xs transition"
            >
              Sign In as Lead Owner
            </button>
          </div>

          {/* Persona 2: Partner B */}
          <div className="p-5 rounded-xl bg-slate-900/90 border border-slate-800 hover:border-teal-500/50 transition flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between mb-3">
                <span className="px-2 py-0.5 rounded text-[11px] font-semibold bg-blue-500/20 text-blue-300 border border-blue-500/30">
                  PARTNER 1
                </span>
                <Cpu className="w-5 h-5 text-blue-400" />
              </div>
              <h3 className="font-bold text-white text-base">Bharat ForgeWorks</h3>
              <p className="text-xs text-slate-400 mt-1">
                Specialized in VMC milling & hard anodizing. Accepted 2,500 units allocation.
              </p>
              <div className="mt-3 text-[11px] text-slate-400 space-y-1">
                <p>👤 Suresh Patel (Partner)</p>
                <p>⚙️ 1,800 / 2,500 units completed</p>
              </div>
            </div>
            <button
              onClick={() => switchDemoUser("PARTNER_B")}
              className="mt-4 w-full py-2 rounded-lg bg-blue-600/90 hover:bg-blue-500 text-white font-medium text-xs transition"
            >
              Sign In as Partner B
            </button>
          </div>

          {/* Persona 3: Partner C */}
          <div className="p-5 rounded-xl bg-slate-900/90 border border-slate-800 hover:border-teal-500/50 transition flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between mb-3">
                <span className="px-2 py-0.5 rounded text-[11px] font-semibold bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                  PARTNER 2
                </span>
                <Layers className="w-5 h-5 text-indigo-400" />
              </div>
              <h3 className="font-bold text-white text-base">Crestline Dynamics</h3>
              <p className="text-xs text-slate-400 mt-1">
                Specialized in sub-micron grinding. Accepted 1,500 units allocation in Peenya Bengaluru.
              </p>
              <div className="mt-3 text-[11px] text-slate-400 space-y-1">
                <p>👤 Ananya Rao (Partner)</p>
                <p>⚙️ 950 / 1,500 units completed</p>
              </div>
            </div>
            <button
              onClick={() => switchDemoUser("PARTNER_C")}
              className="mt-4 w-full py-2 rounded-lg bg-indigo-600/90 hover:bg-indigo-500 text-white font-medium text-xs transition"
            >
              Sign In as Partner C
            </button>
          </div>

          {/* Persona 4: Administrator */}
          <div className="p-5 rounded-xl bg-slate-900/90 border border-slate-800 hover:border-amber-500/50 transition flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between mb-3">
                <span className="px-2 py-0.5 rounded text-[11px] font-semibold bg-amber-500/20 text-amber-300 border border-amber-500/30">
                  PLATFORM REGULATOR
                </span>
                <ShieldCheck className="w-5 h-5 text-amber-400" />
              </div>
              <h3 className="font-bold text-white text-base">CoMitra Regulatory</h3>
              <p className="text-xs text-slate-400 mt-1">
                Oversees platform trust, compliance documents, audit trail, and verified business registries.
              </p>
              <div className="mt-3 text-[11px] text-slate-400 space-y-1">
                <p>👤 Dr. Vikram Sethi (Admin)</p>
                <p>🛡️ Real-time audit & KYC</p>
              </div>
            </div>
            <button
              onClick={() => switchDemoUser("ADMIN")}
              className="mt-4 w-full py-2 rounded-lg bg-amber-600/90 hover:bg-amber-500 text-white font-medium text-xs transition"
            >
              Sign In as Administrator
            </button>
          </div>
        </div>
      </section>

      {/* The 4-Step Collaborative Workflow */}
      <section className="space-y-8 bg-slate-900/50 border border-slate-800/80 rounded-2xl p-8">
        <div className="text-center max-w-2xl mx-auto space-y-2">
          <span className="text-xs uppercase tracking-wider font-semibold text-teal-400">Digital Protocol</span>
          <h2 className="text-2xl sm:text-3xl font-bold text-white">How CoMitra Works</h2>
          <p className="text-slate-400 text-sm">
            End-to-end transparent coordination from order receipt to multi-vendor delivery sign-off.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <div className="p-5 rounded-xl bg-slate-900 border border-slate-800 space-y-3">
            <div className="w-10 h-10 rounded-lg bg-teal-500/20 text-teal-300 flex items-center justify-center font-bold">
              1
            </div>
            <h3 className="font-semibold text-white">Publish Bulk Order</h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              Company enters order specifications, quantity, target unit price, and required machining capabilities.
              System validates whether in-house capacity is exceeded.
            </p>
          </div>

          <div className="p-5 rounded-xl bg-slate-900 border border-slate-800 space-y-3">
            <div className="w-10 h-10 rounded-lg bg-teal-500/20 text-teal-300 flex items-center justify-center font-bold">
              2
            </div>
            <h3 className="font-semibold text-white">Algorithmic Matching</h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              Transparent rule-based engine scores candidate partners on capability overlap, verified available
              capacity, deadline feasibility, certifications, and historical trust.
            </p>
          </div>

          <div className="p-5 rounded-xl bg-slate-900 border border-slate-800 space-y-3">
            <div className="w-10 h-10 rounded-lg bg-teal-500/20 text-teal-300 flex items-center justify-center font-bold">
              3
            </div>
            <h3 className="font-semibold text-white">Allocation & Agreements</h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              Invitations are sent and accepted. Quantities are transactionally locked so allocations never exceed total
              order size. Digital agreements are created with printable revision trails.
            </p>
          </div>

          <div className="p-5 rounded-xl bg-slate-900 border border-slate-800 space-y-3">
            <div className="w-10 h-10 rounded-lg bg-teal-500/20 text-teal-300 flex items-center justify-center font-bold">
              4
            </div>
            <h3 className="font-semibold text-white">Production & Invoicing</h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              Each manufacturer updates batch completions, delay logs, and quality check records. Milestone invoices
              are issued and settled in real time.
            </p>
          </div>
        </div>
      </section>

      {/* Trust & Features Highlights */}
      <section className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="p-6 rounded-xl bg-slate-900/70 border border-slate-800 space-y-2">
          <ShieldCheck className="w-6 h-6 text-teal-400" />
          <h3 className="font-semibold text-white">Explainable Matching</h3>
          <p className="text-xs text-slate-400 leading-relaxed">
            Every recommendation explains why a partner was scored, highlighting exact machine overlaps, lead times,
            and any operational limitations without black-box opacity.
          </p>
        </div>

        <div className="p-6 rounded-xl bg-slate-900/70 border border-slate-800 space-y-2">
          <Lock className="w-6 h-6 text-teal-400" />
          <h3 className="font-semibold text-white">Transactional Capacity Guard</h3>
          <p className="text-xs text-slate-400 leading-relaxed">
            Server-side database transactions prevent concurrent overbooking, negative capacity, or allocations
            exceeding order quantity boundaries.
          </p>
        </div>

        <div className="p-6 rounded-xl bg-slate-900/70 border border-slate-800 space-y-2">
          <BarChart2 className="w-6 h-6 text-teal-400" />
          <h3 className="font-semibold text-white">Real-Time Aggregated Progress</h3>
          <p className="text-xs text-slate-400 leading-relaxed">
            Order owners monitor overall completion percentage calculated cleanly from multiple distributed vendor
            streams with zero duplicate count risks.
          </p>
        </div>
      </section>
    </div>
  );
}
