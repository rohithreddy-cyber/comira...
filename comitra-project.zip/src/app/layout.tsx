import type { Metadata } from "next";
import "./globals.css";
import { AuthProvider } from "@/context/AuthContext";
import Navbar from "@/components/Navbar";

export const metadata: Metadata = {
  title: "CoMitra — Smart Collaborative Manufacturing Platform",
  description: "One Order. Multiple Manufacturers. One Success. Connect manufacturing businesses to fulfill large bulk orders collaboratively.",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body className="min-h-screen flex flex-col bg-slate-950 text-slate-100 antialiased selection:bg-teal-500 selection:text-white">
        <AuthProvider>
          <Navbar />
          <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6">
            {children}
          </main>
          <footer className="no-print bg-slate-900 border-t border-slate-800 text-slate-400 py-6 text-xs text-center">
            <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-4">
              <div>
                <p className="font-semibold text-slate-200">
                  CoMitra — Smart Collaborative Manufacturing Platform
                </p>
                <p className="text-[11px] text-teal-400">One Order. Multiple Manufacturers. One Success.</p>
              </div>
              <p className="text-slate-500">
                &copy; {new Date().getFullYear()} CoMitra Consortium. Built for Industrial Collaborative Excellence.
              </p>
            </div>
          </footer>
        </AuthProvider>
      </body>
    </html>
  );
}
