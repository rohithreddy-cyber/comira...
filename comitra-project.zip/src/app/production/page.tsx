"use client";

import React, { useState, useEffect } from "react";
import { useAuth } from "@/context/AuthContext";
import {
  Factory,
  CheckCircle2,
  AlertTriangle,
  Clock,
  ArrowRight,
  Plus,
  ShieldCheck,
  Calendar,
  Layers,
} from "lucide-react";

export default function ProductionPage() {
  const { user } = useAuth();
  const [updates, setUpdates] = useState<any[]>([]);
  const [allocations, setAllocations] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [modalOpen, setModalOpen] = useState(false);
  const [formLoading, setFormLoading] = useState(false);
  const [msg, setMsg] = useState<{ text: string; error?: boolean } | null>(null);

  const [formData, setFormData] = useState({
    workAllocationId: "",
    orderId: "",
    completedQuantity: 0,
    statusNote: "",
    delayDays: 0,
    delayReason: "",
    qualityPassed: true,
    qualityNotes: "",
  });

  const loadData = async () => {
    setLoading(true);
    try {
      const [upRes, ordRes] = await Promise.all([
        fetch("/api/production/updates"),
        fetch("/api/orders?scope=mine"),
      ]);
      const upData = await upRes.json();
      const ordData = await ordRes.json();

      setUpdates(upData.updates || []);

      // Extract all active allocations for the user's business
      const activeAllocs: any[] = [];
      for (const ord of ordData.orders || []) {
        for (const alloc of ord.allocations || []) {
          if (
            alloc.businessId === user?.businessId ||
            ord.ownerBusinessId === user?.businessId
          ) {
            activeAllocs.push({ ...alloc, orderTitle: ord.title, orderNumber: ord.orderNumber });
          }
        }
      }
      setAllocations(activeAllocs);
      if (activeAllocs.length > 0) {
        setFormData((prev) => ({
          ...prev,
          workAllocationId: activeAllocs[0].id,
          orderId: activeAllocs[0].orderId,
          completedQuantity: activeAllocs[0].completedQuantity,
        }));
      }
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, [user]);

  const handleSubmitUpdate = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormLoading(true);
    setMsg(null);

    try {
      const res = await fetch("/api/production/updates", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(formData),
      });

      const data = await res.json();
      setFormLoading(false);

      if (!res.ok) {
        setMsg({ text: data.error || "Failed to log update", error: true });
        return;
      }

      setMsg({ text: "Production milestone progress recorded successfully!" });
      setTimeout(() => {
        setModalOpen(false);
        loadData();
      }, 1200);
    } catch (err: any) {
      setFormLoading(false);
      setMsg({ text: err.message || "Network error", error: true });
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl">
        <div>
          <h1 className="text-2xl font-bold text-white flex items-center gap-2">
            <Factory className="w-6 h-6 text-teal-400" />
            Live Production Tracking & Milestones
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Real-time batch completions, CMM quality inspection reports, and early delay reporting
          </p>
        </div>

        <button
          onClick={() => {
            setMsg(null);
            setModalOpen(true);
          }}
          className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-teal-600 hover:bg-teal-500 text-white font-semibold text-xs shadow-lg shadow-teal-900/40 transition"
        >
          <Plus className="w-4 h-4" />
          Log Production Update
        </button>
      </div>

      {/* Active Work Streams */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-4">
        <h2 className="text-base font-bold text-white">Your Active Production Streams</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {allocations.map((alloc) => {
            const percent = Math.min(
              100,
              Math.round((alloc.completedQuantity / alloc.allocatedQuantity) * 100)
            );
            return (
              <div key={alloc.id} className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-3">
                <div className="flex justify-between items-start">
                  <div>
                    <span className="font-mono text-xs text-teal-400 font-bold">{alloc.orderNumber}</span>
                    <h3 className="font-bold text-white text-sm mt-0.5">{alloc.orderTitle}</h3>
                    <p className="text-[11px] text-slate-400">
                      Manufacturer: <strong className="text-slate-200">{alloc.business?.name || user?.business?.name}</strong>
                    </p>
                  </div>
                  <span
                    className={`px-2 py-0.5 rounded text-[10px] font-semibold ${
                      alloc.status === "COMPLETED"
                        ? "bg-emerald-500/20 text-emerald-300"
                        : "bg-teal-500/20 text-teal-300"
                    }`}
                  >
                    {alloc.status}
                  </span>
                </div>

                <div className="space-y-1">
                  <div className="flex justify-between text-xs text-slate-400">
                    <span>Progress</span>
                    <span className="text-white font-mono font-bold">
                      {alloc.completedQuantity.toLocaleString()} / {alloc.allocatedQuantity.toLocaleString()} ({percent}%)
                    </span>
                  </div>
                  <div className="w-full bg-slate-900 h-2 rounded-full overflow-hidden border border-slate-800">
                    <div className="bg-teal-500 h-full rounded-full transition-all" style={{ width: `${percent}%` }} />
                  </div>
                </div>

                <div className="flex justify-between items-center text-[11px] text-slate-400 pt-1">
                  <span>Target: {new Date(alloc.agreedDeadline).toLocaleDateString()}</span>
                  <button
                    onClick={() => {
                      setFormData((prev) => ({
                        ...prev,
                        workAllocationId: alloc.id,
                        orderId: alloc.orderId,
                        completedQuantity: alloc.completedQuantity,
                      }));
                      setModalOpen(true);
                    }}
                    className="text-teal-400 hover:text-teal-300 font-semibold"
                  >
                    Update Progress →
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Audit Log Feed of Production Updates */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-4">
        <h2 className="text-base font-bold text-white">Chronological Production Activity Log</h2>
        {updates.length === 0 ? (
          <p className="text-xs text-slate-500 text-center py-8">No production milestones logged yet.</p>
        ) : (
          <div className="space-y-3">
            {updates.map((up) => (
              <div key={up.id} className="p-4 rounded-xl bg-slate-950 border border-slate-800/80 text-xs space-y-2">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1">
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-white">{up.business?.name}</span>
                    <span className="font-mono text-teal-400">{up.order?.orderNumber}</span>
                  </div>
                  <span className="text-slate-500 font-mono text-[11px]">
                    {new Date(up.reportedDate).toLocaleString()}
                  </span>
                </div>

                <div className="flex items-center gap-3">
                  <span className="text-slate-300">
                    Cumulative Units: <strong className="text-white font-mono">{up.completedQuantity.toLocaleString()}</strong>
                  </span>
                  {up.qualityPassed ? (
                    <span className="flex items-center gap-1 text-emerald-400 font-semibold text-[11px]">
                      <CheckCircle2 className="w-3.5 h-3.5" /> Quality Verified
                    </span>
                  ) : (
                    <span className="flex items-center gap-1 text-red-400 font-semibold text-[11px]">
                      <AlertTriangle className="w-3.5 h-3.5" /> Inspection Issue Flagged
                    </span>
                  )}
                  {up.delayDays > 0 && (
                    <span className="flex items-center gap-1 text-amber-400 font-semibold text-[11px]">
                      <Clock className="w-3.5 h-3.5" /> Delay: {up.delayDays} day(s)
                    </span>
                  )}
                </div>

                {up.statusNote && <p className="text-slate-400">“{up.statusNote}”</p>}
                {up.delayReason && (
                  <p className="text-amber-300 font-mono text-[11px]">Delay Cause: {up.delayReason}</p>
                )}
                {up.qualityNotes && (
                  <p className="text-teal-300 font-mono text-[11px]">CMM Notes: {up.qualityNotes}</p>
                )}
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Log Update Modal */}
      {modalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 max-w-lg w-full space-y-4 shadow-2xl">
            <div className="flex justify-between items-center border-b border-slate-800 pb-3">
              <h3 className="text-base font-bold text-white">Record Production Milestone</h3>
              <button onClick={() => setModalOpen(false)} className="text-slate-400 hover:text-white">
                ✕
              </button>
            </div>

            {msg && (
              <div
                className={`p-3 rounded-lg text-xs ${
                  msg.error ? "bg-red-950/80 text-red-200" : "bg-emerald-950/80 text-emerald-200"
                }`}
              >
                {msg.text}
              </div>
            )}

            <form onSubmit={handleSubmitUpdate} className="space-y-4 text-xs">
              <div>
                <label className="block text-slate-300 mb-1">Select Active Allocation Line</label>
                <select
                  value={formData.workAllocationId}
                  onChange={(e) => {
                    const sel = allocations.find((a) => a.id === e.target.value);
                    if (sel) {
                      setFormData({
                        ...formData,
                        workAllocationId: sel.id,
                        orderId: sel.orderId,
                        completedQuantity: sel.completedQuantity,
                      });
                    }
                  }}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-white"
                >
                  {allocations.map((a) => (
                    <option key={a.id} value={a.id}>
                      {a.orderNumber} — {a.orderTitle} (Max: {a.allocatedQuantity.toLocaleString()})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-slate-300 mb-1">Cumulative Completed Units</label>
                <input
                  type="number"
                  required
                  min="0"
                  value={formData.completedQuantity}
                  onChange={(e) => setFormData({ ...formData, completedQuantity: parseFloat(e.target.value) || 0 })}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-white font-mono"
                />
              </div>

              <div>
                <label className="block text-slate-300 mb-1">Production Batch Notes</label>
                <textarea
                  rows={2}
                  placeholder="e.g. Batch 2 machining completed, 0.003mm variance verified."
                  value={formData.statusNote}
                  onChange={(e) => setFormData({ ...formData, statusNote: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-white"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 mb-1">Reported Delay (Days)</label>
                  <input
                    type="number"
                    min="0"
                    value={formData.delayDays}
                    onChange={(e) => setFormData({ ...formData, delayDays: parseInt(e.target.value) || 0 })}
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-white font-mono"
                  />
                </div>
                <div>
                  <label className="block text-slate-300 mb-1">Delay Reason (if any)</label>
                  <input
                    type="text"
                    placeholder="e.g. Spindle tool replacement"
                    value={formData.delayReason}
                    onChange={(e) => setFormData({ ...formData, delayReason: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-white"
                  />
                </div>
              </div>

              <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
                <label className="flex items-center gap-2 text-slate-300 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={formData.qualityPassed}
                    onChange={(e) => setFormData({ ...formData, qualityPassed: e.target.checked })}
                    className="accent-teal-500 w-4 h-4"
                  />
                  <span className="font-semibold text-white">Quality Inspection Cleared</span>
                </label>
                <input
                  type="text"
                  placeholder="CMM / Hydrostatic / Visual test findings..."
                  value={formData.qualityNotes}
                  onChange={(e) => setFormData({ ...formData, qualityNotes: e.target.value })}
                  className="w-full px-3 py-1.5 bg-slate-900 border border-slate-700 rounded-lg text-white text-[11px]"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setModalOpen(false)}
                  className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={formLoading}
                  className="px-4 py-2 bg-teal-600 hover:bg-teal-500 text-white rounded-lg font-semibold disabled:opacity-50"
                >
                  {formLoading ? "Recording..." : "Save Production Milestone"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
