"use client";

import React, { useState, useEffect } from "react";
import { useAuth } from "@/context/AuthContext";
import {
  Building,
  ShieldCheck,
  Cpu,
  Factory,
  Mail,
  Phone,
  MapPin,
  CheckCircle2,
  AlertTriangle,
  Plus,
} from "lucide-react";

export default function ProfilePage() {
  const { user, refreshUser } = useAuth();
  const [loading, setLoading] = useState(false);
  const [profile, setProfile] = useState<any>(null);

  useEffect(() => {
    fetch("/api/auth/me")
      .then((res) => res.json())
      .then((data) => {
        if (data.user?.business) {
          setProfile(data.user.business);
        }
      })
      .catch((e) => console.error(e));
  }, [user]);

  const biz = profile || user?.business;

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-bold text-white flex items-center gap-2">
              <Building className="w-6 h-6 text-teal-400" />
              {biz?.name || "Manufacturing Business Profile"}
            </h1>
            {biz?.verificationStatus === "VERIFIED" && (
              <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-teal-500/10 text-teal-400 border border-teal-500/20 flex items-center gap-1">
                <ShieldCheck className="w-3.5 h-3.5" />
                Verified
              </span>
            )}
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Registration: <span className="font-mono text-teal-400 font-semibold">{biz?.registrationNumber}</span> •
            Sector: {biz?.category}
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Left Column: Contact & Basic Info */}
        <div className="space-y-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow space-y-3 text-xs">
            <h2 className="text-sm font-bold text-white">Contact & Headquarters</h2>
            <div className="space-y-2 text-slate-300">
              <div className="flex items-start gap-2">
                <MapPin className="w-4 h-4 text-slate-500 flex-shrink-0 mt-0.5" />
                <span>
                  {biz?.address || biz?.location}
                </span>
              </div>
              <div className="flex items-center gap-2">
                <Mail className="w-4 h-4 text-slate-500 flex-shrink-0" />
                <span>{biz?.email}</span>
              </div>
              <div className="flex items-center gap-2">
                <Phone className="w-4 h-4 text-slate-500 flex-shrink-0" />
                <span>{biz?.phone}</span>
              </div>
            </div>
          </div>

          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow space-y-2 text-xs">
            <h2 className="text-sm font-bold text-white">Operational Ratings</h2>
            <div className="flex justify-between items-center pt-1">
              <span className="text-slate-400">Trust Standing:</span>
              <span className="font-mono font-bold text-teal-400 text-sm">{biz?.trustScore}%</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-slate-400">KYC Compliance:</span>
              <span className="font-semibold text-emerald-400">{biz?.verificationStatus}</span>
            </div>
          </div>
        </div>

        {/* Right Columns: Capabilities & Machines */}
        <div className="md:col-span-2 space-y-6">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-sm font-bold text-white flex items-center gap-2">
                <Factory className="w-4 h-4 text-teal-400" />
                Certified Manufacturing Capabilities
              </h2>
            </div>

            <div className="space-y-3 text-xs">
              {(biz?.capabilities || []).map((cap: any) => (
                <div key={cap.id} className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-1">
                  <div className="flex justify-between items-center">
                    <h3 className="font-bold text-white">{cap.capabilityName}</h3>
                    {cap.maxPrecision && (
                      <span className="font-mono text-teal-400 text-[11px] font-semibold">
                        Tolerance: {cap.maxPrecision}
                      </span>
                    )}
                  </div>
                  {cap.description && <p className="text-slate-400 text-[11px]">{cap.description}</p>}
                  <div className="flex flex-wrap gap-2 text-[10px] text-slate-500 pt-1">
                    {cap.certifications && (
                      <span className="px-2 py-0.5 rounded bg-slate-900 border border-slate-800 text-slate-300">
                        📜 {cap.certifications}
                      </span>
                    )}
                    {cap.leadTimeDays && (
                      <span className="px-2 py-0.5 rounded bg-slate-900 border border-slate-800 text-slate-300">
                        ⏱️ Lead: {cap.leadTimeDays} days
                      </span>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow space-y-4">
            <h2 className="text-sm font-bold text-white flex items-center gap-2">
              <Cpu className="w-4 h-4 text-teal-400" />
              Machine & Resource Registry
            </h2>
            <div className="space-y-2 text-xs">
              {(biz?.resources || []).map((res: any) => (
                <div
                  key={res.id}
                  className="p-3 rounded-xl bg-slate-950 border border-slate-800 flex justify-between items-center"
                >
                  <div>
                    <h4 className="font-semibold text-white">{res.resourceName}</h4>
                    <p className="text-[11px] text-slate-400">
                      Type: {res.resourceType} • Installed: {res.quantity} unit(s)
                    </p>
                  </div>
                  <span className="px-2 py-0.5 rounded text-[10px] bg-teal-500/20 text-teal-300 font-semibold">
                    {res.operationalStatus}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
