import { NextResponse } from "next/server";
import prisma from "@/lib/prisma";
import { getSessionUser } from "@/lib/auth";
import { invoiceSchema } from "@/lib/validation";
import { logAuditEvent, createNotification } from "@/lib/audit";

export async function GET(req: Request) {
  try {
    const session = await getSessionUser();
    if (!session || !session.businessId) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const { searchParams } = new URL(req.url);
    const orderId = searchParams.get("orderId");
    const role = searchParams.get("role"); // "issued" or "received"

    const where: any = {};
    if (orderId) where.orderId = orderId;

    if (role === "issued") {
      where.issuerBusinessId = session.businessId;
    } else if (role === "received") {
      where.recipientBusinessId = session.businessId;
    } else if (session.role !== "ADMIN") {
      where.OR = [
        { issuerBusinessId: session.businessId },
        { recipientBusinessId: session.businessId },
      ];
    }

    const invoices = await prisma.invoice.findMany({
      where,
      include: {
        order: { select: { id: true, orderNumber: true, title: true } },
        issuerBusiness: { select: { id: true, name: true, location: true, email: true, phone: true } },
        recipientBusiness: { select: { id: true, name: true, location: true, email: true, phone: true } },
        payments: true,
      },
      orderBy: { createdAt: "desc" },
    });

    return NextResponse.json({ invoices });
  } catch (error: any) {
    console.error("Invoices GET error:", error);
    return NextResponse.json({ error: error.message || "Failed to fetch invoices" }, { status: 500 });
  }
}

export async function POST(req: Request) {
  try {
    const session = await getSessionUser();
    if (!session || !session.businessId) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const body = await req.json();

    // 1. SIMULATE PAYMENT ACTION
    if (body.action === "SIMULATE_PAY") {
      const { invoiceId, paymentMethod = "Demonstration Simulated Escrow Transfer" } = body;
      const invoice = await prisma.invoice.findUnique({
        where: { id: invoiceId },
        include: { issuerBusiness: true, recipientBusiness: true },
      });

      if (!invoice) {
        return NextResponse.json({ error: "Invoice not found" }, { status: 404 });
      }

      if (invoice.recipientBusinessId !== session.businessId && session.role !== "ADMIN") {
        return NextResponse.json({ error: "Only the recipient business can pay this invoice" }, { status: 403 });
      }

      if (invoice.status === "PAID") {
        return NextResponse.json({ error: "Invoice is already paid" }, { status: 400 });
      }

      const refNumber = `SIM-PAY-${Date.now()}-${Math.floor(100 + Math.random() * 900)}`;

      const result = await prisma.$transaction(async (tx) => {
        const payment = await tx.paymentRecord.create({
          data: {
            invoiceId,
            amount: invoice.amountTotal,
            referenceNumber: refNumber,
            status: "COMPLETED",
            isSimulated: true,
            notes: `Simulated payment executed by ${session.name} for demo workflow.`,
          },
        });

        const updatedInvoice = await tx.invoice.update({
          where: { id: invoiceId },
          data: {
            status: "PAID",
            paidDate: new Date(),
            paymentMethod,
          },
        });

        return { payment, updatedInvoice };
      });

      await logAuditEvent({
        eventType: "INVOICE",
        action: "PAID",
        actorId: session.id,
        actorName: session.name,
        businessId: session.businessId,
        targetType: "Invoice",
        targetId: invoiceId,
        metadata: {
          invoiceNumber: invoice.invoiceNumber,
          amountTotal: invoice.amountTotal,
          simulated: true,
        },
      });

      await createNotification({
        businessId: invoice.issuerBusinessId,
        title: "Invoice Paid (Simulated)",
        message: `${invoice.recipientBusiness.name} has settled Invoice #${invoice.invoiceNumber} for ₹${invoice.amountTotal.toLocaleString()}.`,
        type: "INVOICE_STATUS",
        link: `/invoices`,
      });

      return NextResponse.json({ success: true, ...result });
    }

    // 2. CREATE INVOICE ACTION
    const parsed = invoiceSchema.safeParse(body);
    if (!parsed.success) {
      return NextResponse.json(
        { error: "Validation failed", details: parsed.error.flatten().fieldErrors },
        { status: 400 }
      );
    }

    const { orderId, recipientBusinessId, itemDescription, quantity, unitPrice, taxRate, dueDate, notes } =
      parsed.data;

    // Check order association
    const order = await prisma.order.findUnique({
      where: { id: orderId },
      include: { allocations: true },
    });

    if (!order) {
      return NextResponse.json({ error: "Order not found" }, { status: 404 });
    }

    // Server-side precise financial calculations
    const amountSubtotal = Math.round(quantity * unitPrice * 100) / 100;
    const taxAmount = Math.round(amountSubtotal * (taxRate / 100) * 100) / 100;
    const amountTotal = Math.round((amountSubtotal + taxAmount) * 100) / 100;

    const invoiceNumber = `INV-${new Date().getFullYear()}-${Math.floor(10000 + Math.random() * 90000)}`;

    const invoice = await prisma.invoice.create({
      data: {
        invoiceNumber,
        orderId,
        issuerBusinessId: session.businessId,
        recipientBusinessId,
        itemDescription,
        quantity,
        unitPrice,
        amountSubtotal,
        taxRate,
        taxAmount,
        amountTotal,
        currency: "INR",
        status: "ISSUED",
        dueDate: new Date(dueDate),
        isSimulated: true,
        notes: notes || "Milestone invoice issued through CoMitra collaborative platform.",
      },
    });

    await logAuditEvent({
      eventType: "INVOICE",
      action: "CREATE",
      actorId: session.id,
      actorName: session.name,
      businessId: session.businessId,
      targetType: "Invoice",
      targetId: invoice.id,
      metadata: { invoiceNumber, amountTotal, recipientBusinessId },
    });

    await createNotification({
      businessId: recipientBusinessId,
      title: `New Invoice Received: ${invoiceNumber}`,
      message: `${session.businessName} issued invoice #${invoiceNumber} for ₹${amountTotal.toLocaleString()}.`,
      type: "INVOICE_STATUS",
      link: `/invoices`,
    });

    return NextResponse.json({ success: true, invoice }, { status: 201 });
  } catch (error: any) {
    console.error("Invoice POST error:", error);
    return NextResponse.json({ error: error.message || "Failed to process invoice" }, { status: 500 });
  }
}
