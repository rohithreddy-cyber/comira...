import { NextResponse } from "next/server";
import prisma from "@/lib/prisma";
import { getSessionUser } from "@/lib/auth";
import { reviewSchema } from "@/lib/validation";
import { logAuditEvent } from "@/lib/audit";

export async function GET(req: Request) {
  try {
    const { searchParams } = new URL(req.url);
    const businessId = searchParams.get("businessId");

    const where: any = {};
    if (businessId) where.revieweeBusinessId = businessId;

    const reviews = await prisma.rating.findMany({
      where,
      include: {
        reviewerBusiness: { select: { id: true, name: true, location: true, verificationStatus: true } },
        order: { select: { id: true, orderNumber: true, title: true } },
      },
      orderBy: { createdAt: "desc" },
    });

    return NextResponse.json({ reviews });
  } catch (error: any) {
    console.error("Reviews GET error:", error);
    return NextResponse.json({ error: error.message || "Failed to fetch reviews" }, { status: 500 });
  }
}

export async function POST(req: Request) {
  try {
    const session = await getSessionUser();
    if (!session || !session.businessId) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const body = await req.json();
    const parsed = reviewSchema.safeParse(body);

    if (!parsed.success) {
      return NextResponse.json(
        { error: "Validation failed", details: parsed.error.flatten().fieldErrors },
        { status: 400 }
      );
    }

    const { orderId, revieweeBusinessId, score, communicationRating, qualityRating, timelinessRating, feedback } =
      parsed.data;

    if (revieweeBusinessId === session.businessId) {
      return NextResponse.json({ error: "Cannot review your own business" }, { status: 400 });
    }

    // Verify that a real collaboration took place between these two businesses on this order
    const order = await prisma.order.findUnique({
      where: { id: orderId },
      include: { allocations: true },
    });

    if (!order) {
      return NextResponse.json({ error: "Order not found" }, { status: 404 });
    }

    const reviewerIsOwner = order.ownerBusinessId === session.businessId;
    const revieweeIsOwner = order.ownerBusinessId === revieweeBusinessId;
    const reviewerHasAlloc = order.allocations.some((a) => a.businessId === session.businessId);
    const revieweeHasAlloc = order.allocations.some((a) => a.businessId === revieweeBusinessId);

    const isLegitimateCollaboration =
      (reviewerIsOwner && revieweeHasAlloc) || (revieweeIsOwner && reviewerHasAlloc);

    if (!isLegitimateCollaboration && session.role !== "ADMIN") {
      return NextResponse.json(
        { error: "Reviews are restricted to confirmed collaborative partners on completed or active orders." },
        { status: 403 }
      );
    }

    // Check duplicate
    const existing = await prisma.rating.findUnique({
      where: {
        orderId_reviewerBusinessId_revieweeBusinessId: {
          orderId,
          reviewerBusinessId: session.businessId,
          revieweeBusinessId,
        },
      },
    });

    if (existing) {
      return NextResponse.json({ error: "You have already submitted a review for this collaboration" }, { status: 400 });
    }

    // Create review and update trustScore
    const result = await prisma.$transaction(async (tx) => {
      const review = await tx.rating.create({
        data: {
          orderId,
          reviewerBusinessId: session.businessId!,
          revieweeBusinessId,
          score,
          communicationRating,
          qualityRating,
          timelinessRating,
          feedback,
          isVerifiedCollaboration: true,
        },
      });

      // Recalculate average trustScore
      const allReviews = await tx.rating.findMany({
        where: { revieweeBusinessId },
      });

      const avgScore = allReviews.reduce((sum, r) => sum + r.score, 0) / allReviews.length;
      const calculatedTrust = Math.round((avgScore / 5) * 100 * 10) / 10;

      await tx.business.update({
        where: { id: revieweeBusinessId },
        data: { trustScore: calculatedTrust },
      });

      return review;
    });

    await logAuditEvent({
      eventType: "REVIEW",
      action: "CREATE",
      actorId: session.id,
      actorName: session.name,
      businessId: session.businessId,
      targetType: "Rating",
      targetId: result.id,
      metadata: { revieweeBusinessId, score },
    });

    return NextResponse.json({ success: true, review: result }, { status: 201 });
  } catch (error: any) {
    console.error("Review POST error:", error);
    return NextResponse.json({ error: error.message || "Failed to submit review" }, { status: 500 });
  }
}
