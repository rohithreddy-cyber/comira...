import { NextResponse } from "next/server";
import prisma from "@/lib/prisma";
import { getSessionUser } from "@/lib/auth";
import { productionUpdateSchema } from "@/lib/validation";
import { logAuditEvent, createNotification } from "@/lib/audit";

export async function GET(req: Request) {
  try {
    const session = await getSessionUser();
    if (!session || !session.businessId) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const { searchParams } = new URL(req.url);
    const orderId = searchParams.get("orderId");
    const workAllocationId = searchParams.get("workAllocationId");

    const where: any = {};
    if (orderId) where.orderId = orderId;
    if (workAllocationId) where.workAllocationId = workAllocationId;

    // Filter by business involvement if not admin
    if (session.role !== "ADMIN") {
      where.OR = [
        { businessId: session.businessId },
        { order: { ownerBusinessId: session.businessId } },
      ];
    }

    const updates = await prisma.productionUpdate.findMany({
      where,
      include: {
        business: { select: { id: true, name: true } },
        workAllocation: true,
        order: { select: { id: true, orderNumber: true, title: true, totalQuantity: true } },
      },
      orderBy: { reportedDate: "desc" },
    });

    return NextResponse.json({ updates });
  } catch (error: any) {
    console.error("Production updates GET error:", error);
    return NextResponse.json({ error: error.message || "Failed to fetch updates" }, { status: 500 });
  }
}

export async function POST(req: Request) {
  try {
    const session = await getSessionUser();
    if (!session || !session.businessId) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const body = await req.json();
    const parsed = productionUpdateSchema.safeParse(body);

    if (!parsed.success) {
      return NextResponse.json(
        { error: "Validation failed", details: parsed.error.flatten().fieldErrors },
        { status: 400 }
      );
    }

    const {
      orderId,
      workAllocationId,
      completedQuantity,
      statusNote,
      delayReason,
      delayDays,
      qualityPassed,
      qualityNotes,
    } = parsed.data;

    // Fetch allocation
    const allocation = await prisma.workAllocation.findUnique({
      where: { id: workAllocationId },
      include: {
        order: {
          include: { allocations: true },
        },
        business: true,
      },
    });

    if (!allocation) {
      return NextResponse.json({ error: "Work allocation not found" }, { status: 404 });
    }

    // Permission check: Allocation holder, Order owner, or Admin
    if (
      allocation.businessId !== session.businessId &&
      allocation.order.ownerBusinessId !== session.businessId &&
      session.role !== "ADMIN"
    ) {
      return NextResponse.json({ error: "Forbidden: You are not authorized to update this production stream" }, { status: 403 });
    }

    // Prevent completed quantity exceeding allocated limit
    if (completedQuantity > allocation.allocatedQuantity) {
      return NextResponse.json(
        {
          error: `Completed quantity (${completedQuantity.toLocaleString()}) cannot exceed total allocated work limit (${allocation.allocatedQuantity.toLocaleString()})`,
        },
        { status: 400 }
      );
    }

    // Execute atomic update
    const result = await prisma.$transaction(async (tx) => {
      // 1. Create production log entry
      const updateEntry = await tx.productionUpdate.create({
        data: {
          orderId,
          workAllocationId,
          businessId: allocation.businessId,
          completedQuantity,
          statusNote,
          delayReason,
          delayDays: delayDays || 0,
          qualityPassed,
          qualityNotes,
        },
      });

      // 2. Update allocation status and completed quantity
      let allocStatus = allocation.status;
      if (completedQuantity >= allocation.allocatedQuantity) {
        allocStatus = qualityPassed ? "COMPLETED" : "QUALITY_CHECK";
      } else if (completedQuantity > 0) {
        allocStatus = "IN_PROGRESS";
      }

      const updatedAlloc = await tx.workAllocation.update({
        where: { id: workAllocationId },
        data: {
          completedQuantity,
          status: allocStatus,
        },
      });

      // 3. Recalculate total completed quantity on the order across all allocations
      const allAllocs = await tx.workAllocation.findMany({
        where: { orderId, status: { not: "CANCELLED" } },
      });

      const orderTotalProduced = allAllocs.reduce((sum, a) => {
        return a.id === workAllocationId ? sum + completedQuantity : sum + a.completedQuantity;
      }, 0);

      // Determine new order lifecycle status
      let newOrderStatus = allocation.order.status;
      if (orderTotalProduced >= allocation.order.totalQuantity) {
        newOrderStatus = "READY_FOR_DELIVERY";
      } else if (orderTotalProduced > 0 && (newOrderStatus === "PRODUCTION_SCHEDULED" || newOrderStatus === "COLLABORATION_PENDING")) {
        newOrderStatus = "IN_PRODUCTION";
      }

      await tx.order.update({
        where: { id: orderId },
        data: { status: newOrderStatus },
      });

      return { updateEntry, updatedAlloc, orderTotalProduced, newOrderStatus };
    });

    await logAuditEvent({
      eventType: "PRODUCTION",
      action: "UPDATE",
      actorId: session.id,
      actorName: session.name,
      businessId: session.businessId,
      targetType: "WorkAllocation",
      targetId: workAllocationId,
      metadata: {
        orderId,
        completedQuantity,
        delayDays,
        qualityPassed,
      },
    });

    // Notify counterpart if delay or completion occurred
    if (delayDays > 0) {
      await createNotification({
        businessId: allocation.order.ownerBusinessId,
        title: `Production Delay Reported`,
        message: `${allocation.business.name} reported a ${delayDays}-day delay on Order ${allocation.order.orderNumber}: ${delayReason || "Operational adjustment"}`,
        type: "MILESTONE_DELAYED",
        link: `/production`,
      });
    }

    return NextResponse.json({ success: true, ...result });
  } catch (error: any) {
    console.error("Production POST error:", error);
    return NextResponse.json({ error: error.message || "Failed to save production update" }, { status: 500 });
  }
}
