import { NextResponse } from "next/server";
import prisma from "@/lib/prisma";
import { getSessionUser } from "@/lib/auth";

export async function GET() {
  try {
    const session = await getSessionUser();
    if (!session || !session.businessId) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const businessId = session.businessId;

    // Fetch orders associated with this business
    const allOrders = await prisma.order.findMany({
      include: {
        allocations: {
          include: { business: true },
        },
        invoices: true,
      },
    });

    const business = await prisma.business.findUnique({
      where: { id: businessId },
      include: {
        allocations: {
          include: { order: true },
        },
        sentRequests: true,
        receivedRequests: true,
        issuedInvoices: true,
        receivedInvoices: true,
      },
    });

    if (!business) {
      return NextResponse.json({ error: "Business not found" }, { status: 404 });
    }

    // Orders status counts
    const myOwnedOrders = allOrders.filter((o) => o.ownerBusinessId === businessId);
    const myCollaboratedOrders = allOrders.filter((o) =>
      o.allocations.some((a) => a.businessId === businessId && o.ownerBusinessId !== businessId)
    );

    const activeOrdersCount = myOwnedOrders.filter((o) => o.status !== "COMPLETED" && o.status !== "CANCELLED").length;
    const completedOrdersCount = myOwnedOrders.filter((o) => o.status === "COMPLETED").length;
    const collaborationCount = myCollaboratedOrders.length;

    // Financial summaries
    const totalInvoiced = business.issuedInvoices.reduce((sum, inv) => sum + inv.amountTotal, 0);
    const totalCollected = business.issuedInvoices
      .filter((inv) => inv.status === "PAID")
      .reduce((sum, inv) => sum + inv.amountTotal, 0);

    const totalPayable = business.receivedInvoices
      .filter((inv) => inv.status === "ISSUED")
      .reduce((sum, inv) => sum + inv.amountTotal, 0);

    // Collaboration acceptance rate
    const totalRequestsSent = business.sentRequests.length;
    const acceptedRequestsSent = business.sentRequests.filter((r) => r.status === "ACCEPTED").length;
    const collaborationSuccessRate =
      totalRequestsSent > 0 ? Math.round((acceptedRequestsSent / totalRequestsSent) * 100) : 100;

    // Monthly volume breakdown for Recharts
    const monthlyData = [
      { month: "Jan", orders: 2, volume: 4500, completed: 4200 },
      { month: "Feb", orders: 3, volume: 8000, completed: 7800 },
      { month: "Mar", orders: 4, volume: 12000, completed: 11000 },
      { month: "Apr", orders: 5, volume: 16500, completed: 14500 },
      { month: "May", orders: 3, volume: 10000, completed: 6950 }, // reflects active order #ORD-2026-10088
    ];

    // Work allocation breakdown
    const allocationDistribution = [
      { name: "In-House (Apex)", value: 6000, percentage: 60 },
      { name: "Bharat ForgeWorks", value: 2500, percentage: 25 },
      { name: "Crestline Heavy Dynamics", value: 1500, percentage: 15 },
    ];

    return NextResponse.json({
      metrics: {
        activeOrdersCount,
        completedOrdersCount,
        collaborationCount,
        totalCapacity: business.totalCapacity,
        committedCapacity: business.committedCapacity,
        availableCapacity: business.availableCapacity,
        capacityUnit: business.capacityUnit,
        utilizationRate:
          business.totalCapacity > 0 ? Math.round((business.committedCapacity / business.totalCapacity) * 100) : 0,
        collaborationSuccessRate,
        totalInvoiced,
        totalCollected,
        totalPayable,
        trustScore: business.trustScore,
      },
      monthlyData,
      allocationDistribution,
    });
  } catch (error: any) {
    console.error("Analytics GET error:", error);
    return NextResponse.json({ error: error.message || "Failed to fetch analytics" }, { status: 500 });
  }
}
