import { NextResponse } from "next/server";
import prisma from "@/lib/prisma";
import { getSessionUser } from "@/lib/auth";
import { capacityUpdateSchema } from "@/lib/validation";
import { logAuditEvent } from "@/lib/audit";

export async function GET(req: Request) {
  try {
    const session = await getSessionUser();
    if (!session || !session.businessId) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const { searchParams } = new URL(req.url);
    const targetBusinessId = searchParams.get("businessId") || session.businessId;

    const business = await prisma.business.findUnique({
      where: { id: targetBusinessId },
      include: {
        allocations: {
          where: { status: { not: "CANCELLED" } },
          include: {
            order: {
              select: {
                id: true,
                orderNumber: true,
                title: true,
                deadline: true,
                status: true,
              },
            },
          },
        },
        resources: true,
      },
    });

    if (!business) {
      return NextResponse.json({ error: "Business not found" }, { status: 404 });
    }

    // Active allocations commitment breakdown
    const activeCommitments = business.allocations.filter((a) => a.status !== "COMPLETED");
    const activeCommittedUnits = activeCommitments.reduce((sum, a) => {
      return sum + (a.allocatedQuantity - a.completedQuantity);
    }, 0);

    const utilizationPercentage =
      business.totalCapacity > 0 ? Math.min(100, Math.round((business.committedCapacity / business.totalCapacity) * 100)) : 0;

    return NextResponse.json({
      businessId: business.id,
      name: business.name,
      totalCapacity: business.totalCapacity,
      committedCapacity: business.committedCapacity,
      availableCapacity: business.availableCapacity,
      capacityUnit: business.capacityUnit,
      utilizationPercentage,
      activeCommitments,
      resources: business.resources,
    });
  } catch (error: any) {
    console.error("Capacity GET error:", error);
    return NextResponse.json({ error: error.message || "Failed to fetch capacity" }, { status: 500 });
  }
}

export async function PATCH(req: Request) {
  try {
    const session = await getSessionUser();
    if (!session || !session.businessId) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const body = await req.json();
    const parsed = capacityUpdateSchema.safeParse(body);

    if (!parsed.success) {
      return NextResponse.json(
        { error: "Validation failed", details: parsed.error.flatten().fieldErrors },
        { status: 400 }
      );
    }

    const { totalCapacity, capacityUnit } = parsed.data;

    const currentBusiness = await prisma.business.findUnique({
      where: { id: session.businessId },
    });

    if (!currentBusiness) {
      return NextResponse.json({ error: "Business not found" }, { status: 404 });
    }

    // Prevent reducing total capacity below currently committed production obligations
    if (totalCapacity < currentBusiness.committedCapacity) {
      return NextResponse.json(
        {
          error: `Cannot reduce total capacity to ${totalCapacity.toLocaleString()} because ${currentBusiness.committedCapacity.toLocaleString()} is currently committed to active orders.`,
        },
        { status: 400 }
      );
    }

    const newAvailable = totalCapacity - currentBusiness.committedCapacity;

    const updated = await prisma.business.update({
      where: { id: session.businessId },
      data: {
        totalCapacity,
        availableCapacity: newAvailable,
        capacityUnit,
      },
    });

    await logAuditEvent({
      eventType: "CAPACITY",
      action: "UPDATE",
      actorId: session.id,
      actorName: session.name,
      businessId: session.businessId,
      targetType: "Business",
      targetId: session.businessId,
      metadata: {
        oldTotal: currentBusiness.totalCapacity,
        newTotal: totalCapacity,
        availableCapacity: newAvailable,
      },
    });

    return NextResponse.json({ success: true, business: updated });
  } catch (error: any) {
    console.error("Capacity PATCH error:", error);
    return NextResponse.json({ error: error.message || "Failed to update capacity" }, { status: 500 });
  }
}
