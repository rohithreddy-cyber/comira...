import { NextResponse } from "next/server";
import prisma from "@/lib/prisma";
import { getSessionUser } from "@/lib/auth";
import { collaborationRequestSchema } from "@/lib/validation";
import { logAuditEvent, createNotification } from "@/lib/audit";

export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  try {
    const session = await getSessionUser();
    if (!session || !session.businessId) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const { searchParams } = new URL(req.url);
    const type = searchParams.get("type"); // "received", "sent", or all

    const where: any = {};
    if (type === "received") {
      where.receiverBusinessId = session.businessId;
    } else if (type === "sent") {
      where.senderBusinessId = session.businessId;
    } else {
      where.OR = [
        { receiverBusinessId: session.businessId },
        { senderBusinessId: session.businessId },
      ];
    }

    const requests = await prisma.collaborationRequest.findMany({
      where,
      include: {
        order: {
          select: {
            id: true,
            orderNumber: true,
            title: true,
            totalQuantity: true,
            quantityUnit: true,
            deadline: true,
            status: true,
          },
        },
        senderBusiness: {
          select: { id: true, name: true, location: true, trustScore: true },
        },
        receiverBusiness: {
          select: { id: true, name: true, location: true, availableCapacity: true, capacityUnit: true },
        },
      },
      orderBy: { createdAt: "desc" },
    });

    return NextResponse.json({ requests });
  } catch (error: any) {
    console.error("Requests GET error:", error);
    return NextResponse.json({ error: error.message || "Failed to fetch requests" }, { status: 500 });
  }
}

export async function POST(req: Request) {
  try {
    const session = await getSessionUser();
    if (!session || !session.businessId) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const body = await req.json();
    const parsed = collaborationRequestSchema.safeParse(body);

    if (!parsed.success) {
      return NextResponse.json(
        { error: "Validation failed", details: parsed.error.flatten().fieldErrors },
        { status: 400 }
      );
    }

    const { orderId, receiverBusinessId, proposedQuantity, unitPrice, proposedDeadline, requirements, message } =
      parsed.data;

    // Fetch order
    const order = await prisma.order.findUnique({
      where: { id: orderId },
      include: { allocations: true },
    });

    if (!order) {
      return NextResponse.json({ error: "Order not found" }, { status: 404 });
    }

    if (order.ownerBusinessId !== session.businessId && session.role !== "ADMIN") {
      return NextResponse.json({ error: "Only the order owner can send collaboration invitations" }, { status: 403 });
    }

    if (receiverBusinessId === session.businessId) {
      return NextResponse.json({ error: "Cannot send collaboration request to yourself" }, { status: 400 });
    }

    // Check partner business
    const partner = await prisma.business.findUnique({
      where: { id: receiverBusinessId },
    });

    if (!partner || partner.isSuspended) {
      return NextResponse.json({ error: "Partner business is invalid or suspended" }, { status: 400 });
    }

    // Check capacity feasibility
    if (proposedQuantity > partner.availableCapacity) {
      return NextResponse.json(
        {
          error: `Proposed quantity (${proposedQuantity.toLocaleString()}) exceeds partner's advertised available capacity (${partner.availableCapacity.toLocaleString()} ${partner.capacityUnit})`,
        },
        { status: 400 }
      );
    }

    // Check total allocation constraint
    const currentAllocated = order.allocations.reduce((sum, a) => {
      return a.status !== "CANCELLED" ? sum + a.allocatedQuantity : sum;
    }, 0);

    const remainingUnallocated = Math.max(0, order.totalQuantity - currentAllocated);
    if (proposedQuantity > remainingUnallocated) {
      return NextResponse.json(
        {
          error: `Proposed quantity (${proposedQuantity.toLocaleString()}) exceeds the unallocated order quantity remaining (${remainingUnallocated.toLocaleString()})`,
        },
        { status: 400 }
      );
    }

    // Check duplicate active request
    const existingActiveRequest = await prisma.collaborationRequest.findFirst({
      where: {
        orderId,
        receiverBusinessId,
        status: "PENDING",
      },
    });

    if (existingActiveRequest) {
      return NextResponse.json(
        { error: "A pending collaboration request for this partner and order is already active" },
        { status: 400 }
      );
    }

    // Check if duplicate confirmed allocation already exists
    const existingAllocation = await prisma.workAllocation.findUnique({
      where: {
        orderId_businessId: {
          orderId,
          businessId: receiverBusinessId,
        },
      },
    });

    if (existingAllocation && existingAllocation.status !== "CANCELLED") {
      return NextResponse.json(
        { error: "This partner already has an active work allocation for this order" },
        { status: 400 }
      );
    }

    // Create request
    const request = await prisma.collaborationRequest.create({
      data: {
        orderId,
        senderBusinessId: session.businessId,
        receiverBusinessId,
        proposedQuantity,
        unitPrice,
        proposedDeadline: new Date(proposedDeadline),
        requirements,
        message,
        status: "PENDING",
      },
      include: {
        receiverBusiness: { select: { name: true } },
      },
    });

    // Update order status to COLLABORATION_PENDING if currently OPEN_FOR_COLLABORATION
    if (order.status === "OPEN_FOR_COLLABORATION") {
      await prisma.order.update({
        where: { id: orderId },
        data: { status: "COLLABORATION_PENDING" },
      });
    }

    await logAuditEvent({
      eventType: "ALLOCATION",
      action: "REQUEST_SENT",
      actorId: session.id,
      actorName: session.name,
      businessId: session.businessId,
      targetType: "CollaborationRequest",
      targetId: request.id,
      metadata: {
        orderNumber: order.orderNumber,
        receiverBusiness: request.receiverBusiness.name,
        proposedQuantity,
        unitPrice,
      },
    });

    // Notify Partner
    await createNotification({
      businessId: receiverBusinessId,
      title: `Collaboration Request: ${order.orderNumber}`,
      message: `${session.businessName || "A manufacturing partner"} invited you to collaborate on ${proposedQuantity.toLocaleString()} units.`,
      type: "COLLABORATION_INVITE",
      link: `/collaborations`,
    });

    return NextResponse.json({ success: true, request }, { status: 201 });
  } catch (error: any) {
    console.error("Requests POST error:", error);
    return NextResponse.json({ error: error.message || "Failed to create collaboration request" }, { status: 500 });
  }
}
