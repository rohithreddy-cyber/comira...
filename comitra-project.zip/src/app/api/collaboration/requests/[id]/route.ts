import { NextResponse } from "next/server";
import prisma from "@/lib/prisma";
import { getSessionUser } from "@/lib/auth";
import { respondRequestSchema } from "@/lib/validation";
import { logAuditEvent, createNotification } from "@/lib/audit";

export async function PATCH(req: Request, { params }: { params: { id: string } }) {
  try {
    const session = await getSessionUser();
    if (!session || !session.businessId) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const requestId = params.id;
    const body = await req.json();

    const request = await prisma.collaborationRequest.findUnique({
      where: { id: requestId },
      include: {
        order: {
          include: { allocations: true },
        },
        senderBusiness: true,
        receiverBusiness: true,
      },
    });

    if (!request) {
      return NextResponse.json({ error: "Collaboration request not found" }, { status: 404 });
    }

    if (request.status !== "PENDING") {
      return NextResponse.json({ error: `Request has already been ${request.status.toLowerCase()}` }, { status: 400 });
    }

    // Action 1: SENDER WITHDRAWS
    if (body.action === "WITHDRAW") {
      if (request.senderBusinessId !== session.businessId && session.role !== "ADMIN") {
        return NextResponse.json({ error: "Only the sender can withdraw a pending invitation" }, { status: 403 });
      }

      const updated = await prisma.collaborationRequest.update({
        where: { id: requestId },
        data: { status: "WITHDRAWN" },
      });

      await logAuditEvent({
        eventType: "ALLOCATION",
        action: "WITHDRAW",
        actorId: session.id,
        actorName: session.name,
        businessId: session.businessId,
        targetType: "CollaborationRequest",
        targetId: requestId,
      });

      return NextResponse.json({ success: true, request: updated });
    }

    // Action 2: RECEIVER ACCEPTS OR REJECTS
    if (request.receiverBusinessId !== session.businessId && session.role !== "ADMIN") {
      return NextResponse.json({ error: "Only the recipient partner business can respond to this invitation" }, { status: 403 });
    }

    const parsed = respondRequestSchema.safeParse(body);
    if (!parsed.success) {
      return NextResponse.json(
        { error: "Validation failed", details: parsed.error.flatten().fieldErrors },
        { status: 400 }
      );
    }

    const { status, responseNote } = parsed.data;

    if (status === "REJECTED") {
      const updated = await prisma.collaborationRequest.update({
        where: { id: requestId },
        data: {
          status: "REJECTED",
          responseNote: responseNote || "Declined by partner",
        },
      });

      await logAuditEvent({
        eventType: "ALLOCATION",
        action: "REJECT",
        actorId: session.id,
        actorName: session.name,
        businessId: session.businessId,
        targetType: "CollaborationRequest",
        targetId: requestId,
        metadata: { responseNote },
      });

      await createNotification({
        businessId: request.senderBusinessId,
        title: `Collaboration Declined`,
        message: `${request.receiverBusiness.name} declined the invitation for ${request.order.orderNumber}.`,
        type: "COLLABORATION_REJECTED",
        link: `/orders/${request.orderId}`,
      });

      return NextResponse.json({ success: true, request: updated });
    }

    if (status === "ACCEPTED") {
      // Server-side double validation before accepting
      const partner = await prisma.business.findUnique({
        where: { id: request.receiverBusinessId },
      });

      if (!partner || partner.availableCapacity < request.proposedQuantity) {
        return NextResponse.json(
          {
            error: `Insufficient available capacity. Partner has ${partner?.availableCapacity || 0} remaining, but request requires ${request.proposedQuantity}.`,
          },
          { status: 400 }
        );
      }

      const activeAllocated = request.order.allocations.reduce((sum, a) => {
        return a.status !== "CANCELLED" ? sum + a.allocatedQuantity : sum;
      }, 0);

      if (activeAllocated + request.proposedQuantity > request.order.totalQuantity) {
        return NextResponse.json(
          {
            error: `Accepting this request would exceed the total order quantity. Available to allocate: ${Math.max(
              0,
              request.order.totalQuantity - activeAllocated
            )} units.`,
          },
          { status: 400 }
        );
      }

      // Execute all changes atomically in a transaction
      const result = await prisma.$transaction(async (tx) => {
        // 1. Mark request accepted
        const updatedReq = await tx.collaborationRequest.update({
          where: { id: requestId },
          data: {
            status: "ACCEPTED",
            responseNote: responseNote || "Accepted",
          },
        });

        // 2. Create WorkAllocation
        const allocation = await tx.workAllocation.create({
          data: {
            orderId: request.orderId,
            businessId: request.receiverBusinessId,
            allocatedQuantity: request.proposedQuantity,
            agreedUnitPrice: request.unitPrice,
            totalAmount: request.proposedQuantity * request.unitPrice,
            agreedDeadline: request.proposedDeadline,
            status: "CONFIRMED",
            notes: responseNote || "Standard partner allocation accepted",
          },
        });

        // 3. Deduct partner's available capacity and add to committed
        await tx.business.update({
          where: { id: request.receiverBusinessId },
          data: {
            availableCapacity: { decrement: request.proposedQuantity },
            committedCapacity: { increment: request.proposedQuantity },
          },
        });

        // 4. Create Printable Digital Agreement draft
        const agreementNumber = `AGR-${new Date().getFullYear()}-${Math.floor(1000 + Math.random() * 9000)}`;
        const agreement = await tx.agreement.create({
          data: {
            agreementNumber,
            orderId: request.orderId,
            ownerBusinessId: request.senderBusinessId,
            partnerBusinessId: request.receiverBusinessId,
            title: `Co-Manufacturing Agreement: ${request.order.title}`,
            termsText: `CO-MANUFACTURING SUBCONTRACT COLLABORATION AGREEMENT\nOrder Reference: ${request.order.orderNumber}\nLead Manufacturer: ${request.senderBusiness.name}\nCollaborating Partner: ${request.receiverBusiness.name}\n\n1. SCOPE OF ALLOCATION\nPartner agrees to manufacture, inspect, and supply ${request.proposedQuantity.toLocaleString()} ${request.order.quantityUnit} conforming to technical specifications and quality standards.\n\n2. COMMERCIAL TERMS\nUnit Rate: ₹${request.unitPrice.toFixed(2)}\nTotal Sub-Contract Value: ₹${(request.proposedQuantity * request.unitPrice).toLocaleString()}\nAgreed Target Completion: ${new Date(request.proposedDeadline).toLocaleDateString()}\n\n3. QUALITY COMPLIANCE\nAdherence to required standards (${request.order.qualityRequirements}) and mutual inspection sign-off prior to delivery.\n\nStatus: Digital record created upon collaboration confirmation on CoMitra Platform.`,
            allocatedQuantity: request.proposedQuantity,
            agreedUnitPrice: request.unitPrice,
            totalValue: request.proposedQuantity * request.unitPrice,
            status: "PENDING_ACCEPTANCE",
            partnerSignedAt: new Date(),
          },
        });

        // 5. Update Order status if all capacity is now covered
        const newTotalAllocated = activeAllocated + request.proposedQuantity;
        const newOrderStatus = newTotalAllocated >= request.order.totalQuantity ? "PRODUCTION_SCHEDULED" : "COLLABORATION_PENDING";

        await tx.order.update({
          where: { id: request.orderId },
          data: { status: newOrderStatus },
        });

        return { updatedReq, allocation, agreement };
      });

      await logAuditEvent({
        eventType: "ALLOCATION",
        action: "ACCEPT",
        actorId: session.id,
        actorName: session.name,
        businessId: session.businessId,
        targetType: "WorkAllocation",
        targetId: result.allocation.id,
        metadata: {
          orderNumber: request.order.orderNumber,
          partnerName: request.receiverBusiness.name,
          allocatedQuantity: request.proposedQuantity,
          totalAmount: result.allocation.totalAmount,
        },
      });

      await createNotification({
        businessId: request.senderBusinessId,
        title: `Collaboration Accepted!`,
        message: `${request.receiverBusiness.name} accepted your invitation for ${request.proposedQuantity.toLocaleString()} units on Order ${request.order.orderNumber}.`,
        type: "COLLABORATION_ACCEPTED",
        link: `/orders/${request.orderId}`,
      });

      return NextResponse.json({ success: true, ...result });
    }

    return NextResponse.json({ error: "Invalid action" }, { status: 400 });
  } catch (error: any) {
    console.error("Requests PATCH error:", error);
    return NextResponse.json({ error: error.message || "Failed to respond to request" }, { status: 500 });
  }
}
