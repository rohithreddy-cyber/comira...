import { NextResponse } from "next/server";
import { generateAiInsight } from "@/lib/gemini";
import { getSessionUser } from "@/lib/auth";

export async function POST(req: Request) {
  try {
    const session = await getSessionUser();
    if (!session) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const body = await req.json();
    const prompt = body.prompt || "Provide an executive summary of current manufacturing collaboration health and order allocations.";

    const result = await generateAiInsight(prompt);

    return NextResponse.json(result);
  } catch (error: any) {
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}
