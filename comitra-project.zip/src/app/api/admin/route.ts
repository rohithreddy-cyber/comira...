import { NextResponse } from "next/server";
import prisma from "@/lib/prisma";
import { getSessionUser } from "@/lib/auth";
import { logAuditEvent, createNotification } from "@/lib/audit";

export async function GET() {
  try {
    const session = await getSessionUser();
    if (!session || session.role !== "ADMIN") {
      return NextResponse.json({ error: "Forbidden: Platform Administrator privileges required" }, { status: 403 });
    }

    const [businesses, verifications, orders, auditEvents, stats] = await Promise.all([
      prisma.business.findMany({
        include: {
          capabilities: true,
          verifications: true,
          users: { select: { id: true, name: true, email: true, role: true } },
        },
        orderBy: { createdAt: "desc" },
      }),
      prisma.businessVerification.findMany({
        include: {
          business: { select: { id: true, name: true, registrationNumber: true, email: true } },
        },
        orderBy: { submittedAt: "desc" },
      }),
      prisma.order.findMany({
        include: {
          ownerBusiness: { select: { id: true, name: true } },
          allocations: { include: { business: { select: { id: true, name: true } } } },
        },
        orderBy: { createdAt: "desc" },
      }),
      prisma.auditEvent.findMany({
        orderBy: { createdAt: "desc" },
        take: 100,
      }),
      prisma.$transaction([
        prisma.business.count(),
        prisma.order.count(),
        prisma.workAllocation.count(),
        prisma.invoice.count(),
      ]),
    ]);

    return NextResponse.json({
      businesses,
      verifications,
      orders,
      auditEvents,
      summary: {
        totalBusinesses: stats[0],
        totalOrders: stats[1],
        totalAllocations: stats[2],
        totalInvoices: stats[3],
      },
    });
  } catch (error: any) {
    console.error("Admin GET error:", error);
    return NextResponse.json({ error: error.message || "Failed to fetch admin data" }, { status: 500 });
  }
}

export async function POST(req: Request) {
  try {
    const session = await getSessionUser();
    if (!session || session.role !== "ADMIN") {
      return NextResponse.json({ error: "Forbidden: Administrator privileges required" }, { status: 403 });
    }

    const body = await req.json();
    const { action, businessId, verificationId, status, notes } = body;

    // 1. VERIFY BUSINESS
    if (action === "REVIEW_VERIFICATION") {
      const verification = await prisma.businessVerification.findUnique({
        where: { id: verificationId },
      });

      if (!verification) {
        return NextResponse.json({ error: "Verification record not found" }, { status: 404 });
      }

      const result = await prisma.$transaction(async (tx) => {
        const updatedVerif = await tx.businessVerification.update({
          where: { id: verificationId },
          data: {
            status, // APPROVED or REJECTED
            reviewerNotes: notes || `Reviewed by Administrator ${session.name}`,
            reviewedAt: new Date(),
          },
        });

        // If approved, update business verificationStatus
        if (status === "APPROVED") {
          await tx.business.update({
            where: { id: verification.businessId },
            data: { verificationStatus: "VERIFIED" },
          });
        }

        return updatedVerif;
      });

      await logAuditEvent({
        eventType: "ADMIN",
        action: `VERIFICATION_${status}`,
        actorId: session.id,
        actorName: session.name,
        targetType: "BusinessVerification",
        targetId: verificationId,
        metadata: { businessId: verification.businessId, status, notes },
      });

      await createNotification({
        businessId: verification.businessId,
        title: `Verification Status Updated: ${status}`,
        message: `Your regulatory compliance document review was marked as ${status}.`,
        type: "SYSTEM_ALERT",
        link: `/profile`,
      });

      return NextResponse.json({ success: true, verification: result });
    }

    // 2. SUSPEND / REINSTATE BUSINESS
    if (action === "TOGGLE_SUSPEND") {
      const business = await prisma.business.findUnique({
        where: { id: businessId },
      });

      if (!business) {
        return NextResponse.json({ error: "Business not found" }, { status: 404 });
      }

      const newSuspendedState = !business.isSuspended;

      const updated = await prisma.business.update({
        where: { id: businessId },
        data: { isSuspended: newSuspendedState },
      });

      await logAuditEvent({
        eventType: "ADMIN",
        action: newSuspendedState ? "SUSPEND_BUSINESS" : "REINSTATE_BUSINESS",
        actorId: session.id,
        actorName: session.name,
        targetType: "Business",
        targetId: businessId,
        metadata: { businessName: business.name, isSuspended: newSuspendedState },
      });

      return NextResponse.json({ success: true, business: updated });
    }

    return NextResponse.json({ error: "Invalid admin action" }, { status: 400 });
  } catch (error: any) {
    console.error("Admin POST error:", error);
    return NextResponse.json({ error: error.message || "Admin operation failed" }, { status: 500 });
  }
}
