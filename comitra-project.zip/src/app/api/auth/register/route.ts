import { NextResponse } from "next/server";
import prisma from "@/lib/prisma";
import { hashPassword, signToken, COOKIE_NAME } from "@/lib/auth";
import { registerSchema } from "@/lib/validation";
import { logAuditEvent } from "@/lib/audit";

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const parsed = registerSchema.safeParse(body);

    if (!parsed.error && !parsed.data) {
      return NextResponse.json({ error: "Invalid payload" }, { status: 400 });
    }

    if (!parsed.success) {
      return NextResponse.json(
        { error: "Validation failed", details: parsed.error.flatten().fieldErrors },
        { status: 400 }
      );
    }

    const data = parsed.data;

    // Check duplicate email
    const existingUser = await prisma.user.findUnique({
      where: { email: data.email.toLowerCase() },
    });
    if (existingUser) {
      return NextResponse.json({ error: "Email is already registered" }, { status: 400 });
    }

    // Check duplicate business registration
    const existingBusiness = await prisma.business.findUnique({
      where: { registrationNumber: data.registrationNumber.toUpperCase() },
    });
    if (existingBusiness) {
      return NextResponse.json({ error: "Business registration number is already registered" }, { status: 400 });
    }

    const passwordHash = await hashPassword(data.password);

    // Create Business and User transactionally
    const result = await prisma.$transaction(async (tx) => {
      const business = await tx.business.create({
        data: {
          name: data.businessName,
          registrationNumber: data.registrationNumber.toUpperCase(),
          description: `${data.businessName} - Specialized in ${data.category}`,
          category: data.category,
          location: data.location,
          address: data.address,
          phone: data.phone,
          email: data.email.toLowerCase(),
          totalCapacity: data.totalCapacity,
          committedCapacity: 0,
          availableCapacity: data.totalCapacity,
          capacityUnit: data.capacityUnit,
          verificationStatus: "PENDING",
        },
      });

      // Default capability based on category
      await tx.businessCapability.create({
        data: {
          businessId: business.id,
          capabilityName: data.category,
          description: `Primary capability in ${data.category}`,
          leadTimeDays: 14,
        },
      });

      const user = await tx.user.create({
        data: {
          name: data.name,
          email: data.email.toLowerCase(),
          passwordHash,
          role: data.role,
          businessId: business.id,
        },
      });

      return { user, business };
    });

    await logAuditEvent({
      eventType: "AUTH",
      action: "REGISTER",
      actorId: result.user.id,
      actorName: result.user.name,
      businessId: result.business.id,
      targetType: "User",
      targetId: result.user.id,
      metadata: { role: result.user.role, businessName: result.business.name },
    });

    const token = signToken({
      id: result.user.id,
      name: result.user.name,
      email: result.user.email,
      role: result.user.role as any,
      businessId: result.business.id,
      businessName: result.business.name,
    });

    const response = NextResponse.json({
      success: true,
      user: {
        id: result.user.id,
        name: result.user.name,
        email: result.user.email,
        role: result.user.role,
        businessId: result.business.id,
        businessName: result.business.name,
      },
    });

    response.cookies.set(COOKIE_NAME, token, {
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      sameSite: "lax",
      path: "/",
      maxAge: 60 * 60 * 24 * 7,
    });

    return response;
  } catch (error: any) {
    console.error("Register error:", error);
    return NextResponse.json({ error: error.message || "Registration failed" }, { status: 500 });
  }
}
