import { NextResponse } from "next/server";
import prisma from "@/lib/prisma";
import { getSessionUser } from "@/lib/auth";
import { logAuditEvent, createNotification } from "@/lib/audit";

export async function GET(req: Request, { params }: { params: { id: string } }) {
  try {
    const session = await getSessionUser();
    const orderId = params.id;

    const order = await prisma.order.findUnique({
      where: { id: orderId },
      include: {
        ownerBusiness: true,
        allocations: {
          include: {
            business: {
              select: {
                id: true,
                name: true,
                location: true,
                verificationStatus: true,
                trustScore: true,
                phone: true,
                email: true,
              },
            },
            milestones: true,
            updates: {
              orderBy: { reportedDate: "desc" },
            },
          },
        },
        requests: {
          include: {
            senderBusiness: { select: { id: true, name: true } },
            receiverBusiness: { select: { id: true, name: true, location: true, trustScore: true } },
          },
          orderBy: { createdAt: "desc" },
        },
        agreements: {
          include: {
            ownerBusiness: { select: { id: true, name: true } },
            partnerBusiness: { select: { id: true, name: true } },
          },
        },
        invoices: {
          include: {
            issuerBusiness: { select: { id: true, name: true } },
            recipientBusiness: { select: { id: true, name: true } },
          },
        },
      },
    });

    if (!order) {
      return NextResponse.json({ error: "Order not found" }, { status: 404 });
    }

    // Access control:
    // If not the order owner or admin, filter out sensitive collaboration requests destined for other partners
    if (session?.role !== "ADMIN" && session?.businessId !== order.ownerBusinessId) {
      order.requests = order.requests.filter(
        (r) => r.receiverBusinessId === session?.businessId || r.senderBusinessId === session?.businessId
      );
      order.agreements = order.agreements.filter(
        (a) => a.partnerBusinessId === session?.businessId || a.ownerBusinessId === session?.businessId
      );
      order.invoices = order.invoices.filter(
        (inv) => inv.issuerBusinessId === session?.businessId || inv.recipientBusinessId === session?.businessId
      );
    }

    // Calculate verified overall progress
    const totalAllocated = order.allocations.reduce((sum, a) => {
      return a.status !== "CANCELLED" ? sum + a.allocatedQuantity : sum;
    }, 0);

    const totalProduced = order.allocations.reduce((sum, a) => {
      return a.status !== "CANCELLED" ? sum + a.completedQuantity : sum;
    }, 0);

    const progressPercentage = order.totalQuantity > 0 ? Math.min(100, Math.round((totalProduced / order.totalQuantity) * 100)) : 0;

    return NextResponse.json({
      order,
      summary: {
        totalQuantity: order.totalQuantity,
        totalAllocated,
        remainingUnallocated: Math.max(0, order.totalQuantity - totalAllocated),
        totalProduced,
        progressPercentage,
        isFullyAllocated: totalAllocated >= order.totalQuantity,
        isCompleted: totalProduced >= order.totalQuantity && order.status === "COMPLETED",
      },
    });
  } catch (error: any) {
    console.error("Order GET id error:", error);
    return NextResponse.json({ error: error.message || "Failed to load order" }, { status: 500 });
  }
}

export async function PATCH(req: Request, { params }: { params: { id: string } }) {
  try {
    const session = await getSessionUser();
    if (!session || !session.businessId) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const orderId = params.id;
    const existingOrder = await prisma.order.findUnique({
      where: { id: orderId },
      include: { allocations: true },
    });

    if (!existingOrder) {
      return NextResponse.json({ error: "Order not found" }, { status: 404 });
    }

    if (existingOrder.ownerBusinessId !== session.businessId && session.role !== "ADMIN") {
      return NextResponse.json({ error: "Forbidden. Only order owner can modify order." }, { status: 403 });
    }

    const body = await req.json();

    // Prevent reducing totalQuantity below sum of active allocations
    const activeAllocated = existingOrder.allocations.reduce((sum, a) => {
      return a.status !== "CANCELLED" ? sum + a.allocatedQuantity : sum;
    }, 0);

    if (body.totalQuantity && body.totalQuantity < activeAllocated) {
      return NextResponse.json(
        {
          error: `Cannot reduce total quantity below currently committed partner allocations (${activeAllocated})`,
        },
        { status: 400 }
      );
    }

    const updated = await prisma.order.update({
      where: { id: orderId },
      data: {
        title: body.title ?? existingOrder.title,
        description: body.description ?? existingOrder.description,
        deliveryLocation: body.deliveryLocation ?? existingOrder.deliveryLocation,
        deadline: body.deadline ? new Date(body.deadline) : existingOrder.deadline,
        status: body.status ?? existingOrder.status,
        technicalSpecs: body.technicalSpecs ?? existingOrder.technicalSpecs,
        qualityRequirements: body.qualityRequirements ?? existingOrder.qualityRequirements,
      },
    });

    await logAuditEvent({
      eventType: "ORDER",
      action: "UPDATE",
      actorId: session.id,
      actorName: session.name,
      businessId: session.businessId,
      targetType: "Order",
      targetId: orderId,
      metadata: { changedFields: Object.keys(body) },
    });

    return NextResponse.json({ success: true, order: updated });
  } catch (error: any) {
    console.error("Order PATCH error:", error);
    return NextResponse.json({ error: error.message || "Failed to update order" }, { status: 500 });
  }
}

export async function DELETE(req: Request, { params }: { params: { id: string } }) {
  try {
    const session = await getSessionUser();
    if (!session || !session.businessId) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const orderId = params.id;
    const order = await prisma.order.findUnique({
      where: { id: orderId },
      include: { allocations: true },
    });

    if (!order) {
      return NextResponse.json({ error: "Order not found" }, { status: 404 });
    }

    if (order.ownerBusinessId !== session.businessId && session.role !== "ADMIN") {
      return NextResponse.json({ error: "Forbidden" }, { status: 403 });
    }

    // Cancel order and release capacity
    await prisma.$transaction(async (tx) => {
      await tx.order.update({
        where: { id: orderId },
        data: { status: "CANCELLED" },
      });

      // Release partner commitments
      for (const alloc of order.allocations) {
        if (alloc.status !== "CANCELLED" && alloc.status !== "COMPLETED") {
          await tx.workAllocation.update({
            where: { id: alloc.id },
            data: { status: "CANCELLED" },
          });

          const uncompleted = Math.max(0, alloc.allocatedQuantity - alloc.completedQuantity);
          await tx.business.update({
            where: { id: alloc.businessId },
            data: {
              committedCapacity: { decrement: uncompleted },
              availableCapacity: { increment: uncompleted },
            },
          });
        }
      }
    });

    await logAuditEvent({
      eventType: "ORDER",
      action: "CANCEL",
      actorId: session.id,
      actorName: session.name,
      businessId: session.businessId,
      targetType: "Order",
      targetId: orderId,
    });

    return NextResponse.json({ success: true, message: "Order cancelled and capacities restored." });
  } catch (error: any) {
    console.error("Order DELETE error:", error);
    return NextResponse.json({ error: error.message || "Failed to cancel order" }, { status: 500 });
  }
}
