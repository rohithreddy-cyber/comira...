import { NextResponse } from "next/server";
import { computePartnerRecommendations, DEFAULT_WEIGHTS } from "@/lib/matchingEngine";
import prisma from "@/lib/prisma";

export async function GET(req: Request, { params }: { params: { id: string } }) {
  try {
    const orderId = params.id;
    const { searchParams } = new URL(req.url);

    const weights = {
      capabilityWeight: parseFloat(searchParams.get("capabilityWeight") || String(DEFAULT_WEIGHTS.capabilityWeight)),
      capacityWeight: parseFloat(searchParams.get("capacityWeight") || String(DEFAULT_WEIGHTS.capacityWeight)),
      qualityWeight: parseFloat(searchParams.get("qualityWeight") || String(DEFAULT_WEIGHTS.qualityWeight)),
      deadlineWeight: parseFloat(searchParams.get("deadlineWeight") || String(DEFAULT_WEIGHTS.deadlineWeight)),
      trustWeight: parseFloat(searchParams.get("trustWeight") || String(DEFAULT_WEIGHTS.trustWeight)),
    };

    const recommendations = await computePartnerRecommendations(orderId, weights);

    // Persist or update the recommendations in DB for historical auditing
    for (const rec of recommendations) {
      await prisma.partnerRecommendation.upsert({
        where: {
          orderId_businessId: {
            orderId,
            businessId: rec.business.id,
          },
        },
        create: {
          orderId,
          businessId: rec.business.id,
          score: rec.breakdown.totalScore,
          capabilityScore: rec.breakdown.capabilityScore,
          capacityScore: rec.breakdown.capacityScore,
          deadlineScore: rec.breakdown.deadlineScore,
          qualityScore: rec.breakdown.qualityScore,
          trustScore: rec.breakdown.trustScore,
          matchCategory: rec.breakdown.matchCategory,
          matchedCapabilities: rec.breakdown.matchedCapabilities.join(", "),
          reasonsJson: JSON.stringify(rec.breakdown.reasons),
          limitationsJson: JSON.stringify(rec.breakdown.limitations),
        },
        update: {
          score: rec.breakdown.totalScore,
          capabilityScore: rec.breakdown.capabilityScore,
          capacityScore: rec.breakdown.capacityScore,
          deadlineScore: rec.breakdown.deadlineScore,
          qualityScore: rec.breakdown.qualityScore,
          trustScore: rec.breakdown.trustScore,
          matchCategory: rec.breakdown.matchCategory,
          matchedCapabilities: rec.breakdown.matchedCapabilities.join(", "),
          reasonsJson: JSON.stringify(rec.breakdown.reasons),
          limitationsJson: JSON.stringify(rec.breakdown.limitations),
        },
      });
    }

    return NextResponse.json({
      weights,
      formula: "Score = 0.35 * Capability + 0.25 * Capacity + 0.15 * Quality + 0.15 * Deadline + 0.10 * Trust",
      recommendations,
    });
  } catch (error: any) {
    console.error("Recommendations GET error:", error);
    return NextResponse.json({ error: error.message || "Failed to calculate recommendations" }, { status: 500 });
  }
}
