import { NextResponse } from "next/server";
import prisma from "@/lib/prisma";
import { getSessionUser } from "@/lib/auth";
import { orderSchema } from "@/lib/validation";
import { logAuditEvent, createNotification } from "@/lib/audit";

export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  try {
    const session = await getSessionUser();
    const { searchParams } = new URL(req.url);
    const category = searchParams.get("category");
    const status = searchParams.get("status");
    const search = searchParams.get("search");
    const scope = searchParams.get("scope"); // "mine" or "marketplace"

    const where: any = {};

    if (category) {
      where.category = category;
    }

    if (status) {
      where.status = status;
    }

    if (search) {
      where.OR = [
        { title: { contains: search } },
        { orderNumber: { contains: search } },
        { requiredCapabilities: { contains: search } },
      ];
    }

    if (scope === "mine" && session?.businessId) {
      where.OR = [
        { ownerBusinessId: session.businessId },
        { allocations: { some: { businessId: session.businessId } } },
      ];
    }

    const orders = await prisma.order.findMany({
      where,
      include: {
        ownerBusiness: {
          select: {
            id: true,
            name: true,
            category: true,
            location: true,
            verificationStatus: true,
            trustScore: true,
          },
        },
        allocations: {
          include: {
            business: {
              select: { id: true, name: true, location: true },
            },
          },
        },
      },
      orderBy: { createdAt: "desc" },
    });

    return NextResponse.json({ orders });
  } catch (error: any) {
    console.error("Orders GET error:", error);
    return NextResponse.json({ error: error.message || "Failed to fetch orders" }, { status: 500 });
  }
}

export async function POST(req: Request) {
  try {
    const session = await getSessionUser();
    if (!session || !session.businessId) {
      return NextResponse.json({ error: "Unauthorized. Must be signed into a business profile." }, { status: 401 });
    }

    const body = await req.json();
    const parsed = orderSchema.safeParse(body);

    if (!parsed.success) {
      return NextResponse.json(
        { error: "Validation failed", details: parsed.error.flatten().fieldErrors },
        { status: 400 }
      );
    }

    const data = parsed.data;

    // Fetch owner business capacity
    const ownerBusiness = await prisma.business.findUnique({
      where: { id: session.businessId },
    });

    if (!ownerBusiness) {
      return NextResponse.json({ error: "Business not found" }, { status: 404 });
    }

    // Validate self-allocation does not exceed total order or owner capacity
    if (data.selfAllocatedQty > data.totalQuantity) {
      return NextResponse.json(
        { error: "In-house self-allocation cannot exceed the total order quantity" },
        { status: 400 }
      );
    }

    if (data.selfAllocatedQty > ownerBusiness.availableCapacity) {
      return NextResponse.json(
        {
          error: `In-house self-allocation (${data.selfAllocatedQty}) exceeds your remaining available capacity (${ownerBusiness.availableCapacity} ${ownerBusiness.capacityUnit})`,
        },
        { status: 400 }
      );
    }

    const orderNumber = `ORD-${new Date().getFullYear()}-${Math.floor(10000 + Math.random() * 90000)}`;
    const totalBudget = data.totalQuantity * data.targetUnitCost;

    // Determine initial status:
    // If selfAllocatedQty < totalQuantity, order needs collaboration -> OPEN_FOR_COLLABORATION
    // Else -> PRODUCTION_SCHEDULED
    const initialStatus =
      data.selfAllocatedQty < data.totalQuantity ? "OPEN_FOR_COLLABORATION" : "PRODUCTION_SCHEDULED";

    const order = await prisma.$transaction(async (tx) => {
      const newOrder = await tx.order.create({
        data: {
          orderNumber,
          title: data.title,
          description: data.description,
          category: data.category,
          totalQuantity: data.totalQuantity,
          quantityUnit: data.quantityUnit,
          targetUnitCost: data.targetUnitCost,
          totalBudget,
          deadline: new Date(data.deadline),
          deliveryLocation: data.deliveryLocation,
          technicalSpecs: data.technicalSpecs,
          qualityRequirements: data.qualityRequirements,
          requiredCapabilities: data.requiredCapabilities,
          status: initialStatus,
          selfAllocatedQty: data.selfAllocatedQty,
          ownerBusinessId: session.businessId!,
        },
      });

      // If self-allocated quantity > 0, create in-house work allocation and commit capacity
      if (data.selfAllocatedQty > 0) {
        await tx.workAllocation.create({
          data: {
            orderId: newOrder.id,
            businessId: session.businessId!,
            allocatedQuantity: data.selfAllocatedQty,
            agreedUnitPrice: data.targetUnitCost,
            totalAmount: data.selfAllocatedQty * data.targetUnitCost,
            agreedDeadline: new Date(data.deadline),
            status: "CONFIRMED",
            notes: "Lead manufacturer in-house production allocation",
          },
        });

        // Deduct committed capacity
        await tx.business.update({
          where: { id: session.businessId! },
          data: {
            committedCapacity: { increment: data.selfAllocatedQty },
            availableCapacity: { decrement: data.selfAllocatedQty },
          },
        });
      }

      return newOrder;
    });

    await logAuditEvent({
      eventType: "ORDER",
      action: "CREATE",
      actorId: session.id,
      actorName: session.name,
      businessId: session.businessId,
      targetType: "Order",
      targetId: order.id,
      metadata: {
        orderNumber: order.orderNumber,
        totalQuantity: order.totalQuantity,
        selfAllocatedQty: order.selfAllocatedQty,
        needsCollaboration: data.selfAllocatedQty < data.totalQuantity,
      },
    });

    await createNotification({
      userId: session.id,
      businessId: session.businessId,
      title: `Order Created: ${order.orderNumber}`,
      message: `Your bulk order for ${order.totalQuantity.toLocaleString()} ${order.quantityUnit} was published successfully.`,
      type: "SYSTEM_ALERT",
      link: `/orders/${order.id}`,
    });

    return NextResponse.json({ success: true, order }, { status: 201 });
  } catch (error: any) {
    console.error("Order POST error:", error);
    return NextResponse.json({ error: error.message || "Failed to create order" }, { status: 500 });
  }
}
