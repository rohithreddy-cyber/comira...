import { NextResponse } from "next/server";
import prisma from "@/lib/prisma";
import { getSessionUser } from "@/lib/auth";
import { logAuditEvent, createNotification } from "@/lib/audit";

export async function GET(req: Request) {
  try {
    const session = await getSessionUser();
    if (!session || !session.businessId) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const { searchParams } = new URL(req.url);
    const orderId = searchParams.get("orderId");

    const where: any = {};
    if (orderId) where.orderId = orderId;

    if (session.role !== "ADMIN") {
      where.OR = [
        { ownerBusinessId: session.businessId },
        { partnerBusinessId: session.businessId },
      ];
    }

    const agreements = await prisma.agreement.findMany({
      where,
      include: {
        order: { select: { id: true, orderNumber: true, title: true, quantityUnit: true } },
        ownerBusiness: { select: { id: true, name: true, location: true, email: true } },
        partnerBusiness: { select: { id: true, name: true, location: true, email: true } },
        revisions: { orderBy: { revisionNumber: "desc" } },
      },
      orderBy: { createdAt: "desc" },
    });

    return NextResponse.json({ agreements });
  } catch (error: any) {
    console.error("Agreements GET error:", error);
    return NextResponse.json({ error: error.message || "Failed to fetch agreements" }, { status: 500 });
  }
}

export async function POST(req: Request) {
  try {
    const session = await getSessionUser();
    if (!session || !session.businessId) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const body = await req.json();
    const { agreementId, action, changeSummary, newTerms } = body;

    const agreement = await prisma.agreement.findUnique({
      where: { id: agreementId },
      include: { order: true, revisions: true },
    });

    if (!agreement) {
      return NextResponse.json({ error: "Agreement not found" }, { status: 404 });
    }

    const isOwner = agreement.ownerBusinessId === session.businessId;
    const isPartner = agreement.partnerBusinessId === session.businessId;

    if (!isOwner && !isPartner && session.role !== "ADMIN") {
      return NextResponse.json({ error: "Forbidden: You are not a party to this agreement" }, { status: 403 });
    }

    // Action: SIGN
    if (action === "SIGN") {
      const data: any = {};
      if (isOwner) {
        data.ownerSignedAt = new Date();
      }
      if (isPartner) {
        data.partnerSignedAt = new Date();
      }

      // If both signed (or now will be both signed), advance status
      const willBothBeSigned =
        (agreement.ownerSignedAt || data.ownerSignedAt) && (agreement.partnerSignedAt || data.partnerSignedAt);

      if (willBothBeSigned) {
        data.status = "ACCEPTED";
      }

      const updated = await prisma.agreement.update({
        where: { id: agreementId },
        data,
      });

      await logAuditEvent({
        eventType: "AGREEMENT",
        action: "SIGN",
        actorId: session.id,
        actorName: session.name,
        businessId: session.businessId,
        targetType: "Agreement",
        targetId: agreementId,
        metadata: { agreementNumber: agreement.agreementNumber, status: updated.status },
      });

      const recipientId = isOwner ? agreement.partnerBusinessId : agreement.ownerBusinessId;
      await createNotification({
        businessId: recipientId,
        title: willBothBeSigned ? "Agreement Fully Executed" : "Agreement Signed by Counterpart",
        message: `${session.businessName} signed agreement #${agreement.agreementNumber}. Status: ${updated.status}.`,
        type: "AGREEMENT_STATUS",
        link: `/agreements`,
      });

      return NextResponse.json({ success: true, agreement: updated });
    }

    // Action: REVISE
    if (action === "REVISE") {
      if (!newTerms || !changeSummary) {
        return NextResponse.json({ error: "Revision requires new terms text and a change summary" }, { status: 400 });
      }

      const nextRevNum = agreement.revisions.length + 1;

      const result = await prisma.$transaction(async (tx) => {
        await tx.agreementRevision.create({
          data: {
            agreementId,
            revisionNumber: nextRevNum,
            changeSummary,
            termsText: newTerms,
            createdById: session.id,
          },
        });

        const updated = await tx.agreement.update({
          where: { id: agreementId },
          data: {
            termsText: newTerms,
            status: "PENDING_ACCEPTANCE",
            ownerSignedAt: isOwner ? new Date() : null,
            partnerSignedAt: isPartner ? new Date() : null,
          },
        });

        return updated;
      });

      await logAuditEvent({
        eventType: "AGREEMENT",
        action: "REVISE",
        actorId: session.id,
        actorName: session.name,
        businessId: session.businessId,
        targetType: "Agreement",
        targetId: agreementId,
        metadata: { revisionNumber: nextRevNum, changeSummary },
      });

      return NextResponse.json({ success: true, agreement: result });
    }

    return NextResponse.json({ error: "Invalid action" }, { status: 400 });
  } catch (error: any) {
    console.error("Agreements POST error:", error);
    return NextResponse.json({ error: error.message || "Failed to process agreement" }, { status: 500 });
  }
}
