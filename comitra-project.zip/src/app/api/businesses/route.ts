import { NextResponse } from "next/server";
import prisma from "@/lib/prisma";

export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  try {
    const { searchParams } = new URL(req.url);
    const category = searchParams.get("category");
    const location = searchParams.get("location");
    const search = searchParams.get("search");
    const minCapacity = searchParams.get("minCapacity");

    const where: any = {
      isSuspended: false,
    };

    if (category) {
      where.category = category;
    }

    if (location) {
      where.location = { contains: location };
    }

    if (minCapacity) {
      where.availableCapacity = { gte: parseFloat(minCapacity) };
    }

    if (search) {
      where.OR = [
        { name: { contains: search } },
        { category: { contains: search } },
        { location: { contains: search } },
        { capabilities: { some: { capabilityName: { contains: search } } } },
      ];
    }

    const businesses = await prisma.business.findMany({
      where,
      select: {
        id: true,
        name: true,
        registrationNumber: true,
        description: true,
        category: true,
        location: true,
        address: true,
        phone: true,
        email: true,
        website: true,
        totalCapacity: true,
        committedCapacity: true,
        availableCapacity: true,
        capacityUnit: true,
        verificationStatus: true,
        trustScore: true,
        capabilities: true,
        resources: true,
        receivedReviews: {
          select: {
            id: true,
            score: true,
            feedback: true,
            createdAt: true,
            reviewerBusiness: { select: { name: true } },
          },
        },
      },
      orderBy: { trustScore: "desc" },
    });

    return NextResponse.json({ businesses });
  } catch (error: any) {
    console.error("Businesses GET error:", error);
    return NextResponse.json({ error: error.message || "Failed to fetch businesses" }, { status: 500 });
  }
}
