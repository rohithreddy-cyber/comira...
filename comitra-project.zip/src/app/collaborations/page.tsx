"use client";

import React, { useState, useEffect } from "react";
import { useAuth } from "@/context/AuthContext";
import {
  Users,
  CheckCircle2,
  XCircle,
  Clock,
  ArrowRight,
  Factory,
  ShieldAlert,
  AlertTriangle,
  RotateCcw,
} from "lucide-react";

export default function CollaborationsPage() {
  const { user } = useAuth();
  const [requests, setRequests] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [actionLoading, setActionLoading] = useState<string | null>(null);
  const [statusMsg, setStatusMsg] = useState<{ text: string; error?: boolean } | null>(null);
  const [tab, setTab] = useState<"received" | "sent">("received");

  const loadRequests = async () => {
    setLoading(true);
    try {
      const res = await fetch("/api/collaboration/requests");
      const data = await res.json();
      setRequests(data.requests || []);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadRequests();
  }, [user]);

  const handleRespond = async (requestId: string, status: "ACCEPTED" | "REJECTED") => {
    setActionLoading(requestId);
    setStatusMsg(null);

    try {
      const res = await fetch(`/api/collaboration/requests/${requestId}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          status,
          responseNote: status === "ACCEPTED" ? "Accepted via partner portal" : "Declined due to scheduling",
        }),
      });

      const data = await res.json();
      setActionLoading(null);

      if (!res.ok) {
        setStatusMsg({ text: data.error || "Operation failed", error: true });
        return;
      }

      setStatusMsg({
        text:
          status === "ACCEPTED"
            ? "Invitation accepted! Production allocation created and digital agreement drafted."
            : "Invitation declined.",
      });
      loadRequests();
    } catch (err: any) {
      setActionLoading(null);
      setStatusMsg({ text: err.message || "Network error", error: true });
    }
  };

  const handleWithdraw = async (requestId: string) => {
    setActionLoading(requestId);
    try {
      const res = await fetch(`/api/collaboration/requests/${requestId}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "WITHDRAW" }),
      });
      setActionLoading(null);
      loadRequests();
    } catch (err) {
      setActionLoading(null);
    }
  };

  const receivedRequests = requests.filter((r) => r.receiverBusinessId === user?.businessId);
  const sentRequests = requests.filter((r) => r.senderBusinessId === user?.businessId);

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl">
        <div>
          <h1 className="text-2xl font-bold text-white flex items-center gap-2">
            <Users className="w-6 h-6 text-teal-400" />
            Collaboration Inquiries & Allocations
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Review incoming subcontract opportunities, confirm capacity commitments, and manage outgoing invitations
          </p>
        </div>
      </div>

      {statusMsg && (
        <div
          className={`p-4 rounded-xl text-xs flex items-center gap-2 shadow ${
            statusMsg.error
              ? "bg-red-950/80 border border-red-800 text-red-200"
              : "bg-emerald-950/80 border border-emerald-800 text-emerald-200"
          }`}
        >
          {statusMsg.error ? <AlertTriangle className="w-4 h-4" /> : <CheckCircle2 className="w-4 h-4" />}
          <span>{statusMsg.text}</span>
        </div>
      )}

      {/* Tabs */}
      <div className="flex gap-2 border-b border-slate-800 pb-2 text-xs font-semibold">
        <button
          onClick={() => setTab("received")}
          className={`px-4 py-2 rounded-lg transition flex items-center gap-2 ${
            tab === "received" ? "bg-teal-600 text-white" : "text-slate-400 hover:text-slate-200"
          }`}
        >
          Received Inquiries ({receivedRequests.length})
        </button>
        <button
          onClick={() => setTab("sent")}
          className={`px-4 py-2 rounded-lg transition flex items-center gap-2 ${
            tab === "sent" ? "bg-teal-600 text-white" : "text-slate-400 hover:text-slate-200"
          }`}
        >
          Sent Invitations ({sentRequests.length})
        </button>
      </div>

      {/* Content */}
      {loading ? (
        <div className="flex justify-center py-12">
          <div className="w-8 h-8 border-4 border-teal-500 border-t-transparent rounded-full animate-spin" />
        </div>
      ) : (tab === "received" ? receivedRequests : sentRequests).length === 0 ? (
        <div className="text-center py-16 bg-slate-900 border border-slate-800 rounded-2xl space-y-2">
          <Users className="w-8 h-8 text-slate-600 mx-auto" />
          <p className="text-xs text-slate-400">No {tab} collaboration inquiries active at this moment.</p>
        </div>
      ) : (
        <div className="space-y-4">
          {(tab === "received" ? receivedRequests : sentRequests).map((req) => (
            <div
              key={req.id}
              className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-4"
            >
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-mono text-xs font-bold text-teal-400 bg-teal-500/10 px-2.5 py-0.5 rounded border border-teal-500/20">
                      {req.order?.orderNumber}
                    </span>
                    <span
                      className={`px-2 py-0.5 rounded text-[10px] font-semibold ${
                        req.status === "ACCEPTED"
                          ? "bg-emerald-500/20 text-emerald-300 border border-emerald-500/30"
                          : req.status === "REJECTED"
                          ? "bg-red-500/20 text-red-300 border border-red-500/30"
                          : req.status === "WITHDRAWN"
                          ? "bg-slate-700 text-slate-400"
                          : "bg-amber-500/20 text-amber-300 border border-amber-500/30"
                      }`}
                    >
                      {req.status}
                    </span>
                  </div>
                  <h3 className="text-base font-bold text-white mt-1">{req.order?.title}</h3>
                  <p className="text-xs text-slate-400">
                    {tab === "received"
                      ? `From: ${req.senderBusiness?.name}`
                      : `To: ${req.receiverBusiness?.name}`}
                  </p>
                </div>

                <div className="text-right">
                  <div className="text-xs text-slate-400">Proposed Quantity</div>
                  <div className="text-xl font-bold font-mono text-white">
                    {req.proposedQuantity.toLocaleString()} {req.order?.quantityUnit || "units"}
                  </div>
                  <div className="text-[11px] text-teal-400">
                    ₹{req.unitPrice} / unit • Total: ₹{(req.proposedQuantity * req.unitPrice).toLocaleString()}
                  </div>
                </div>
              </div>

              {/* Requirement details */}
              <div className="p-3 rounded-xl bg-slate-950 border border-slate-800/80 text-xs space-y-1">
                <span className="font-semibold text-slate-300">Technical Scope & Requirements:</span>
                <p className="text-slate-400">{req.requirements || "Standard manufacturing drawings"}</p>
                {req.message && (
                  <p className="text-slate-300 italic pt-1">“{req.message}”</p>
                )}
                {req.responseNote && (
                  <p className="text-teal-300 pt-1 font-mono text-[11px]">Partner response: {req.responseNote}</p>
                )}
              </div>

              {/* Action Buttons */}
              <div className="flex items-center justify-between pt-2 border-t border-slate-800/80 text-xs">
                <div className="text-slate-400 flex items-center gap-1 font-mono text-[11px]">
                  <Clock className="w-3.5 h-3.5" />
                  Target: {new Date(req.proposedDeadline).toLocaleDateString()}
                </div>

                <div className="flex items-center gap-2">
                  {tab === "received" && req.status === "PENDING" && (
                    <>
                      <button
                        onClick={() => handleRespond(req.id, "REJECTED")}
                        disabled={actionLoading === req.id}
                        className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-red-900/50 text-slate-300 hover:text-red-300 transition"
                      >
                        Decline
                      </button>
                      <button
                        onClick={() => handleRespond(req.id, "ACCEPTED")}
                        disabled={actionLoading === req.id}
                        className="px-4 py-1.5 rounded-lg bg-teal-600 hover:bg-teal-500 text-white font-semibold shadow transition"
                      >
                        {actionLoading === req.id ? "Confirming..." : "Accept Allocation"}
                      </button>
                    </>
                  )}

                  {tab === "sent" && req.status === "PENDING" && (
                    <button
                      onClick={() => handleWithdraw(req.id)}
                      disabled={actionLoading === req.id}
                      className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 transition"
                    >
                      Withdraw Request
                    </button>
                  )}

                  <a
                    href={`/orders/${req.orderId}`}
                    className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 flex items-center gap-1 font-medium transition"
                  >
                    View Order Details
                    <ArrowRight className="w-3.5 h-3.5" />
                  </a>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
