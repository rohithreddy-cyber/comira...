"use client";

import React, { useState, useEffect } from "react";
import { useAuth } from "@/context/AuthContext";
import {
  CreditCard,
  Printer,
  CheckCircle2,
  AlertTriangle,
  Clock,
  ArrowRight,
  ShieldCheck,
  Plus,
  DollarSign,
  FileText,
} from "lucide-react";

export default function InvoicesPage() {
  const { user } = useAuth();
  const [invoices, setInvoices] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedInvoice, setSelectedInvoice] = useState<any>(null);
  const [payLoading, setPayLoading] = useState(false);
  const [createModalOpen, setCreateModalOpen] = useState(false);
  const [orders, setOrders] = useState<any[]>([]);
  const [msg, setMsg] = useState<{ text: string; error?: boolean } | null>(null);

  const [newInv, setNewInv] = useState({
    orderId: "",
    recipientBusinessId: "",
    itemDescription: "Batch completion milestone billing",
    quantity: 1000,
    unitPrice: 450,
    taxRate: 18.0,
    dueDate: new Date(Date.now() + 14 * 24 * 60 * 60 * 1000).toISOString().split("T")[0],
    notes: "Demonstration milestone invoice",
  });

  const loadInvoices = async () => {
    setLoading(true);
    try {
      const [invRes, ordRes] = await Promise.all([
        fetch("/api/invoices"),
        fetch("/api/orders?scope=mine"),
      ]);
      const invData = await invRes.json();
      const ordData = await ordRes.json();

      setInvoices(invData.invoices || []);
      setOrders(ordData.orders || []);

      if ((invData.invoices || []).length > 0 && !selectedInvoice) {
        setSelectedInvoice(invData.invoices[0]);
      }
      if ((ordData.orders || []).length > 0) {
        setNewInv((prev) => ({
          ...prev,
          orderId: ordData.orders[0].id,
          recipientBusinessId: ordData.orders[0].ownerBusinessId,
        }));
      }
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadInvoices();
  }, [user]);

  const handleSimulatePayment = async (invoiceId: string) => {
    setPayLoading(true);
    setMsg(null);

    try {
      const res = await fetch("/api/invoices", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          action: "SIMULATE_PAY",
          invoiceId,
          paymentMethod: "CoMitra Demonstration Simulated Escrow Settlement",
        }),
      });

      const data = await res.json();
      setPayLoading(false);

      if (!res.ok) {
        setMsg({ text: data.error || "Payment simulation failed", error: true });
        return;
      }

      setMsg({
        text: `Simulated payment successful! Reference: ${data.payment?.referenceNumber}. Invoice marked as PAID.`,
      });
      loadInvoices();
      if (data.updatedInvoice) {
        setSelectedInvoice((prev: any) => ({ ...prev, ...data.updatedInvoice }));
      }
    } catch (err: any) {
      setPayLoading(false);
      setMsg({ text: err.message || "Network error", error: true });
    }
  };

  const handleCreateInvoice = async (e: React.FormEvent) => {
    e.preventDefault();
    setPayLoading(true);
    setMsg(null);

    try {
      const res = await fetch("/api/invoices", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(newInv),
      });

      const data = await res.json();
      setPayLoading(false);

      if (!res.ok) {
        setMsg({ text: data.error || "Failed to issue invoice", error: true });
        return;
      }

      setMsg({ text: `Invoice #${data.invoice.invoiceNumber} created and dispatched successfully!` });
      setCreateModalOpen(false);
      loadInvoices();
    } catch (err: any) {
      setPayLoading(false);
      setMsg({ text: err.message || "Network error", error: true });
    }
  };

  return (
    <div className="space-y-6">
      {/* Banner */}
      <div className="no-print flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl">
        <div>
          <h1 className="text-2xl font-bold text-white flex items-center gap-2">
            <CreditCard className="w-6 h-6 text-teal-400" />
            Invoices & Settlement Records
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Itemized GST billing, milestone verification, and simulated escrow release workflows
          </p>
        </div>

        <div className="flex items-center gap-2">
          {selectedInvoice && (
            <button
              onClick={() => window.print()}
              className="inline-flex items-center gap-2 px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold text-xs border border-slate-700 transition"
            >
              <Printer className="w-4 h-4 text-teal-400" />
              Print Tax Invoice
            </button>
          )}

          <button
            onClick={() => setCreateModalOpen(true)}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-teal-600 hover:bg-teal-500 text-white font-semibold text-xs shadow transition"
          >
            <Plus className="w-4 h-4" />
            Issue Milestone Invoice
          </button>
        </div>
      </div>

      {msg && (
        <div
          className={`no-print p-4 rounded-xl text-xs flex items-center gap-2 shadow ${
            msg.error
              ? "bg-red-950/80 border border-red-800 text-red-200"
              : "bg-emerald-950/80 border border-emerald-800 text-emerald-200"
          }`}
        >
          {msg.error ? <AlertTriangle className="w-4 h-4" /> : <CheckCircle2 className="w-4 h-4" />}
          <span>{msg.text}</span>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Invoice List (Hidden in Print) */}
        <div className="no-print space-y-3">
          <h2 className="text-sm font-bold text-white">Invoice Records</h2>
          {invoices.length === 0 ? (
            <p className="text-xs text-slate-500 py-6">No invoices recorded yet.</p>
          ) : (
            invoices.map((inv) => {
              const isSelected = selectedInvoice?.id === inv.id;
              return (
                <div
                  key={inv.id}
                  onClick={() => setSelectedInvoice(inv)}
                  className={`p-4 rounded-xl border text-xs cursor-pointer transition ${
                    isSelected
                      ? "bg-teal-950/40 border-teal-500/60 shadow"
                      : "bg-slate-900 border-slate-800 hover:border-slate-700"
                  }`}
                >
                  <div className="flex justify-between items-center mb-1">
                    <span className="font-mono text-teal-400 font-bold">{inv.invoiceNumber}</span>
                    <span
                      className={`px-2 py-0.5 rounded text-[10px] font-semibold ${
                        inv.status === "PAID"
                          ? "bg-emerald-500/20 text-emerald-300"
                          : "bg-blue-500/20 text-blue-300"
                      }`}
                    >
                      {inv.status}
                    </span>
                  </div>
                  <p className="font-semibold text-white truncate">{inv.itemDescription}</p>
                  <p className="text-[11px] text-slate-400 mt-0.5">
                    Issuer: {inv.issuerBusiness?.name} → {inv.recipientBusiness?.name}
                  </p>
                  <div className="flex justify-between items-center mt-2 pt-2 border-t border-slate-800/80">
                    <span className="text-slate-400">Total with 18% GST</span>
                    <span className="font-mono font-bold text-white">₹{inv.amountTotal.toLocaleString()}</span>
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Printable Tax Invoice Document View */}
        <div className="lg:col-span-2">
          {selectedInvoice ? (
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-8 sm:p-10 shadow-2xl space-y-6 text-slate-200 print:bg-white print:text-black print:border-none print:shadow-none">
              <div className="border-b border-slate-800 pb-6 print:border-black flex justify-between items-start">
                <div>
                  <span className="text-[10px] font-mono font-bold uppercase tracking-wider text-teal-400 print:text-black">
                    TAX INVOICE / GST COMPLIANT
                  </span>
                  <h2 className="text-2xl font-extrabold text-white print:text-black mt-1 font-mono">
                    {selectedInvoice.invoiceNumber}
                  </h2>
                  <p className="text-xs text-slate-400 print:text-gray-600 mt-0.5">
                    Order Ref: {selectedInvoice.order?.orderNumber} — {selectedInvoice.order?.title}
                  </p>
                </div>
                <div className="text-right">
                  <span
                    className={`px-3 py-1 rounded-full text-xs font-bold ${
                      selectedInvoice.status === "PAID"
                        ? "bg-emerald-500/20 text-emerald-300 print:text-black"
                        : "bg-blue-500/20 text-blue-300 print:text-black"
                    }`}
                  >
                    PAYMENT: {selectedInvoice.status}
                  </span>
                  <div className="text-[10px] text-slate-500 print:text-gray-500 mt-1 font-mono">
                    Issued: {new Date(selectedInvoice.issuedDate).toLocaleDateString()}
                  </div>
                </div>
              </div>

              {/* Billed By & Billed To */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 p-4 rounded-xl bg-slate-950 border border-slate-800 print:bg-white print:border-gray-300 text-xs">
                <div>
                  <span className="text-[10px] uppercase font-bold text-teal-400 print:text-gray-700">
                    Billed By (Issuer)
                  </span>
                  <h4 className="font-bold text-white print:text-black text-sm mt-0.5">
                    {selectedInvoice.issuerBusiness?.name}
                  </h4>
                  <p className="text-slate-400 print:text-gray-600 mt-1">
                    {selectedInvoice.issuerBusiness?.location}
                  </p>
                  <p className="text-slate-400 print:text-gray-600">
                    Email: {selectedInvoice.issuerBusiness?.email}
                  </p>
                </div>

                <div>
                  <span className="text-[10px] uppercase font-bold text-blue-400 print:text-gray-700">
                    Billed To (Recipient)
                  </span>
                  <h4 className="font-bold text-white print:text-black text-sm mt-0.5">
                    {selectedInvoice.recipientBusiness?.name}
                  </h4>
                  <p className="text-slate-400 print:text-gray-600 mt-1">
                    {selectedInvoice.recipientBusiness?.location}
                  </p>
                  <p className="text-slate-400 print:text-gray-600">
                    Email: {selectedInvoice.recipientBusiness?.email}
                  </p>
                </div>
              </div>

              {/* Line Items Table */}
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs border border-slate-800 print:border-gray-300 rounded-xl overflow-hidden">
                  <thead className="bg-slate-950 print:bg-gray-100 text-slate-400 print:text-black border-b border-slate-800 print:border-gray-300 text-[10px] uppercase">
                    <tr>
                      <th className="py-2.5 px-3">Description</th>
                      <th className="py-2.5 px-3 text-right">Quantity</th>
                      <th className="py-2.5 px-3 text-right">Unit Rate (₹)</th>
                      <th className="py-2.5 px-3 text-right">Subtotal (₹)</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800 print:divide-gray-200">
                    <tr>
                      <td className="py-3 px-3 text-white print:text-black font-medium">
                        {selectedInvoice.itemDescription}
                      </td>
                      <td className="py-3 px-3 text-right font-mono">{selectedInvoice.quantity.toLocaleString()}</td>
                      <td className="py-3 px-3 text-right font-mono">{selectedInvoice.unitPrice.toFixed(2)}</td>
                      <td className="py-3 px-3 text-right font-mono font-semibold">
                        ₹{selectedInvoice.amountSubtotal.toLocaleString()}
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>

              {/* Tax & Total Calculation */}
              <div className="flex justify-end text-xs">
                <div className="w-72 space-y-2 p-4 rounded-xl bg-slate-950 border border-slate-800 print:bg-white print:border-gray-300">
                  <div className="flex justify-between text-slate-400 print:text-gray-600">
                    <span>Taxable Subtotal:</span>
                    <span className="font-mono text-white print:text-black font-semibold">
                      ₹{selectedInvoice.amountSubtotal.toLocaleString()}
                    </span>
                  </div>
                  <div className="flex justify-between text-slate-400 print:text-gray-600">
                    <span>Applicable GST (18.0%):</span>
                    <span className="font-mono text-white print:text-black font-semibold">
                      ₹{selectedInvoice.taxAmount.toLocaleString()}
                    </span>
                  </div>
                  <div className="pt-2 border-t border-slate-800 print:border-gray-300 flex justify-between text-sm font-bold text-white print:text-black">
                    <span>Grand Total:</span>
                    <span className="font-mono text-teal-400 print:text-black">
                      ₹{selectedInvoice.amountTotal.toLocaleString()}
                    </span>
                  </div>
                </div>
              </div>

              {/* Simulated Notice & Payment Details */}
              <div className="p-3 rounded-lg bg-slate-950 border border-slate-800 print:border-gray-300 text-[11px] space-y-1">
                <p className="text-amber-400 font-semibold print:text-black">
                  Demonstration Simulated Invoice & Escrow:
                </p>
                <p className="text-slate-400 print:text-gray-600">
                  Payment flows are digitally recorded and simulated for academic project review. Due date:{" "}
                  {new Date(selectedInvoice.dueDate).toLocaleDateString()}.
                </p>
                {selectedInvoice.paidDate && (
                  <p className="text-emerald-400 font-mono print:text-black">
                    Paid on: {new Date(selectedInvoice.paidDate).toLocaleString()} via{" "}
                    {selectedInvoice.paymentMethod || "Demonstration simulated transfer"}
                  </p>
                )}
              </div>

              {/* Simulate Pay Action (Hidden in Print) */}
              {selectedInvoice.status !== "PAID" && (
                <div className="no-print pt-2 flex justify-end">
                  <button
                    onClick={() => handleSimulatePayment(selectedInvoice.id)}
                    disabled={payLoading}
                    className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-xs shadow transition disabled:opacity-50"
                  >
                    <CheckCircle2 className="w-4 h-4" />
                    {payLoading ? "Processing Payment..." : "Simulate Payment Release"}
                  </button>
                </div>
              )}
            </div>
          ) : (
            <div className="text-center py-16 bg-slate-900 border border-slate-800 rounded-2xl text-xs text-slate-500">
              Select an invoice from the sidebar to inspect tax breakdown.
            </div>
          )}
        </div>
      </div>

      {/* Modal: Issue Invoice */}
      {createModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 max-w-lg w-full space-y-4 shadow-2xl">
            <div className="flex justify-between items-center border-b border-slate-800 pb-3">
              <h3 className="text-base font-bold text-white">Issue Milestone Tax Invoice</h3>
              <button onClick={() => setCreateModalOpen(false)} className="text-slate-400 hover:text-white">
                ✕
              </button>
            </div>

            <form onSubmit={handleCreateInvoice} className="space-y-4 text-xs">
              <div>
                <label className="block text-slate-300 mb-1">Select Order</label>
                <select
                  value={newInv.orderId}
                  onChange={(e) => {
                    const sel = orders.find((o) => o.id === e.target.value);
                    if (sel) {
                      setNewInv({
                        ...newInv,
                        orderId: sel.id,
                        recipientBusinessId: sel.ownerBusinessId,
                      });
                    }
                  }}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-white"
                >
                  {orders.map((o) => (
                    <option key={o.id} value={o.id}>
                      {o.orderNumber} — {o.title}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-slate-300 mb-1">Line Item Description</label>
                <input
                  type="text"
                  required
                  value={newInv.itemDescription}
                  onChange={(e) => setNewInv({ ...newInv, itemDescription: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-white"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 mb-1">Milestone Quantity</label>
                  <input
                    type="number"
                    required
                    min="1"
                    value={newInv.quantity}
                    onChange={(e) => setNewInv({ ...newInv, quantity: parseFloat(e.target.value) || 0 })}
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-white font-mono"
                  />
                </div>
                <div>
                  <label className="block text-slate-300 mb-1">Unit Rate (₹)</label>
                  <input
                    type="number"
                    required
                    min="1"
                    value={newInv.unitPrice}
                    onChange={(e) => setNewInv({ ...newInv, unitPrice: parseFloat(e.target.value) || 0 })}
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-white font-mono"
                  />
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setCreateModalOpen(false)}
                  className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={payLoading}
                  className="px-4 py-2 bg-teal-600 hover:bg-teal-500 text-white rounded-lg font-semibold disabled:opacity-50"
                >
                  {payLoading ? "Issuing..." : "Issue & Transmit Invoice"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
