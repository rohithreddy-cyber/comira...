import prisma from "./prisma";
import { MatchingFactorBreakdown } from "@/types";

export interface ScoringWeights {
  capabilityWeight: number; // 0.35
  capacityWeight: number;   // 0.25
  qualityWeight: number;    // 0.15
  deadlineWeight: number;   // 0.15
  trustWeight: number;      // 0.10
}

export const DEFAULT_WEIGHTS: ScoringWeights = {
  capabilityWeight: 0.35,
  capacityWeight: 0.25,
  qualityWeight: 0.15,
  deadlineWeight: 0.15,
  trustWeight: 0.10,
};

export async function computePartnerRecommendations(orderId: string, weights: ScoringWeights = DEFAULT_WEIGHTS) {
  const order = await prisma.order.findUnique({
    where: { id: orderId },
    include: {
      ownerBusiness: true,
      allocations: true,
    },
  });

  if (!order) {
    throw new Error("Order not found");
  }

  // Calculate remaining unallocated quantity needed
  const totalAllocated = order.allocations.reduce((sum, a) => {
    if (a.status !== "CANCELLED") {
      return sum + a.allocatedQuantity;
    }
    return sum;
  }, 0) + (order.selfAllocatedQty || 0);

  const neededQuantity = Math.max(0, order.totalQuantity - totalAllocated);

  const requiredCaps = order.requiredCapabilities
    .split(",")
    .map((c) => c.trim().toLowerCase())
    .filter(Boolean);

  // Fetch all other active businesses
  const candidateBusinesses = await prisma.business.findMany({
    where: {
      id: { not: order.ownerBusinessId },
      isSuspended: false,
    },
    include: {
      capabilities: true,
      resources: true,
      verifications: true,
      receivedReviews: true,
    },
  });

  const orderDeadline = new Date(order.deadline);
  const daysUntilDeadline = Math.max(1, Math.ceil((orderDeadline.getTime() - Date.now()) / (1000 * 60 * 60 * 24)));

  const recommendations = [];

  for (const business of candidateBusinesses) {
    const reasons: string[] = [];
    const limitations: string[] = [];
    const matchedCaps: string[] = [];

    // 1. Capability Score
    let matchedCount = 0;
    for (const reqCap of requiredCaps) {
      const match = business.capabilities.find(
        (c) =>
          c.capabilityName.toLowerCase().includes(reqCap) ||
          reqCap.includes(c.capabilityName.toLowerCase()) ||
          (c.description && c.description.toLowerCase().includes(reqCap))
      );

      if (match) {
        matchedCount++;
        matchedCaps.push(match.capabilityName);
      }
    }

    const capabilityScore = requiredCaps.length > 0 ? Math.min(100, Math.round((matchedCount / requiredCaps.length) * 100)) : 70;

    if (matchedCaps.length > 0) {
      reasons.push(`Matched manufacturing capabilities: ${matchedCaps.join(", ")}`);
    } else {
      limitations.push(`Does not directly advertise core requirements (${order.requiredCapabilities})`);
    }

    // 2. Capacity Score
    let capacityScore = 0;
    if (neededQuantity <= 0) {
      capacityScore = 100;
      reasons.push(`Order is fully allocated; partner provides standby surge capacity`);
    } else if (business.availableCapacity >= neededQuantity) {
      capacityScore = 100;
      reasons.push(`Available capacity of ${business.availableCapacity.toLocaleString()} ${business.capacityUnit} comfortably handles the needed ${neededQuantity.toLocaleString()} units`);
    } else if (business.availableCapacity > 0) {
      const ratio = business.availableCapacity / neededQuantity;
      capacityScore = Math.min(100, Math.round(ratio * 100));
      reasons.push(`Can supply a partial allocation of up to ${business.availableCapacity.toLocaleString()} units (${Math.round(ratio * 100)}% of unallocated order)`);
      if (ratio < 0.5) {
        limitations.push(`Available capacity (${business.availableCapacity.toLocaleString()}) covers less than half of unallocated requirement`);
      }
    } else {
      capacityScore = 10;
      limitations.push(`Reported remaining capacity is exhausted or near zero`);
    }

    // 3. Deadline / Lead Time Score
    let maxLeadTime = 0;
    for (const cap of business.capabilities) {
      if (cap.leadTimeDays && cap.leadTimeDays > maxLeadTime) {
        maxLeadTime = cap.leadTimeDays;
      }
    }

    let deadlineScore = 80;
    if (maxLeadTime > 0) {
      if (maxLeadTime <= daysUntilDeadline * 0.7) {
        deadlineScore = 98;
        reasons.push(`Estimated production lead time (${maxLeadTime} days) is well within deadline window (${daysUntilDeadline} days)`);
      } else if (maxLeadTime <= daysUntilDeadline) {
        deadlineScore = 85;
        reasons.push(`Lead time (${maxLeadTime} days) fits within target deadline`);
      } else {
        deadlineScore = 40;
        limitations.push(`Standard lead time (${maxLeadTime} days) exceeds or is very tight against order deadline (${daysUntilDeadline} days)`);
      }
    } else {
      deadlineScore = 75;
    }

    // 4. Quality & Certification Score
    let qualityScore = 50;
    if (business.verificationStatus === "VERIFIED") {
      qualityScore = 90;
      reasons.push(`Business identity and regulatory credentials are fully verified`);
    } else if (business.verificationStatus === "PENDING") {
      qualityScore = 65;
      limitations.push(`Verification submission is currently pending administrator review`);
    } else {
      qualityScore = 30;
      limitations.push(`Business is unverified on the platform`);
    }

    const hasIso = business.capabilities.some(
      (c) => c.certifications && (c.certifications.includes("ISO") || c.certifications.includes("AS9100"))
    );
    if (hasIso) {
      qualityScore = Math.min(100, qualityScore + 10);
      reasons.push(`Holds quality standard certifications (ISO / Aerospace)`);
    }

    // 5. Historical Trust & Ratings Score
    let trustScore = business.trustScore || 85.0;
    if (business.receivedReviews.length > 0) {
      const avgScore =
        business.receivedReviews.reduce((sum, r) => sum + r.score, 0) / business.receivedReviews.length;
      trustScore = Math.round((avgScore / 5) * 100);
      reasons.push(`Proven performance track record: ${avgScore.toFixed(1)}/5 stars across ${business.receivedReviews.length} verified review(s)`);
    }

    // Normalized Total Score Calculation
    const totalScore = Math.round(
      capabilityScore * weights.capabilityWeight +
      capacityScore * weights.capacityWeight +
      qualityScore * weights.qualityWeight +
      deadlineScore * weights.deadlineWeight +
      trustScore * weights.trustWeight
    );

    let matchCategory: "EXCELLENT" | "HIGH" | "MODERATE" | "LOW" = "LOW";
    if (totalScore >= 85 && capabilityScore >= 70 && capacityScore >= 60) {
      matchCategory = "EXCELLENT";
    } else if (totalScore >= 70 && capabilityScore >= 50) {
      matchCategory = "HIGH";
    } else if (totalScore >= 50) {
      matchCategory = "MODERATE";
    } else {
      matchCategory = "LOW";
    }

    const breakdown: MatchingFactorBreakdown = {
      capabilityScore,
      capacityScore,
      deadlineScore,
      qualityScore,
      trustScore,
      totalScore,
      matchCategory,
      matchedCapabilities: matchedCaps,
      reasons,
      limitations,
    };

    recommendations.push({
      business,
      breakdown,
    });
  }

  // Sort descending by total score
  recommendations.sort((a, b) => b.breakdown.totalScore - a.breakdown.totalScore);

  return recommendations;
}
