import { z } from "zod";

export const registerSchema = z.object({
  name: z.string().min(2, "Name must be at least 2 characters"),
  email: z.string().email("Invalid email address"),
  password: z.string().min(8, "Password must be at least 8 characters"),
  role: z.enum(["OWNER", "PARTNER"]).default("OWNER"),
  businessName: z.string().min(2, "Business name is required"),
  registrationNumber: z.string().min(3, "Registration / GSTIN is required"),
  category: z.string().min(2, "Manufacturing category is required"),
  location: z.string().min(2, "Location is required"),
  address: z.string().min(5, "Address is required"),
  phone: z.string().min(8, "Phone number is required"),
  totalCapacity: z.number().positive("Total capacity must be greater than zero"),
  capacityUnit: z.string().default("units/month"),
});

export const loginSchema = z.object({
  email: z.string().email("Invalid email address"),
  password: z.string().min(1, "Password is required"),
});

export const orderSchema = z.object({
  title: z.string().min(5, "Order title must be at least 5 characters"),
  description: z.string().min(10, "Detailed description is required"),
  category: z.string().min(2, "Category is required"),
  totalQuantity: z.number().positive("Total quantity must be greater than 0"),
  quantityUnit: z.string().default("units"),
  targetUnitCost: z.number().positive("Target unit cost must be greater than 0"),
  deadline: z.string().refine((val) => !isNaN(Date.parse(val)), "Invalid deadline date"),
  deliveryLocation: z.string().min(3, "Delivery location is required"),
  technicalSpecs: z.string().min(10, "Technical specifications are required"),
  qualityRequirements: z.string().min(5, "Quality standards/certifications required"),
  requiredCapabilities: z.string().min(2, "Required capabilities are required (comma separated)"),
  selfAllocatedQty: z.number().min(0, "In-house allocation cannot be negative").default(0),
});

export const collaborationRequestSchema = z.object({
  orderId: z.string().min(1, "Order ID is required"),
  receiverBusinessId: z.string().min(1, "Partner Business ID is required"),
  proposedQuantity: z.number().positive("Proposed quantity must be greater than 0"),
  unitPrice: z.number().positive("Unit price must be greater than 0"),
  proposedDeadline: z.string().refine((val) => !isNaN(Date.parse(val)), "Invalid deadline date"),
  requirements: z.string().optional(),
  message: z.string().optional(),
});

export const respondRequestSchema = z.object({
  status: z.enum(["ACCEPTED", "REJECTED"]),
  responseNote: z.string().optional(),
});

export const productionUpdateSchema = z.object({
  orderId: z.string().min(1, "Order ID is required"),
  workAllocationId: z.string().min(1, "Work Allocation ID is required"),
  completedQuantity: z.number().nonnegative("Completed quantity cannot be negative"),
  statusNote: z.string().optional(),
  delayReason: z.string().optional(),
  delayDays: z.number().int().nonnegative().default(0),
  qualityPassed: z.boolean().default(true),
  qualityNotes: z.string().optional(),
});

export const invoiceSchema = z.object({
  orderId: z.string().min(1, "Order ID is required"),
  recipientBusinessId: z.string().min(1, "Recipient Business ID is required"),
  itemDescription: z.string().min(3, "Item description is required"),
  quantity: z.number().positive("Quantity must be greater than 0"),
  unitPrice: z.number().positive("Unit price must be greater than 0"),
  taxRate: z.number().nonnegative().default(18.0),
  dueDate: z.string().refine((val) => !isNaN(Date.parse(val)), "Invalid due date"),
  notes: z.string().optional(),
});

export const reviewSchema = z.object({
  orderId: z.string().min(1, "Order ID is required"),
  revieweeBusinessId: z.string().min(1, "Reviewee Business ID is required"),
  score: z.number().min(1).max(5),
  communicationRating: z.number().min(1).max(5),
  qualityRating: z.number().min(1).max(5),
  timelinessRating: z.number().min(1).max(5),
  feedback: z.string().min(10, "Review feedback must be at least 10 characters"),
});

export const capacityUpdateSchema = z.object({
  totalCapacity: z.number().positive("Total capacity must be positive"),
  availableCapacity: z.number().min(0, "Available capacity cannot be negative"),
  capacityUnit: z.string().min(1, "Capacity unit is required"),
});
