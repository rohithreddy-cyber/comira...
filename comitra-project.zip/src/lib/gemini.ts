/**
 * Optional Gemini AI Integration
 * Used strictly for supplemental decision explanations and summary narratives.
 * Core matching, allocation, and tracking work 100% autonomously without any AI key.
 */

export async function generateAiInsight(promptText: string): Promise<{ success: boolean; text: string; error?: string }> {
  const apiKey = process.env.GEMINI_API_KEY;

  if (!apiKey || apiKey.trim() === "") {
    return {
      success: false,
      text: "AI Insights is inactive: GEMINI_API_KEY is not configured in .env. Core algorithmic matching and data analytics are active and operating independently.",
    };
  }

  try {
    const url = `https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${apiKey}`;
    const response = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        contents: [
          {
            parts: [{ text: `You are CoMitra Industrial AI Copilot. Provide an objective, concise executive summary for manufacturing executives:\n\n${promptText}` }],
          },
        ],
      }),
    });

    if (!response.ok) {
      throw new Error(`Gemini API returned status ${response.status}`);
    }

    const data = await response.json();
    const candidateText = data.candidates?.[0]?.content?.parts?.[0]?.text;
    if (!candidateText) {
      throw new Error("No text content returned from Gemini model");
    }

    return {
      success: true,
      text: candidateText,
    };
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : "Failed to communicate with AI endpoint";
    return {
      success: false,
      text: "AI narrative temporarily unavailable. Rule-based analytics and data are unaffected.",
      error: message,
    };
  }
}
