import prisma from "./prisma";

export async function logAuditEvent({
  eventType,
  action,
  actorId,
  actorName,
  businessId,
  targetType,
  targetId,
  metadata,
}: {
  eventType: string;
  action: string;
  actorId?: string;
  actorName: string;
  businessId?: string;
  targetType: string;
  targetId: string;
  metadata?: Record<string, unknown>;
}) {
  try {
    return await prisma.auditEvent.create({
      data: {
        eventType,
        action,
        actorId,
        actorName,
        businessId,
        targetType,
        targetId,
        metadataJson: metadata ? JSON.stringify(metadata) : null,
      },
    });
  } catch (error) {
    console.error("Failed to log audit event:", error);
    return null;
  }
}

export async function createNotification({
  userId,
  businessId,
  title,
  message,
  type,
  link,
}: {
  userId?: string;
  businessId?: string;
  title: string;
  message: string;
  type: string;
  link?: string;
}) {
  try {
    return await prisma.notification.create({
      data: {
        userId,
        businessId,
        title,
        message,
        type,
        link,
      },
    });
  } catch (error) {
    console.error("Failed to create notification:", error);
    return null;
  }
}
