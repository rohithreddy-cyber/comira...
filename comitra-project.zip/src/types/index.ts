export type UserRole = "OWNER" | "PARTNER" | "ADMIN";

export type OrderStatus =
  | "DRAFT"
  | "OPEN_FOR_COLLABORATION"
  | "COLLABORATION_PENDING"
  | "PRODUCTION_SCHEDULED"
  | "IN_PRODUCTION"
  | "QUALITY_INSPECTION"
  | "READY_FOR_DELIVERY"
  | "COMPLETED"
  | "CANCELLED";

export type RequestStatus = "PENDING" | "ACCEPTED" | "REJECTED" | "WITHDRAWN";

export type AllocationStatus = "CONFIRMED" | "IN_PROGRESS" | "QUALITY_CHECK" | "COMPLETED" | "CANCELLED";

export type MilestoneStatus = "PENDING" | "IN_PROGRESS" | "COMPLETED" | "DELAYED";

export type AgreementStatus = "DRAFT" | "PENDING_ACCEPTANCE" | "ACCEPTED" | "REVISED" | "CANCELLED";

export type InvoiceStatus = "DRAFT" | "ISSUED" | "PAID" | "CANCELLED";

export interface SessionUser {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  businessId?: string | null;
  businessName?: string | null;
}

export interface MatchingFactorBreakdown {
  capabilityScore: number;
  capacityScore: number;
  deadlineScore: number;
  qualityScore: number;
  trustScore: number;
  totalScore: number;
  matchCategory: "EXCELLENT" | "HIGH" | "MODERATE" | "LOW";
  matchedCapabilities: string[];
  reasons: string[];
  limitations: string[];
}
