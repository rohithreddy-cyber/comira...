"use client";

import React, { useState, useEffect } from "react";
import Link from "next/navigation";
import { usePathname } from "next/navigation";
import { useAuth } from "@/context/AuthContext";
import {
  Factory,
  Layers,
  Users,
  FileText,
  CreditCard,
  Gauge,
  Bell,
  LogOut,
  ChevronDown,
  ShieldAlert,
  CheckCircle2,
  TrendingUp,
  BarChart3,
  Search,
  Sliders,
  Menu,
  X,
} from "lucide-react";

export default function Navbar() {
  const { user, logout, switchDemoUser } = useAuth();
  const pathname = usePathname();
  const [unreadCount, setUnreadCount] = useState(0);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [demoMenuOpen, setDemoMenuOpen] = useState(false);

  useEffect(() => {
    if (user) {
      fetch("/api/notifications")
        .then((res) => res.json())
        .then((data) => {
          if (data.unreadCount !== undefined) {
            setUnreadCount(data.unreadCount);
          }
        })
        .catch(() => {});
    }
  }, [user, pathname]);

  const navLinks = [
    { label: "Dashboard", href: "/dashboard", icon: Gauge },
    { label: "Orders", href: "/orders", icon: Layers },
    { label: "Collaborations", href: "/collaborations", icon: Users },
    { label: "Production", href: "/production", icon: Factory },
    { label: "Capacity", href: "/capacity", icon: Sliders },
    { label: "Agreements", href: "/agreements", icon: FileText },
    { label: "Invoices", href: "/invoices", icon: CreditCard },
    { label: "Directory", href: "/businesses", icon: Search },
    { label: "Analytics", href: "/analytics", icon: BarChart3 },
  ];

  if (user?.role === "ADMIN") {
    navLinks.push({ label: "Admin Console", href: "/admin", icon: ShieldAlert });
  }

  return (
    <header className="sticky top-0 z-50 bg-slate-900 border-b border-slate-800 text-white shadow-md">
      {/* Demo Persona Switcher Banner */}
      <div className="bg-gradient-to-r from-teal-900 via-slate-800 to-slate-900 text-xs px-4 py-1.5 flex flex-wrap items-center justify-between border-b border-teal-800/40">
        <div className="flex items-center gap-2">
          <span className="bg-teal-500/20 text-teal-300 font-semibold px-2 py-0.5 rounded border border-teal-500/30">
            DEMO MODE
          </span>
          <span className="hidden sm:inline text-slate-300">
            Active Persona: <strong className="text-white">{user?.business?.name || user?.name || "Guest"}</strong> (
            {user?.role || "Not logged in"})
          </span>
        </div>

        <div className="flex items-center gap-1.5 text-xs">
          <span className="text-slate-400 hidden md:inline">Quick Persona Switch:</span>
          <button
            onClick={() => switchDemoUser("OWNER")}
            className="px-2 py-0.5 rounded bg-slate-800 hover:bg-teal-600 transition text-slate-200 hover:text-white border border-slate-700"
            title="Apex Precision - Lead Manufacturer / Order Owner"
          >
            Apex (Owner)
          </button>
          <button
            onClick={() => switchDemoUser("PARTNER_B")}
            className="px-2 py-0.5 rounded bg-slate-800 hover:bg-teal-600 transition text-slate-200 hover:text-white border border-slate-700"
            title="Bharat ForgeWorks - 2,500 units partner"
          >
            Bharat Forge (Partner)
          </button>
          <button
            onClick={() => switchDemoUser("PARTNER_C")}
            className="px-2 py-0.5 rounded bg-slate-800 hover:bg-teal-600 transition text-slate-200 hover:text-white border border-slate-700"
            title="Crestline Dynamics - 1,500 units partner"
          >
            Crestline (Partner)
          </button>
          <button
            onClick={() => switchDemoUser("ADMIN")}
            className="px-2 py-0.5 rounded bg-amber-950/70 hover:bg-amber-700 transition text-amber-200 hover:text-white border border-amber-800"
            title="Platform Regulatory Administrator"
          >
            Admin
          </button>
        </div>
      </div>

      {/* Main Navbar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo & Tagline */}
          <div className="flex items-center gap-3">
            <a href="/" className="flex items-center gap-2 group">
              <div className="w-10 h-10 rounded-lg bg-teal-600 flex items-center justify-center text-white shadow-lg group-hover:bg-teal-500 transition">
                <Factory className="w-6 h-6" />
              </div>
              <div>
                <span className="text-xl font-bold tracking-tight text-white flex items-center gap-1">
                  Co<span className="text-teal-400">Mitra</span>
                </span>
                <span className="block text-[10px] text-slate-400 uppercase tracking-widest font-medium">
                  Smart Collaborative Manufacturing
                </span>
              </div>
            </a>
          </div>

          {/* Desktop Navigation Links */}
          {user && (
            <nav className="hidden lg:flex items-center gap-1">
              {navLinks.map((item) => {
                const Icon = item.icon;
                const isActive = pathname === item.href || pathname.startsWith(`${item.href}/`);
                return (
                  <a
                    key={item.href}
                    href={item.href}
                    className={`flex items-center gap-1.5 px-3 py-2 rounded-md text-xs font-medium transition ${
                      isActive
                        ? "bg-teal-500/10 text-teal-400 border border-teal-500/30"
                        : "text-slate-300 hover:bg-slate-800 hover:text-white"
                    }`}
                  >
                    <Icon className="w-4 h-4" />
                    {item.label}
                  </a>
                );
              })}
            </nav>
          )}

          {/* Right Action Icons */}
          <div className="flex items-center gap-3">
            {user ? (
              <>
                {/* Notification Bell */}
                <a
                  href="/notifications"
                  className="relative p-2 rounded-lg text-slate-300 hover:text-white hover:bg-slate-800 transition"
                  title="Notifications"
                >
                  <Bell className="w-5 h-5" />
                  {unreadCount > 0 && (
                    <span className="absolute top-1 right-1 flex h-4 w-4 items-center justify-center rounded-full bg-red-500 text-[9px] font-bold text-white ring-2 ring-slate-900">
                      {unreadCount}
                    </span>
                  )}
                </a>

                {/* Profile Pill */}
                <a
                  href="/profile"
                  className="hidden sm:flex items-center gap-2 px-3 py-1.5 rounded-lg bg-slate-800/80 hover:bg-slate-800 border border-slate-700 text-xs text-slate-200"
                >
                  <div className="w-6 h-6 rounded-full bg-teal-600 flex items-center justify-center text-white font-bold text-xs">
                    {user.name.charAt(0)}
                  </div>
                  <div className="text-left">
                    <p className="font-medium text-white truncate max-w-[120px]">{user.name}</p>
                    <p className="text-[10px] text-teal-400">{user.role}</p>
                  </div>
                </a>

                {/* Logout Button */}
                <button
                  onClick={logout}
                  className="p-2 rounded-lg text-slate-400 hover:text-red-400 hover:bg-slate-800 transition"
                  title="Sign Out"
                >
                  <LogOut className="w-5 h-5" />
                </button>
              </>
            ) : (
              <div className="flex items-center gap-2">
                <a
                  href="/login"
                  className="px-4 py-2 text-sm font-medium text-slate-300 hover:text-white hover:bg-slate-800 rounded-lg transition"
                >
                  Sign In
                </a>
                <a
                  href="/register"
                  className="px-4 py-2 text-sm font-medium bg-teal-600 hover:bg-teal-500 text-white rounded-lg transition shadow"
                >
                  Register Business
                </a>
              </div>
            )}

            {/* Mobile menu trigger */}
            {user && (
              <button
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                className="lg:hidden p-2 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800"
              >
                {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && user && (
        <div className="lg:hidden bg-slate-950 border-b border-slate-800 px-4 pt-2 pb-4 space-y-1">
          {navLinks.map((item) => {
            const Icon = item.icon;
            const isActive = pathname === item.href;
            return (
              <a
                key={item.href}
                href={item.href}
                onClick={() => setMobileMenuOpen(false)}
                className={`flex items-center gap-2 px-3 py-2 rounded-md text-sm font-medium ${
                  isActive ? "bg-teal-600 text-white" : "text-slate-300 hover:bg-slate-800"
                }`}
              >
                <Icon className="w-4 h-4" />
                {item.label}
              </a>
            );
          })}
        </div>
      )}
    </header>
  );
}
