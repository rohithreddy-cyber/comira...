import { PrismaClient } from "@prisma/client";
import bcrypt from "bcryptjs";

const prisma = new PrismaClient();

async function main() {
  console.log("🌱 Starting CoMitra demo database seed...");

  // Clean existing demo data (safe idempotent reset)
  await prisma.auditEvent.deleteMany();
  await prisma.notification.deleteMany();
  await prisma.rating.deleteMany();
  await prisma.paymentRecord.deleteMany();
  await prisma.invoice.deleteMany();
  await prisma.agreementRevision.deleteMany();
  await prisma.agreement.deleteMany();
  await prisma.productionUpdate.deleteMany();
  await prisma.productionMilestone.deleteMany();
  await prisma.workAllocation.deleteMany();
  await prisma.collaborationRequest.deleteMany();
  await prisma.partnerRecommendation.deleteMany();
  await prisma.order.deleteMany();
  await prisma.productionResource.deleteMany();
  await prisma.businessCapability.deleteMany();
  await prisma.businessVerification.deleteMany();
  await prisma.user.deleteMany();
  await prisma.business.deleteMany();

  const standardPasswordHash = await bcrypt.hash("Password123!", 10);
  const adminPasswordHash = await bcrypt.hash("AdminSecret123!", 10);

  // 1. Company A: Apex Precision Engineering (Order Owner / Lead Manufacturer)
  const businessA = await prisma.business.create({
    data: {
      name: "Apex Precision Engineering Pvt Ltd",
      registrationNumber: "U29253MH2014PTC254890",
      description: "Premier tier-1 precision automotive and aerospace component manufacturer with 5-axis CNC machining.",
      category: "CNC Machining & Metal Fabrication",
      location: "Pune, Maharashtra",
      address: "Plot 42, Bhosari MIDC Industrial Zone, Pune 411026",
      phone: "+91 20 2712 4401",
      email: "contact@apexprecision.demo",
      website: "https://apexprecision.demo",
      totalCapacity: 8000,
      committedCapacity: 6000, // producing 6,000 units of the main order
      availableCapacity: 2000,
      capacityUnit: "components/month",
      verificationStatus: "VERIFIED",
      trustScore: 94.5,
      capabilities: {
        create: [
          {
            capabilityName: "CNC Machining",
            description: "High-precision 5-axis CNC milling and automated lathe turning",
            maxPrecision: "±0.005 mm",
            certifications: "ISO 9001:2015, IATF 16949",
            unitPriceEstimate: 450,
            leadTimeDays: 14,
          },
          {
            capabilityName: "Precision Turning",
            description: "Swiss lathe turning for cylindrical components",
            maxPrecision: "±0.002 mm",
            certifications: "ISO 9001:2015",
            unitPriceEstimate: 380,
            leadTimeDays: 10,
          },
          {
            capabilityName: "Metal Fabrication",
            description: "Laser cutting, sheet metal bending, and TIG/MIG welding",
            maxPrecision: "±0.05 mm",
            certifications: "ISO 3834",
            unitPriceEstimate: 320,
            leadTimeDays: 12,
          },
        ],
      },
      resources: {
        create: [
          { resourceName: "DMG MORI 5-Axis Mill", resourceType: "CNC Mill", quantity: 4, capacityPerHour: 15, operationalStatus: "OPERATIONAL" },
          { resourceName: "Mazak QTN High-Precision Lathe", resourceType: "CNC Lathe", quantity: 6, capacityPerHour: 22, operationalStatus: "OPERATIONAL" },
          { resourceName: "Zeiss CMM Inspection Unit", resourceType: "Quality CMM", quantity: 2, capacityPerHour: 40, operationalStatus: "OPERATIONAL" },
        ],
      },
      verifications: {
        create: {
          documentType: "GSTIN",
          documentNumber: "27AABCA1234F1Z8",
          status: "APPROVED",
          reviewerNotes: "Verified via MCA and GST portal.",
          reviewedAt: new Date("2026-01-15"),
        },
      },
    },
  });

  const userA = await prisma.user.create({
    data: {
      name: "Rohit Deshmukh",
      email: "owner@apex.com",
      passwordHash: standardPasswordHash,
      role: "OWNER",
      businessId: businessA.id,
    },
  });

  // 2. Company B: Bharat ForgeWorks & Components (Partner 1)
  const businessB = await prisma.business.create({
    data: {
      name: "Bharat ForgeWorks & Components",
      registrationNumber: "U28910GJ2016PTC091234",
      description: "Certified partner specialized in heavy forge, high tolerance milling, and mil-spec surface finishing.",
      category: "CNC Machining & Metal Fabrication",
      location: "Sanand, Gujarat",
      address: "Sanand GIDC Industrial Estate Phase II, Ahmedabad 382110",
      phone: "+91 79 4001 8890",
      email: "collab@bharatforgeworks.demo",
      website: "https://bharatforgeworks.demo",
      totalCapacity: 15000,
      committedCapacity: 2500, // allocated 2,500 units
      availableCapacity: 12500,
      capacityUnit: "components/month",
      verificationStatus: "VERIFIED",
      trustScore: 96.2,
      capabilities: {
        create: [
          {
            capabilityName: "CNC Machining",
            description: "Vertical machining centers with high throughput",
            maxPrecision: "±0.008 mm",
            certifications: "ISO 9001:2015, AS9100D",
            unitPriceEstimate: 420,
            leadTimeDays: 12,
          },
          {
            capabilityName: "Heat Treatment",
            description: "Vacuum carburizing and induction case hardening",
            maxPrecision: "58-62 HRC",
            certifications: "NADCAP",
            unitPriceEstimate: 95,
            leadTimeDays: 5,
          },
          {
            capabilityName: "Surface Finishing",
            description: "Hard anodizing, nickel plating, and passivation",
            maxPrecision: "Class 2 Type III",
            certifications: "RoHS Compliant",
            unitPriceEstimate: 60,
            leadTimeDays: 4,
          },
        ],
      },
      resources: {
        create: [
          { resourceName: "Haas VF-4SS VMC Machining Center", resourceType: "CNC Mill", quantity: 8, capacityPerHour: 20, operationalStatus: "OPERATIONAL" },
          { resourceName: "Ipsen Vacuum Furnaces", resourceType: "Heat Treatment", quantity: 2, capacityPerHour: 100, operationalStatus: "OPERATIONAL" },
        ],
      },
      verifications: {
        create: {
          documentType: "GSTIN",
          documentNumber: "24AABCB5678G2Z1",
          status: "APPROVED",
          reviewerNotes: "Approved - AS9100D Certificate verified.",
          reviewedAt: new Date("2026-02-10"),
        },
      },
    },
  });

  const userB = await prisma.user.create({
    data: {
      name: "Suresh Patel",
      email: "partner@bharatforge.com",
      passwordHash: standardPasswordHash,
      role: "PARTNER",
      businessId: businessB.id,
    },
  });

  // 3. Company C: Crestline Heavy Dynamics (Partner 2)
  const businessC = await prisma.business.create({
    data: {
      name: "Crestline Heavy Dynamics Ltd",
      registrationNumber: "U29100KA2018PLC078901",
      description: "Precision tooling, grinding, CNC milling, and high volume contract manufacturing.",
      category: "CNC Machining & Metal Fabrication",
      location: "Peenya, Bengaluru",
      address: "12/A 4th Phase, Peenya Industrial Area, Bengaluru 560058",
      phone: "+91 80 2839 7720",
      email: "contact@crestlinedynamics.demo",
      website: "https://crestlinedynamics.demo",
      totalCapacity: 12000,
      committedCapacity: 1500, // allocated 1,500 units
      availableCapacity: 10500,
      capacityUnit: "components/month",
      verificationStatus: "VERIFIED",
      trustScore: 91.8,
      capabilities: {
        create: [
          {
            capabilityName: "CNC Machining",
            description: "High-speed CNC milling and cylindrical grinding",
            maxPrecision: "±0.005 mm",
            certifications: "ISO 9001:2015",
            unitPriceEstimate: 440,
            leadTimeDays: 14,
          },
          {
            capabilityName: "Surface Grinding",
            description: "Sub-micron surface finishing and lapping",
            maxPrecision: "Ra 0.2 um",
            certifications: "ISO 9001:2015",
            unitPriceEstimate: 110,
            leadTimeDays: 6,
          },
        ],
      },
      resources: {
        create: [
          { resourceName: "Makino Slim3 VMC", resourceType: "CNC Mill", quantity: 5, capacityPerHour: 18, operationalStatus: "OPERATIONAL" },
          { resourceName: "Studer Cylindrical Grinder", resourceType: "Grinder", quantity: 3, capacityPerHour: 12, operationalStatus: "OPERATIONAL" },
        ],
      },
      verifications: {
        create: {
          documentType: "GSTIN",
          documentNumber: "29AABCC9012H3Z4",
          status: "APPROVED",
          reviewerNotes: "Verified via MCA active directory.",
          reviewedAt: new Date("2026-03-01"),
        },
      },
    },
  });

  const userC = await prisma.user.create({
    data: {
      name: "Ananya Rao",
      email: "partner@crestline.com",
      passwordHash: standardPasswordHash,
      role: "PARTNER",
      businessId: businessC.id,
    },
  });

  // 4. Company D: Delta MicroTech Labs (Candidate with distinct focus / partial match)
  const businessD = await prisma.business.create({
    data: {
      name: "Delta MicroTech Labs",
      registrationNumber: "U33110TN2020PTC112233",
      description: "Industrial 3D additive manufacturing, rapid prototyping, and precision micro-molding.",
      category: "Additive Manufacturing & Plastics",
      location: "Ambattur, Chennai",
      address: "Plot 88 Industrial Estate, Ambattur, Chennai 600058",
      phone: "+91 44 2625 3344",
      email: "info@deltamicrotech.demo",
      website: "https://deltamicrotech.demo",
      totalCapacity: 3000,
      committedCapacity: 500,
      availableCapacity: 2500,
      capacityUnit: "parts/month",
      verificationStatus: "VERIFIED",
      trustScore: 88.0,
      capabilities: {
        create: [
          {
            capabilityName: "Additive Manufacturing",
            description: "Direct Metal Laser Sintering (DMLS) titanium & aluminum 3D printing",
            maxPrecision: "±0.02 mm",
            certifications: "ISO 13485 Medical",
            unitPriceEstimate: 1200,
            leadTimeDays: 7,
          },
          {
            capabilityName: "Rapid Prototyping",
            description: "SLA / SLS polymer prototyping and low volume bridge tooling",
            maxPrecision: "±0.05 mm",
            unitPriceEstimate: 600,
            leadTimeDays: 3,
          },
        ],
      },
      resources: {
        create: [
          { resourceName: "EOS M290 Metal 3D Printer", resourceType: "DMLS Printer", quantity: 2, capacityPerHour: 4, operationalStatus: "OPERATIONAL" },
        ],
      },
      verifications: {
        create: {
          documentType: "GSTIN",
          documentNumber: "33AABCD3344J1Z9",
          status: "APPROVED",
          reviewerNotes: "Verified MSME Udyam registration.",
          reviewedAt: new Date("2026-03-20"),
        },
      },
    },
  });

  const userD = await prisma.user.create({
    data: {
      name: "Karthik Subramanian",
      email: "partner@deltamicro.com",
      passwordHash: standardPasswordHash,
      role: "PARTNER",
      businessId: businessD.id,
    },
  });

  // 5. Platform Administrator
  const adminBusiness = await prisma.business.create({
    data: {
      name: "CoMitra National Regulatory & Quality Directorate",
      registrationNumber: "GOV-IN-COMITRA-001",
      description: "Centralized oversight, business verification, and dispute resolution body for CoMitra industrial clusters.",
      category: "Industrial Administration",
      location: "New Delhi, Delhi",
      address: "Udyog Bhawan, Rafi Marg, New Delhi 110011",
      phone: "+91 11 2306 1234",
      email: "admin@comitra.gov.in",
      website: "https://comitra.gov.in",
      totalCapacity: 0,
      committedCapacity: 0,
      availableCapacity: 0,
      capacityUnit: "audits/month",
      verificationStatus: "VERIFIED",
      trustScore: 100.0,
    },
  });

  const adminUser = await prisma.user.create({
    data: {
      name: "Dr. Vikram Sethi (Chief Auditor)",
      email: "admin@comitra.gov.in",
      passwordHash: adminPasswordHash,
      role: "ADMIN",
      businessId: adminBusiness.id,
    },
  });

  // 6. Bulk Order: 10,000 units of Aerospace Hydraulic Actuator Housings
  // Owner (Apex) has capacity for 6,000; Needs 4,000 collaborated
  const targetDeadline = new Date(Date.now() + 45 * 24 * 60 * 60 * 1000); // 45 days from now
  const order1 = await prisma.order.create({
    data: {
      orderNumber: "ORD-2026-10088",
      title: "10,000 Units: Aircraft High-Pressure Hydraulic Actuator Housings",
      description:
        "Fictional Demonstration Order: Major aerospace client placed an urgent requirement for 10,000 precision CNC machined actuator housings (Alloy 7075-T6). Apex can produce 6,000 units in-house and collaborates with Bharat ForgeWorks (2,500 units) and Crestline Heavy Dynamics (1,500 units) to meet the strict delivery deadline.",
      category: "CNC Machining & Metal Fabrication",
      totalQuantity: 10000,
      quantityUnit: "units",
      targetUnitCost: 450,
      totalBudget: 4500000,
      deadline: targetDeadline,
      deliveryLocation: "HAL Aerospace Logistics Park, Bengaluru (Hub 4)",
      technicalSpecs: "Material: Aluminum 7075-T6; Tolerance: ±0.005mm; Surface Finish: Ra 0.4 um; Mil-A-8625 Hard Anodizing Type III Class 2; 100% CMM inspection certificate required.",
      qualityRequirements: "AS9100D or ISO 9001:2015 mandatory; Ultrasonic material defect testing; Hydrostatic pressure test at 3000 PSI.",
      requiredCapabilities: "CNC Machining, Heat Treatment, Surface Finishing",
      status: "IN_PRODUCTION",
      selfAllocatedQty: 6000,
      ownerBusinessId: businessA.id,
    },
  });

  // Partner Recommendations for Order 1
  await prisma.partnerRecommendation.createMany({
    data: [
      {
        orderId: order1.id,
        businessId: businessB.id,
        score: 96.5,
        capabilityScore: 98.0,
        capacityScore: 95.0,
        deadlineScore: 97.0,
        qualityScore: 98.0,
        trustScore: 96.2,
        matchCategory: "EXCELLENT",
        matchedCapabilities: "CNC Machining, Heat Treatment, Surface Finishing",
        reasonsJson: JSON.stringify([
          "Exact match on CNC Machining, Heat Treatment, and Hard Anodizing capabilities",
          "Excess available capacity of 12,500 units/mo comfortably handles 2,500 unit allocation",
          "AS9100D aerospace certification directly matches quality requirements",
          "Proven 96.2% on-time delivery track record",
        ]),
        limitationsJson: JSON.stringify([
          "Transit distance from Sanand (Gujarat) to Bengaluru hub requires 2 days logistics planning",
        ]),
      },
      {
        orderId: order1.id,
        businessId: businessC.id,
        score: 91.0,
        capabilityScore: 92.0,
        capacityScore: 90.0,
        deadlineScore: 93.0,
        qualityScore: 92.0,
        trustScore: 91.8,
        matchCategory: "HIGH",
        matchedCapabilities: "CNC Machining, Surface Grinding",
        reasonsJson: JSON.stringify([
          "High precision 5-axis CNC machining meets ±0.005mm tolerance",
          "Located in Peenya Bengaluru, adjacent to delivery destination (zero inter-state freight delay)",
          "10,500 units/mo capacity available to support 1,500 units",
        ]),
        limitationsJson: JSON.stringify([
          "Anodizing must be sub-contracted or coordinated via Bharat ForgeWorks partner facility",
        ]),
      },
      {
        orderId: order1.id,
        businessId: businessD.id,
        score: 48.0,
        capabilityScore: 35.0,
        capacityScore: 50.0,
        deadlineScore: 60.0,
        qualityScore: 70.0,
        trustScore: 88.0,
        matchCategory: "LOW",
        matchedCapabilities: "Additive Manufacturing (Partial)",
        reasonsJson: JSON.stringify([
          "High ISO quality ratings and certified precision laboratory",
        ]),
        limitationsJson: JSON.stringify([
          "Specializes in additive 3D metal sintering rather than high-speed CNC milling",
          "Estimated unit cost (₹1,200) exceeds order target unit budget (₹450)",
          "Insufficient capacity for bulk volume component production",
        ]),
      },
    ],
  });

  // Collaboration Requests
  await prisma.collaborationRequest.create({
    data: {
      orderId: order1.id,
      senderBusinessId: businessA.id,
      receiverBusinessId: businessB.id,
      proposedQuantity: 2500,
      unitPrice: 450,
      proposedDeadline: new Date(Date.now() + 40 * 24 * 60 * 60 * 1000),
      requirements: "CNC Machining + Hard Anodizing Type III Class 2. Supply full CMM dimensional report.",
      message: "Hi Suresh, we have an urgent aerospace actuator order of 10,000 units. We'd like Bharat ForgeWorks to partner with us for 2,500 units.",
      status: "ACCEPTED",
      responseNote: "Accepted. We have reserved Haas VMC line 3 and vacuum hardening capacity for this allocation.",
    },
  });

  await prisma.collaborationRequest.create({
    data: {
      orderId: order1.id,
      senderBusinessId: businessA.id,
      receiverBusinessId: businessC.id,
      proposedQuantity: 1500,
      unitPrice: 440,
      proposedDeadline: new Date(Date.now() + 38 * 24 * 60 * 60 * 1000),
      requirements: "Precision CNC Milling and sub-micron Ra 0.4 um finishing.",
      message: "Hi Ananya, requesting Crestline to partner on 1,500 units for the aerospace actuator housing.",
      status: "ACCEPTED",
      responseNote: "Confirmed. Peenya tooling fixtures scheduled for immediate production start.",
    },
  });

  // Work Allocations
  // 1. Apex In-house Allocation (6,000 units)
  const allocA = await prisma.workAllocation.create({
    data: {
      orderId: order1.id,
      businessId: businessA.id,
      allocatedQuantity: 6000,
      completedQuantity: 4200, // 70% completed
      agreedUnitPrice: 450,
      totalAmount: 2700000,
      agreedDeadline: targetDeadline,
      status: "IN_PROGRESS",
      notes: "Lead manufacturer in-house production: 6,000 units scheduled across Mazak and DMG MORI lines.",
    },
  });

  // 2. Bharat ForgeWorks Allocation (2,500 units)
  const allocB = await prisma.workAllocation.create({
    data: {
      orderId: order1.id,
      businessId: businessB.id,
      allocatedQuantity: 2500,
      completedQuantity: 1800, // 72% completed
      agreedUnitPrice: 450,
      totalAmount: 1125000,
      agreedDeadline: new Date(Date.now() + 40 * 24 * 60 * 60 * 1000),
      status: "IN_PROGRESS",
      notes: "Partner allocation: 2,500 units including Mil-A-8625 Type III hard anodizing.",
    },
  });

  // 3. Crestline Allocation (1,500 units)
  const allocC = await prisma.workAllocation.create({
    data: {
      orderId: order1.id,
      businessId: businessC.id,
      allocatedQuantity: 1500,
      completedQuantity: 950, // 63.3% completed
      agreedUnitPrice: 440,
      totalAmount: 660000,
      agreedDeadline: new Date(Date.now() + 38 * 24 * 60 * 60 * 1000),
      status: "IN_PROGRESS",
      notes: "Partner allocation: 1,500 units CNC milling and precision surface grinding.",
    },
  });

  // Production Milestones
  await prisma.productionMilestone.createMany({
    data: [
      {
        orderId: order1.id,
        workAllocationId: allocA.id,
        title: "Apex Phase 1: Tooling & Rough Machining (3,000 units)",
        targetQuantity: 3000,
        targetDate: new Date(Date.now() - 10 * 24 * 60 * 60 * 1000),
        actualDate: new Date(Date.now() - 11 * 24 * 60 * 60 * 1000),
        status: "COMPLETED",
      },
      {
        orderId: order1.id,
        workAllocationId: allocA.id,
        title: "Apex Phase 2: 5-Axis Finish Machining & CMM (3,000 units)",
        targetQuantity: 3000,
        targetDate: new Date(Date.now() + 15 * 24 * 60 * 60 * 1000),
        status: "IN_PROGRESS",
      },
      {
        orderId: order1.id,
        workAllocationId: allocB.id,
        title: "Bharat Forge Phase 1: CNC Milling (1,500 units)",
        targetQuantity: 1500,
        targetDate: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000),
        actualDate: new Date(Date.now() - 6 * 24 * 60 * 60 * 1000),
        status: "COMPLETED",
      },
      {
        orderId: order1.id,
        workAllocationId: allocB.id,
        title: "Bharat Forge Phase 2: Anodizing & Hydro Testing (1,000 units)",
        targetQuantity: 1000,
        targetDate: new Date(Date.now() + 20 * 24 * 60 * 60 * 1000),
        status: "IN_PROGRESS",
      },
      {
        orderId: order1.id,
        workAllocationId: allocC.id,
        title: "Crestline Batch 1: Machining & Grinding (1,000 units)",
        targetQuantity: 1000,
        targetDate: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000),
        actualDate: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000),
        status: "COMPLETED",
      },
      {
        orderId: order1.id,
        workAllocationId: allocC.id,
        title: "Crestline Batch 2: Final Tolerance Inspection (500 units)",
        targetQuantity: 500,
        targetDate: new Date(Date.now() + 12 * 24 * 60 * 60 * 1000),
        status: "IN_PROGRESS",
      },
    ],
  });

  // Production Updates (Live progress feed)
  await prisma.productionUpdate.createMany({
    data: [
      {
        orderId: order1.id,
        workAllocationId: allocA.id,
        businessId: businessA.id,
        completedQuantity: 4200,
        statusNote: "Batch 1 and 2 CNC milling completed with 0.003mm variance. Ultrasonic scan passed.",
        qualityPassed: true,
        qualityNotes: "Zero defect on 100 sample lot. Passed CMM inspection.",
      },
      {
        orderId: order1.id,
        workAllocationId: allocB.id,
        businessId: businessB.id,
        completedQuantity: 1800,
        statusNote: "1,800 units processed through Haas VMC lines. 1,000 units passed Mil-spec anodizing tank 2.",
        qualityPassed: true,
        qualityNotes: "Mil-A-8625 salt spray test 336 hours cleared.",
      },
      {
        orderId: order1.id,
        workAllocationId: allocC.id,
        businessId: businessC.id,
        completedQuantity: 950,
        statusNote: "Batch of 950 housings ground to Ra 0.38 um. Slight 1-day tooling adjustment resolved.",
        delayReason: "Tool replacement on spindle 2",
        delayDays: 1,
        qualityPassed: true,
        qualityNotes: "Surface roughness verified with contact profilometer.",
      },
    ],
  });

  // Agreements
  const agreementB = await prisma.agreement.create({
    data: {
      agreementNumber: "AGR-2026-APEX-BF-001",
      orderId: order1.id,
      ownerBusinessId: businessA.id,
      partnerBusinessId: businessB.id,
      title: "Manufacturing Sub-Contract Agreement — 2,500 Units Actuator Housings",
      termsText: `CO-MANUFACTURING AND SUBCONTRACT COLLABORATION AGREEMENT
Order Reference: ORD-2026-10088
Primary Contractor: Apex Precision Engineering Pvt Ltd
Collaborating Partner: Bharat ForgeWorks & Components

1. SCOPE OF COLLABORATION
The Partner agrees to manufacture, surface finish, and inspect 2,500 units of Aircraft High-Pressure Hydraulic Actuator Housings conforming strictly to aerospace drawings #ACT-7075-REV-E.

2. COMMERCIAL TERMS
- Quantity: 2,500 units
- Agreed Unit Price: ₹450.00 / unit
- Total Consideration: ₹11,25,000.00 (Excluding GST)
- Payment Terms: 30% advance on material readiness, 70% upon successful delivery and quality acceptance.

3. QUALITY & COMPLIANCE
Partner guarantees adherence to AS9100D manufacturing controls, material test certificates (MTC 3.1), and 100% CMM dimensional data records.

4. DELAY & LIQUIDATED DAMAGES
Any unexcused delay beyond the agreed milestone of 40 days shall incur 0.5% per week up to a maximum of 5% of order value.

Status: Digitally accepted and recorded on CoMitra Platform.`,
      allocatedQuantity: 2500,
      agreedUnitPrice: 450,
      totalValue: 1125000,
      status: "ACCEPTED",
      ownerSignedAt: new Date(Date.now() - 14 * 24 * 60 * 60 * 1000),
      partnerSignedAt: new Date(Date.now() - 13 * 24 * 60 * 60 * 1000),
      revisions: {
        create: {
          revisionNumber: 1,
          changeSummary: "Initial agreement execution on collaboration acceptance",
          termsText: "Initial finalized contract draft.",
          createdById: userA.id,
        },
      },
    },
  });

  const agreementC = await prisma.agreement.create({
    data: {
      agreementNumber: "AGR-2026-APEX-CL-002",
      orderId: order1.id,
      ownerBusinessId: businessA.id,
      partnerBusinessId: businessC.id,
      title: "Manufacturing Sub-Contract Agreement — 1,500 Units Actuator Housings",
      termsText: `CO-MANUFACTURING AND SUBCONTRACT COLLABORATION AGREEMENT
Order Reference: ORD-2026-10088
Primary Contractor: Apex Precision Engineering Pvt Ltd
Collaborating Partner: Crestline Heavy Dynamics Ltd

1. SCOPE OF PRODUCTION
Manufacture and sub-micron grinding of 1,500 units of Hydraulic Actuator Housings.

2. COMMERCIAL TERMS
- Quantity: 1,500 units
- Agreed Unit Price: ₹440.00 / unit
- Total Consideration: ₹6,60,000.00 (Excluding GST)

3. DELIVERY LOCATION
Direct dispatch to HAL Aerospace Logistics Park Hub 4 Bengaluru with CoMitra co-batch clearance certificate.`,
      allocatedQuantity: 1500,
      agreedUnitPrice: 440,
      totalValue: 660000,
      status: "ACCEPTED",
      ownerSignedAt: new Date(Date.now() - 12 * 24 * 60 * 60 * 1000),
      partnerSignedAt: new Date(Date.now() - 11 * 24 * 60 * 60 * 1000),
      revisions: {
        create: {
          revisionNumber: 1,
          changeSummary: "Mutual agreement signed by Rohit Deshmukh and Ananya Rao",
          termsText: "Initial contract version.",
          createdById: userA.id,
        },
      },
    },
  });

  // Invoices & Payments (Demonstration simulated invoices)
  const invoiceB = await prisma.invoice.create({
    data: {
      invoiceNumber: "INV-2026-BF-00108",
      orderId: order1.id,
      issuerBusinessId: businessB.id,
      recipientBusinessId: businessA.id,
      itemDescription: "Milestone Billing (Batch 1: 1,800 units Aircraft Actuator Housings completed & anodized)",
      quantity: 1800,
      unitPrice: 450,
      amountSubtotal: 810000,
      taxRate: 18.0,
      taxAmount: 145800,
      amountTotal: 955800,
      currency: "INR",
      status: "PAID",
      dueDate: new Date(Date.now() + 10 * 24 * 60 * 60 * 1000),
      issuedDate: new Date(Date.now() - 4 * 24 * 60 * 60 * 1000),
      paidDate: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000),
      paymentMethod: "NEFT Bank Transfer (Simulated)",
      isSimulated: true,
      notes: "Demonstration simulated invoice payment cleared via simulated CoMitra escrow workflow.",
      payments: {
        create: {
          amount: 955800,
          referenceNumber: "SIM-NEFT-2026-992144",
          status: "COMPLETED",
          isSimulated: true,
          notes: "Simulated demonstration payment cleared successfully.",
        },
      },
    },
  });

  const invoiceC = await prisma.invoice.create({
    data: {
      invoiceNumber: "INV-2026-CL-00421",
      orderId: order1.id,
      issuerBusinessId: businessC.id,
      recipientBusinessId: businessA.id,
      itemDescription: "Interim Progress Billing (Batch 1: 950 units ground and inspected)",
      quantity: 950,
      unitPrice: 440,
      amountSubtotal: 418000,
      taxRate: 18.0,
      taxAmount: 75240,
      amountTotal: 493240,
      currency: "INR",
      status: "ISSUED",
      dueDate: new Date(Date.now() + 14 * 24 * 60 * 60 * 1000),
      issuedDate: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000),
      isSimulated: true,
      notes: "Interim invoice pending Apex finance approval and simulated milestone release.",
    },
  });

  // Historical completed order for trust ratings demo
  const completedOrder = await prisma.order.create({
    data: {
      orderNumber: "ORD-2025-08912",
      title: "5,000 Units: Heavy Turbine Flange Rings",
      description: "Previous collaborative order successfully fulfilled across Apex Precision and Bharat ForgeWorks.",
      category: "CNC Machining & Metal Fabrication",
      totalQuantity: 5000,
      quantityUnit: "units",
      targetUnitCost: 650,
      totalBudget: 3250000,
      deadline: new Date(Date.now() - 60 * 24 * 60 * 60 * 1000),
      deliveryLocation: "L&T Heavy Engineering, Hazira",
      technicalSpecs: "Alloy Steel Grade 4140, Normalized & Tempered.",
      qualityRequirements: "Zero micro-crack ultrasonic acceptance.",
      requiredCapabilities: "CNC Machining, Heat Treatment",
      status: "COMPLETED",
      selfAllocatedQty: 3000,
      ownerBusinessId: businessA.id,
    },
  });

  // Ratings between businesses
  await prisma.rating.create({
    data: {
      orderId: completedOrder.id,
      reviewerBusinessId: businessA.id,
      revieweeBusinessId: businessB.id,
      score: 5.0,
      communicationRating: 4.9,
      qualityRating: 5.0,
      timelinessRating: 4.8,
      feedback: "Exceptional machining tolerance and rapid delivery on the turbine flange project. Highly recommended manufacturing partner.",
      isVerifiedCollaboration: true,
    },
  });

  await prisma.rating.create({
    data: {
      orderId: completedOrder.id,
      reviewerBusinessId: businessB.id,
      revieweeBusinessId: businessA.id,
      score: 4.9,
      communicationRating: 5.0,
      qualityRating: 4.9,
      timelinessRating: 4.9,
      feedback: "Clear drawings, prompt milestone payments, and excellent collaborative coordination throughout the project lifecycle.",
      isVerifiedCollaboration: true,
    },
  });

  // Notifications
  await prisma.notification.createMany({
    data: [
      {
        userId: userA.id,
        businessId: businessA.id,
        title: "Collaboration Accepted by Bharat ForgeWorks",
        message: "Bharat ForgeWorks accepted allocation of 2,500 units for Order #ORD-2026-10088.",
        type: "COLLABORATION_ACCEPTED",
        link: `/orders/${order1.id}`,
        isRead: false,
      },
      {
        userId: userA.id,
        businessId: businessA.id,
        title: "Production Milestone Reached: Crestline Dynamics",
        message: "Crestline reported 950 units completed for Batch 1.",
        type: "PRODUCTION_UPDATE",
        link: `/production`,
        isRead: false,
      },
      {
        userId: userB.id,
        businessId: businessB.id,
        title: "Simulated Payment Cleared",
        message: "Apex Precision settled Invoice #INV-2026-BF-00108 for ₹9,55,800.",
        type: "INVOICE_STATUS",
        link: `/invoices`,
        isRead: false,
      },
      {
        userId: userC.id,
        businessId: businessC.id,
        title: "Collaboration Allocation Active",
        message: "1,500 units allocated for Aircraft Actuator Housings.",
        type: "ALLOCATION_UPDATED",
        link: `/production`,
        isRead: true,
      },
    ],
  });

  // Audit Events
  await prisma.auditEvent.createMany({
    data: [
      {
        eventType: "ORDER",
        action: "CREATE",
        actorId: userA.id,
        actorName: "Rohit Deshmukh",
        businessId: businessA.id,
        targetType: "Order",
        targetId: order1.id,
        metadataJson: JSON.stringify({ orderNumber: order1.orderNumber, totalQuantity: 10000 }),
      },
      {
        eventType: "ALLOCATION",
        action: "ACCEPT",
        actorId: userB.id,
        actorName: "Suresh Patel",
        businessId: businessB.id,
        targetType: "WorkAllocation",
        targetId: allocB.id,
        metadataJson: JSON.stringify({ allocatedQuantity: 2500, unitPrice: 450 }),
      },
      {
        eventType: "ALLOCATION",
        action: "ACCEPT",
        actorId: userC.id,
        actorName: "Ananya Rao",
        businessId: businessC.id,
        targetType: "WorkAllocation",
        targetId: allocC.id,
        metadataJson: JSON.stringify({ allocatedQuantity: 1500, unitPrice: 440 }),
      },
      {
        eventType: "INVOICE",
        action: "PAID",
        actorId: userA.id,
        actorName: "Rohit Deshmukh",
        businessId: businessA.id,
        targetType: "Invoice",
        targetId: invoiceB.id,
        metadataJson: JSON.stringify({ amountTotal: 955800, simulated: true }),
      },
    ],
  });

  console.log("✅ CoMitra demo database successfully seeded!");
  console.log("Demonstration Credentials:");
  console.log("  Owner:   owner@apex.com / Password123!         (Apex Precision Engineering)");
  console.log("  Partner: partner@bharatforge.com / Password123! (Bharat ForgeWorks)");
  console.log("  Partner: partner@crestline.com / Password123!   (Crestline Heavy Dynamics)");
  console.log("  Partner: partner@deltamicro.com / Password123!  (Delta MicroTech Labs)");
  console.log("  Admin:   admin@comitra.gov.in / AdminSecret123! (Regulatory Directorate)");
}

main()
  .catch((e) => {
    console.error("❌ Seed failed:", e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
