import { describe, it, expect } from "vitest";
import { hashPassword, verifyPassword, signToken, verifySessionToken } from "@/lib/auth";
import { SessionUser } from "@/types";

describe("Authentication & Authorization", () => {
  it("hashes and verifies passwords securely", async () => {
    const raw = "SuperSecurePassword123!";
    const hash = await hashPassword(raw);

    expect(hash).not.toBe(raw);
    const valid = await verifyPassword(raw, hash);
    expect(valid).toBe(true);

    const invalid = await verifyPassword("WrongPassword", hash);
    expect(invalid).toBe(false);
  });

  it("signs and decodes valid JWT session token", () => {
    const user: SessionUser = {
      id: "user_test_123",
      name: "Rohit Deshmukh",
      email: "owner@apex.com",
      role: "OWNER",
      businessId: "biz_test_456",
      businessName: "Apex Precision Engineering",
    };

    const token = signToken(user);
    expect(typeof token).toBe("string");

    const decoded = verifySessionToken(token);
    expect(decoded).not.toBeNull();
    expect(decoded?.email).toBe("owner@apex.com");
    expect(decoded?.role).toBe("OWNER");
    expect(decoded?.businessId).toBe("biz_test_456");
  });

  it("returns null for malformed or tampered token", () => {
    const tampered = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.tampered.signature";
    const result = verifySessionToken(tampered);
    expect(result).toBeNull();
  });
});
