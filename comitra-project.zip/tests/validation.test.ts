import { describe, it, expect } from "vitest";
import {
  orderSchema,
  collaborationRequestSchema,
  productionUpdateSchema,
  invoiceSchema,
  registerSchema,
  capacityUpdateSchema,
} from "@/lib/validation";

describe("Validation Schemas", () => {
  it("validates valid order payload", () => {
    const validOrder = {
      title: "5,000 Units: High Precision CNC Flanges",
      description: "Automotive engine high tolerance components",
      category: "CNC Machining & Metal Fabrication",
      totalQuantity: 5000,
      quantityUnit: "units",
      targetUnitCost: 350,
      deadline: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(),
      deliveryLocation: "Pune, Maharashtra",
      technicalSpecs: "Material 4140 Steel; Tolerance ±0.005mm",
      qualityRequirements: "ISO 9001:2015 certified",
      requiredCapabilities: "CNC Machining, Turning",
      selfAllocatedQty: 2000,
    };

    const result = orderSchema.safeParse(validOrder);
    expect(result.success).toBe(true);
  });

  it("rejects order with negative or zero quantity", () => {
    const invalidOrder = {
      title: "Invalid Order",
      description: "Test description",
      category: "CNC Machining",
      totalQuantity: -50,
      targetUnitCost: 100,
      deadline: new Date().toISOString(),
      deliveryLocation: "Mumbai",
      technicalSpecs: "Specs",
      qualityRequirements: "ISO",
      requiredCapabilities: "Machining",
      selfAllocatedQty: 0,
    };

    const result = orderSchema.safeParse(invalidOrder);
    expect(result.success).toBe(false);
  });

  it("validates collaboration request schema", () => {
    const validRequest = {
      orderId: "order_123",
      receiverBusinessId: "biz_456",
      proposedQuantity: 1500,
      unitPrice: 400,
      proposedDeadline: new Date(Date.now() + 20 * 24 * 60 * 60 * 1000).toISOString(),
      requirements: "CNC milling only",
      message: "Please review",
    };

    const result = collaborationRequestSchema.safeParse(validRequest);
    expect(result.success).toBe(true);
  });

  it("rejects collaboration request with zero or negative price", () => {
    const invalidRequest = {
      orderId: "order_123",
      receiverBusinessId: "biz_456",
      proposedQuantity: 1500,
      unitPrice: 0,
      proposedDeadline: new Date().toISOString(),
    };

    const result = collaborationRequestSchema.safeParse(invalidRequest);
    expect(result.success).toBe(false);
  });

  it("validates capacity update boundaries", () => {
    const valid = {
      totalCapacity: 15000,
      availableCapacity: 8000,
      capacityUnit: "units/month",
    };
    expect(capacityUpdateSchema.safeParse(valid).success).toBe(true);

    const invalid = {
      totalCapacity: -500,
      availableCapacity: -100,
      capacityUnit: "",
    };
    expect(capacityUpdateSchema.safeParse(invalid).success).toBe(false);
  });
});
