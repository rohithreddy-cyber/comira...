import { describe, it, expect } from "vitest";

describe("Business Logic & Calculations", () => {
  it("calculates progress percentage accurately without double counting", () => {
    const totalQuantity = 10000;
    const allocations = [
      { id: "1", allocatedQuantity: 6000, completedQuantity: 4200, status: "IN_PROGRESS" },
      { id: "2", allocatedQuantity: 2500, completedQuantity: 1800, status: "IN_PROGRESS" },
      { id: "3", allocatedQuantity: 1500, completedQuantity: 950, status: "IN_PROGRESS" },
    ];

    const totalAllocated = allocations.reduce((sum, a) => sum + a.allocatedQuantity, 0);
    const totalProduced = allocations.reduce((sum, a) => sum + a.completedQuantity, 0);

    expect(totalAllocated).toBe(10000);
    expect(totalProduced).toBe(6950);

    const progressPercentage = Math.round((totalProduced / totalQuantity) * 100);
    expect(progressPercentage).toBe(70); // 69.5 rounded
  });

  it("handles cancelled allocations without counting towards active commitments", () => {
    const allocations = [
      { id: "1", allocatedQuantity: 6000, status: "IN_PROGRESS" },
      { id: "2", allocatedQuantity: 2500, status: "CANCELLED" },
      { id: "3", allocatedQuantity: 1500, status: "CONFIRMED" },
    ];

    const activeAllocated = allocations.reduce((sum, a) => {
      return a.status !== "CANCELLED" ? sum + a.allocatedQuantity : sum;
    }, 0);

    expect(activeAllocated).toBe(7500); // 2500 is ignored
  });

  it("calculates precise GST and grand total for invoices", () => {
    const quantity = 1800;
    const unitPrice = 450;
    const taxRate = 18.0;

    const amountSubtotal = Math.round(quantity * unitPrice * 100) / 100;
    const taxAmount = Math.round(amountSubtotal * (taxRate / 100) * 100) / 100;
    const amountTotal = Math.round((amountSubtotal + taxAmount) * 100) / 100;

    expect(amountSubtotal).toBe(810000);
    expect(taxAmount).toBe(145800);
    expect(amountTotal).toBe(955800);
  });
});
