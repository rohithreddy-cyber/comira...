import { describe, it, expect, beforeAll, afterAll } from "vitest";
import prisma from "@/lib/prisma";
import { computePartnerRecommendations, DEFAULT_WEIGHTS } from "@/lib/matchingEngine";

describe("CoMitra Partner Matching Engine", () => {
  let testOrderId: string;

  beforeAll(async () => {
    // Find seeded test order
    const order = await prisma.order.findFirst({
      where: { orderNumber: "ORD-2026-10088" },
    });
    if (order) {
      testOrderId = order.id;
    }
  });

  it("calculates recommendations and ranks candidates correctly", async () => {
    expect(testOrderId).toBeDefined();

    const recs = await computePartnerRecommendations(testOrderId, DEFAULT_WEIGHTS);

    expect(recs.length).toBeGreaterThan(0);

    // Candidates should be sorted descending by total score
    for (let i = 0; i < recs.length - 1; i++) {
      expect(recs[i].breakdown.totalScore).toBeGreaterThanOrEqual(recs[i + 1].breakdown.totalScore);
    }

    // Top partner should be Bharat ForgeWorks (EXCELLENT match)
    const topRec = recs[0];
    expect(topRec.breakdown.totalScore).toBeGreaterThan(85);
    expect(topRec.breakdown.matchCategory).toBe("EXCELLENT");
    expect(topRec.breakdown.reasons.length).toBeGreaterThan(0);
  });

  it("identifies operational limitations for lower matched candidates", async () => {
    const recs = await computePartnerRecommendations(testOrderId, DEFAULT_WEIGHTS);

    // Candidate with additive/different capability (Delta MicroTech) should have limitations
    const deltaRec = recs.find((r) => r.business.name.includes("Delta"));
    if (deltaRec) {
      expect(deltaRec.breakdown.totalScore).toBeLessThan(70);
      expect(deltaRec.breakdown.limitations.length).toBeGreaterThan(0);
    }
  });

  it("dynamically shifts scores when weights are adjusted", async () => {
    // Weight heavily toward deadline and lead time
    const customWeights = {
      capabilityWeight: 0.1,
      capacityWeight: 0.1,
      qualityWeight: 0.1,
      deadlineWeight: 0.6,
      trustWeight: 0.1,
    };

    const recs = await computePartnerRecommendations(testOrderId, customWeights);
    expect(recs.length).toBeGreaterThan(0);
    expect(recs[0].breakdown.deadlineScore).toBeGreaterThan(0);
  });
});
